# Material numérico e códigos

As bases copiadas preservam a amostra efetivamente utilizada; versões atuais das fontes podem conter revisões.

Os CSV/JSON guardam estatísticas, estimações, diagnósticos e previsões. Scripts em materiais/codigos usam caminhos relativos ao projeto. Os modelos serializados e bibliotecas não estão incluídos: execute as estimações anteriores para gerá-los antes dos scripts que deles dependem.

Dependências principais: Python, numpy, pandas, scipy, matplotlib, statsmodels, pmdarima e arch. A apresentação LaTeX é compilável independentemente dessas dependências.

Sequência geral: questao_1a, 1b, 1c, 2a, 2b, 2c, 2d, relatorio_2d, 2e, comparacao_2e, 3a, complemento_3a, 4a e 4b; parte2_a, parte2_b, parte2_b_diagnosticos, parte2_b_auto, parte2_c, parte2_c_graficos e parte2_d. Preserve as bases baixadas se desejar conferir os números históricos; scripts de obtenção podem consultar novamente as fontes.

tmp/slides32/revisao_completa.py monta a versão revisada usando os CSV/JSON e o fonte anterior como base dos slides preservados. A versão anterior incluída nessa pasta é dependência de montagem, não o arquivo atual para apresentar. O PDF atual e seu LaTeX autocontido ficam na raiz do repositório.

Este pacote foi organizado para disponibilizar os insumos e resultados existentes. Não foi feita nova estimação completa nesta revisão visual e de cobertura.
