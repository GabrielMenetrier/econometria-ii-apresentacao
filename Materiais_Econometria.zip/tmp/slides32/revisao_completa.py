from pathlib import Path
import sys,re,json,math,shutil
W=Path.cwd();sys.path.insert(0,str(W/'materiais/.dependencias'))
sys.stdout.reconfigure(encoding='utf-8')
import numpy as np
import pandas as pd
from scipy.stats import t as student_t
from statsmodels.tsa.stattools import acf
M=W/'materiais'; OUT=W/'output/pdf/slides_revisados';OUT.mkdir(parents=True,exist_ok=True)
# Reuse only the formatting helpers; the final document is built below.
scope={};exec((W/'tmp/slides32/latex_version.py').read_text(encoding='utf-8').split('parts=[header]')[0],scope)
base_tx=scope['tx'];font=scope['font'];header=scope['header']
def tx(s):
 s=str(s).replace('₋','-')
 for k,v in {'μ':'mu','ν':'nu','ρ':'rho','ε':'epsilon','Φ':'Phi','Θ':'Theta','χ':'chi','∞':'infty','ω':'omega','√':'surd','→':'rightarrow'}.items():s=s.replace(k,'@@'+v+'@@')
 s=base_tx(s)
 for k in ['mu','nu','rho','epsilon','Phi','Theta','chi','infty','omega','surd','rightarrow']:s=s.replace('@@'+k+'@@','$'+chr(92)+k+'$')
 return s
def node(x,y,w,text,size=18,bold=False,color='ink',raw=False):
 return rf'\node[anchor=north west,inner sep=0pt,text width={w}pt,align=left,text={color}] at ([xshift={x}pt,yshift=-{y}pt]current page.north west) {{{font(size)}'+(r'\bfseries ' if bold else '')+(str(text) if raw else tx(text))+'};\n'
def fmt(v,n=3):
 if pd.isna(v):return '-'
 return f'{v:,.{n}f}'.replace(',','X').replace('.',',').replace('X','.')
def pv(v):
 if v==0:return '< 10⁻³⁰⁰'
 if v>=.001:return fmt(v,3)
 mant,exp=f'{v:.2e}'.split('e');su=str.maketrans('0123456789-','⁰¹²³⁴⁵⁶⁷⁸⁹⁻')
 return mant.replace('.',',')+' × 10'+str(int(exp)).translate(su)
def read(p):return pd.read_csv(M/p)
def table(headers,rows,widths,y=95,fs=17,x=40,minh=30,pad=10):
 out='';cy=y
 for ri,row in enumerate([headers]+rows):
  rh=max(minh,max(str(t).count('\n')+1 for t in row)*fs*1.18+pad)
  if ri==0:out+=rf'\fill[black!6] ([xshift={x}pt,yshift=-{cy}pt]current page.north west) rectangle ++({sum(widths)}pt,-{rh}pt);'+'\n'
  cx=x
  for t,w in zip(row,widths):out+=node(cx+6,cy+pad/2,w-12,t,fs,ri==0);cx+=w
  cy+=rh;out+=rf'\draw[black!20,line width=.3pt] ([xshift={x}pt,yshift=-{cy}pt]current page.north west) -- ++({sum(widths)}pt,0);'+'\n'
 return out,cy
def tabular(*a,**k):return table(*a,**k)[0]
counter=0
def chart(x,y,w,h,title,series,bars=False,band=None,opts='',fs=10):
 global counter
 counter+=1;anchor='a'+str(counter);axx=x+35;axy=y+28;aw=w-50;ah=h-56
 out=node(x+12,y,w-20,title,14,True)
 out+=rf'\coordinate ({anchor}) at ([xshift={axx}pt,yshift=-{axy}pt]current page.north west);'+'\n'
 options=f'width={aw}pt,height={ah}pt,scale only axis,anchor=north west,at={{({anchor})}},axis lines=left,axis line style={{black!35}},tick style={{black!30}},ymajorgrids=true,grid style={{black!12}},scaled ticks=false,enlarge x limits=false,clip=true,tick label style={{font={font(fs)},/pgf/number format/1000 sep={{}}}}'
 out+='\\begin{axis}['+options+(','+opts if opts else '')+']\n'
 for i,se in enumerate(series):
  xx,yy=se[:2];color=se[2] if len(se)>2 else 'accent';style=se[3] if len(se)>3 else ('ycomb' if bars else 'no marks')
  coords=' '.join(f'({float(a):.8g},{float(b):.8g})' for a,b in zip(xx,yy) if np.isfinite(b))
  out+=r'\addplot['+color+','+style+',line width=.75pt] coordinates {'+coords+'};\n'
 if band is not None:
  xx=series[0][0]
  for z in [-band,band]:out+=rf'\addplot[black!45,dashed,no marks,line width=.5pt] coordinates {{({min(xx)},{z}) ({max(xx)},{z})}};'+'\n'
 return out+'\\end{axis}\n'
def correlogram(x,y,w,h,title,xx,yy,N):
 band=1.96/np.sqrt(N);lo=min(-band*1.5,float(min(yy))*1.2);hi=max(band*1.5,float(max(yy))*1.2)
 if hi>.8:lo=-.6;hi=1
 else:lo=math.floor(lo*10)/10;hi=math.ceil(hi*10)/10
 return chart(x,y,w,h,title,[(xx,yy)],True,band,opts='xmin=1,xmax='+str(max(xx))+',xtick={1,12,24,36,48},ymin='+str(lo)+',ymax='+str(hi))
source=(W/'output/pdf/slides_latex/apresentacao.tex').read_text(encoding='utf-8')
old={i+1:b for i,b in enumerate(source.split(r'\null\begin{tikzpicture}[remember picture,overlay]')[1:])}
for i in old:old[i]=old[i].split(r'\end{tikzpicture}\newpage')[0]
pages=[];audit=[];current=''
def add(body,cue,item,kind='resposta'):
 body=re.sub(r'\\node\[.*?yshift=-520\.00pt.*?;\n','',body)
 body=re.sub(r'\\node\[.*?yshift=-485\.00pt.*?;\n','',body)
 # Remove original footer rule before inserting a single, consistent footer.
 body=re.sub(r'\\draw\[black!25,line width=\.4pt\].*?;\n','',body)
 n=len(pages)+1
 if cue:
  body+=r'\draw[black!25,line width=.4pt] ([xshift=40pt,yshift=-472pt]current page.north west) -- ++(880pt,0);'+'\n'
  body+=node(42,482,860,cue,15,color='muted')
 body+=node(918,523,30,str(n),10,color='muted')
 pages.append(r'\null\begin{tikzpicture}[remember picture,overlay]'+'\n'+body+r'\end{tikzpicture}\newpage'+'\n')
 audit.append({'slide':n,'item':item,'tipo':kind,'lembrete':cue})
def question(n,item):add(old[n],'',item,'pergunta')
def start(title):return node(36,24,886,title,25,True)
def legacy(n,cue,item):add(old[n],cue,item)
def cf(key,what,x,y,w=440,h=165):
 z=fac[(fac.serie==key)&(fac.defasagem.between(1,48))]
 return correlogram(x,y,w,h,what,z.defasagem,z[what.split(' · ')[0]],z.N.iloc[0])
fac=read('questao_1b/coeficientes_fac_facp.csv')

# 1(a): six separate plots, then all four descriptive-statistics columns.
question(1,'1(a)')
legacy(2,'HOUSTNSA é o total mensal bruto; HOUST é uma taxa anualizada ajustada. Por isso, comparamos os níveis em painéis separados. Em 100 Δlog, a escala é comum e uma constante multiplicativa desaparece; o log sozinho não remove sazonalidade.', '1(a)')
lv=read('questao_1a/estatisticas_nivel_completa_1994_2025.csv');dl=read('questao_1a/estatisticas_dlog_completa_1994_2025.csv')
rows=[[str(lv.iloc[i,0])]+[fmt(v,0 if i==0 else 2) for v in [*lv.iloc[i,1:3],*dl.iloc[i,1:3]]] for i in range(len(lv))]
rows[4][0]='Q1 (25%)';rows[6][0]='Q3 (75%)'
b=start('1(a) O que mostram as estatísticas descritivas?')+tabular(['Estatística','h em nível','s em nível','100 Δlog h','100 Δlog s'],rows,[220,165,165,165,165],y=84,fs=17,minh=29)
b+=node(45,426,865,'1994M1–2025M12. Níveis: mil unidades/mês (h); mil unidades, taxa anualizada (s).\n100 Δlog: variação percentual aproximada. Curtose apresentada em excesso.',15)
add(b,'São 384 meses e 383 variações. A volatilidade das variações cai de 11,72 para 7,80 com o ajuste sazonal. Não dividimos os níveis por 12 nesta análise: as magnitudes têm unidades distintas, enquanto as variações logarítmicas permitem a comparação na mesma escala.', '1(a)')
# 1(b): all eight requested correlograms, plus logs required by the discussion.
question(3,'1(b)')
for label,keys in [('níveis',['h_nivel','s_nivel']),('logs',['log_h','log_s']),('diferenças do log',['dlog_h','dlog_s'])]:
 b=start('1(b) O que revelam a FAC e a FACP em '+label+'?')
 for col,key in enumerate(keys):
  for row,stat in enumerate(['FAC','FACP']):b+=cf(key,stat+' · '+('HOUSTNSA' if col==0 else 'HOUST'),35+col*460,88+row*177,h=164)
 b+=node(45,439,865,'Identificação: 1994M1–2024M12. 48 defasagens; bandas pontuais de referência ±1,96/√N.',14)
 cue={'níveis':'A FAC mede a correlação com cada atraso; a FACP retira o efeito dos atrasos intermediários. A persistência elevada aparece nas duas séries. Na bruta, o padrão anual é muito mais visível, pois a construção varia com clima e calendário.',
 'logs':'O decaimento lento é compatível com raiz AR próxima da unidade, sem comprovar uma raiz unitária. No AR(1), Φ(z)=1−φz e a raiz é 1/φ: φ próximo de 1 implica raiz próxima de 1. FAC e FACP informam a identificação; não alteram as raízes.',
 'diferenças do log':'A diferença do log reduz a persistência de longo prazo. Na bruta, ainda vemos picos em 12, 24 e 36 meses: a diferença mensal não remove toda a sazonalidade. Na ajustada, esses picos são menores graças ao procedimento de ajuste sazonal.'}[label]
 add(b,cue,'1(b)')
# 1(c): actual within-month subseries, not only twelve monthly means.
question(5,'1(c)')
sub=read('questao_1c/observacoes_subseries.csv');sub=sub[sub.ano<=2024]
months=['Jan','Fev','Mar','Abr','Mai','Jun','Jul','Ago','Set','Out','Nov','Dez']
for col,title,ylim in [('HOUSTNSA','bruta','ymin=0,ymax=210,ytick={0,100,200}'),('HOUST','ajustada','ymin=400,ymax=2400,ytick={500,1500,2300}')]:
 b=start('1(c) Qual o padrão? Seasonal subseries plot - '+title)
 for m in range(1,13):
  z=sub[sub.mes==m];xx=z.ano.to_numpy();vals=z[col].to_numpy()
  b+=chart(30+(m-1)%6*153,90+(m-1)//6*170,149,157,months[m-1],[(xx,vals,'accent'),([1994,2024],[vals.mean()]*2,'red!65!black','dashed,no marks')],opts=ylim+',xmin=1994,xmax=2024,xtick={1994,2024}',fs=9)
 b+=node(42,438,872,'Cada painel acompanha o mesmo mês em 1994–2024. Linha tracejada: média daquele mês.\nUnidade: '+('mil unidades no mês.' if col=='HOUSTNSA' else 'mil unidades, taxa anualizada dessazonalizada.'),14)
 add(b,'Cada painel reúne os janeiros, fevereiros e assim por diante, ao longo dos anos. A linha tracejada resume a média do mês; a curva mostra a variação entre anos. '+('As médias são maiores no meio do ano e menores no inverno.' if col=='HOUSTNSA' else 'As médias mensais ficam próximas, mas os ciclos e a crise imobiliária continuam visíveis. Ajustar a sazonalidade não elimina o ciclo.'),'1(c)')
legacy(6,'O perfil médio resume as linhas tracejadas dos painéis anteriores, agora em desvio percentual da média geral de cada série. A amplitude cai de 32,56 para 2,81 pontos percentuais. Isso evidencia a remoção do padrão mensal, sem provar ausência de toda dependência sazonal.', '1(c)')
# 2(a).
question(7,'2(a)')
b=start('2(a) Qual d adotar e quais ARIMA não sazonais testar?')
dd=read('questao_2a/fac_facp_delta_houst.csv');lagcol=dd.columns[0]
for k,stat in enumerate(['FAC','FACP']):
 z=dd[dd[lagcol].between(1,48)];b+=correlogram(35+k*460,88,440,164,stat+' · ΔHOUST',z[lagcol],z[stat],371)
b+=tabular(['Candidato','Justificativa'],[['(0,1,1)','FAC inicial dominada pelo atraso 1; FACP com cauda.'],['(1,1,1)','Permite dinâmica AR e MA sem impor cortes exatos.'],['(3,1,0)','FACP nos atrasos 2 e 3 é marginalmente relevante.'],['(1,1,0)','Alternativa AR curta; confronta o candidato MA(1).']],[175,705],y=272,fs=17,minh=30)
b+=node(42,437,870,r'$d=1$ em HOUST original; $\Delta s_t=s_t-s_{t-1}$. N = 371. Sem termos sazonais.',17,True,raw=True)
add(b,'Adotamos d=1 porque a persistência do nível desaparece após uma diferença. É uma escolha de modelagem, não prova de raiz unitária. Usamos ΔHOUST, sem log, coerente com o alvo s. Drift é a média das diferenças; d é o número de diferenças.', '2(a)')
# 2(b): one comparative table continued across three slides; no missing t statistics.
question(9,'2(b)')
est=read('questao_2b/resultados_completos.csv').sort_values('AIC');coef=read('questao_2b/coeficientes_erros_t.csv')
for part in range(3):
 rows=[]
 for _,r in est.iloc[part*4:(part+1)*4].iterrows():
  c=coef[coef.modelo==r.modelo];short=r.modelo.replace('ARIMA','').replace(' sem drift','\nsem drift').replace(' com drift','\ncom drift')
  rows.append([short,'\n'.join(c.parametro),'\n'.join(fmt(x) for x in c.estimativa),'\n'.join(fmt(x) for x in c.erro_padrao),'\n'.join(fmt(x,2) for x in c.t_assintotico),fmt(r.sigma2,2),fmt(r.AIC,2),fmt(r.BIC,2)])
 b=start(f'2(b) Quais estimativas sustentam a escolha? (tabela {part+1}/3)')
 b+=tabular(['ARIMA','Parâm.','Coef.','EP','t','σ²','AIC','BIC'],rows,[140,85,110,95,90,110,125,125],y=90,fs=17,minh=35,pad=6)
 b+=node(42,425,870,'Mesma ΔHOUST: 1994M2–2024M12, N = 371. Máxima verossimilhança exata; EP OIM.\n12 modelos: seis ordens, com e sem drift. σ² em (mil unidades, taxa anualizada)².',15)
 cue=['O (0,1,1) sem drift tem os menores AIC e BIC nesta comparação inicial. A tabela agora traz coeficientes, erros-padrão e t para todos os parâmetros. Um t pequeno indica pouca precisão relativa; os testes são assintóticos e dependem das hipóteses do modelo.',
 'Todos os modelos usam exatamente as mesmas 371 diferenças, a mesma escala e a mesma inicialização estacionária da parte ARMA. Alterar amostra ou transformação muda a base da verossimilhança e impede a comparação direta desses valores de AIC e BIC.',
 'AIC = −2 log L + 2k; BIC = −2 log L + k log N. Menor é preferível, equilibrando ajuste e quantidade de parâmetros. O BIC penaliza mais aqui. Os drifts estimados são imprecisos; a escolha sem drift ainda precisa passar pelo diagnóstico residual.'][part]
 add(b,cue,'2(b)')
# 2(c): explicitly state polynomials; root plot retained.
question(11,'2(c)')
b=old[12]+node(440,386,472,'Φ(z)=1; Θ(z)=1−0,4260z.\nFator de integração: (1−z).',17)
add(b,'Não há raiz AR para quase cancelar a raiz MA de 2,3473. A parte diferenciada é estacionária sob o modelo; o nível mantém a raiz unitária da integração. Quando raízes AR e MA quase coincidem, os efeitos se compensam, a estimação fica imprecisa e a parcimônia favorece simplificar.', '2(c)')
# 2(d): statistics, degrees of freedom, and actual path back to identification.
question(13,'2(d)')
fr=read('questao_2d/fac_residuos.csv');z=fr[(fr.modelo=='ARIMA(0,1,1) sem drift')&fr.lag.between(1,48)]
b=start('2(d) O modelo passa no diagnóstico dos resíduos?')
for k,c in enumerate(['FAC_residuos','FAC_residuos_quadrados']):b+=correlogram(35+k*460,85,440,160,'FAC · resíduos'+('²' if k else ''),z.lag,z[c],371)
tests=read('questao_2d/testes_residuos.csv');tests=tests[(tests.modelo=='ARIMA(0,1,1) sem drift')&((tests.teste=='Ljung-Box')|((tests.teste=='ARCH-LM')&(tests.defasagem==12)))]
rows=[[r.teste+' ('+str(r.defasagem)+')',fmt(r.estatistica,3),str(r.gl),pv(r.p_valor),'Rejeita' if r.p_valor<.05 else 'Não rejeita'] for r in tests.itertuples()]
b+=tabular(['Teste','Q ou LM','gl','p-valor','Decisão a 5%'],rows,[250,160,80,180,210],y=269,fs=17,minh=31)
b+=node(42,435,870,'Q: autocorrelação conjunta até o atraso indicado. ARCH: dependência nos resíduos².',16)
add(b,'Q(24) rejeita ausência de autocorrelação; ARCH(12) rejeita ausência de efeitos ARCH. Os gráficos usam bandas pontuais aproximadas. Portanto, o modelo não passou no diagnóstico completo: precisamos voltar à identificação e não podemos chamá-lo de ruído branco validado.', '2(d)')
diag=read('questao_2d/comparacao_diagnosticos.csv')
chosen=['ARIMA(0,1,1) sem drift','ARIMA(0,1,2) sem drift','ARIMA(3,1,0) sem drift','ARIMA(2,1,3) sem drift','ARIMA(5,1,0) sem drift']
rows=[]
for name in chosen:
 r=diag[diag.modelo==name].iloc[0];rows.append([name.replace('ARIMA','').replace(' sem drift',''),fmt(r.AIC,2),fmt(r.BIC,2),pv(r.p_Q24),pv(r.p_ARCH12)])
b=start('2(d) O que mudou ao voltar à identificação?')+tabular(['ARIMA sem drift','AIC','BIC','p Q(24)','p ARCH(12)'],rows,[240,160,160,160,160],y=98,fs=19,minh=41)
b+=node(43,367,867,'12 candidatos iniciais + 12 novas ordens: nenhum passou em todos os testes.\n(2,1,3): ΔAIC = −0,10; BIC pior; raiz MA ≈ 1 e quase cancelamento AR/MA.',19)
add(b,'Exploramos ordens adicionais para absorver a dependência residual. O ganho de AIC do (2,1,3) é mínimo e vem com instabilidade e mais parâmetros; Q e ARCH continuam rejeitando. Mantemos o (0,1,1) por parcimônia apenas como benchmark com falhas declaradas, não como modelo aprovado.', '2(d)')
# 2(e).
question(15,'2(e)')
b=start('2(e) A seleção automática concorda com a manual?')
b+=tabular(['Seleção','Modelo','AIC','BIC','p Q24'],[['Manual','(0,1,1)','4.415,88','4.423,71','0,0042'],['Auto não sazonal','(0,1,1)','4.415,88','4.423,71','0,0042'],['Auto m=12','(0,1,1)(0,0,2)₁₂','4.404,35','4.420,01','0,0097']],[210,240,150,150,130],y=109,fs=19,minh=52)
b+=node(43,345,875,'Questão 2: modelo principal não sazonal; item 2(e): investigar termos sazonais.',18,True)
b+=node(43,388,875,'pmdarima: stepwise/AIC; KPSS d=1; OCSB D=0; m=12 na busca sazonal.\nSARIMA automático: ainda rejeita Q(24) e ARCH(12).',17)
add(b,'O texto da questão 2 exige modelo principal não sazonal. Já 2(e) pede observar termos sazonais na seleção automática: comparar é pertinente, mas substituir o principal não está explicitamente autorizado. O espaço de busca ampliado explica a divergência; D=0 não obriga P=Q=0.', '2(e)')
# 3(a): identify orders, justify candidates, coefficients/IC, residuals and Q.
question(17,'3(a)')
ident=read('questao_3a/identificacao.csv')
b=start('3(a) Quais diferenças e ordens sazonais testar?')
for row,(key,label) in enumerate([('diff1','Δh'),('diff1_diff12','(1−B)(1−B¹²)h')]):
 z=ident[(ident.transformacao==key)&ident.lag.between(1,48)]
 for col,stat in enumerate(['FAC','FACP']):b+=correlogram(35+460*col,85+177*row,440,161,stat+' · '+label,z.lag,z[stat],z.N.iloc[0])
b+=node(42,438,872,'HOUSTNSA original, sem log. d=D=1 como hipótese de trabalho; P e Q têm período 12.',16)
add(b,'Em Δh, os picos anuais persistem. Na diferença mensal e anual combinada, a FAC destaca atrasos 1 e 12 negativos, sugerindo MA(1) comum e sazonal. A FACP tem cauda. Os testes de diferenciação não são unânimes; d=D=1 é uma escolha de trabalho, não duas raízes comprovadas.', '3(a)')
sar=read('questao_3a/comparacao.csv');sc=read('questao_3a/coeficientes.csv');names=sar.head(4).modelo.tolist()
short=lambda s:s.replace('SARIMA','').replace(')12',')₁₂')
b=start('3(a) Como os candidatos confrontam a identificação?')
rows=[[short(names[0]),'MA curto e sazonal: p=P=0, q=Q=1.'],[short(names[1]),'Q=2: testa um segundo termo MA anual.'],[short(names[2]),'P=1, Q=1: permite dinâmica sazonal mista.'],[short(names[3]),'p=1, q=1: permite dinâmica curta mista.']]
b+=tabular(['SARIMA candidato','Justificativa'],rows,[290,590],y=104,fs=20,minh=58)
b+=node(42,413,874,'Dez candidatos estimados; quatro melhores por AIC detalhados a seguir.\nMesma diferença dupla: 1995M2–2024M12, N=359; sem termo determinístico.',16)
add(b,'A proposta central é (0,1,1)(0,1,1)₁₂. Os demais candidatos verificam se um AR adicional ou um segundo MA sazonal melhora o ajuste o suficiente para compensar a complexidade. As comparações mantêm a transformação e a amostra; não comparamos esses AIC aos de HOUST.', '3(a)')
b=start('3(a) Quais estimativas e critérios sustentam a escolha?');rows=[]
for name in names:
 r=sar[sar.modelo==name].iloc[0];c=sc[sc.modelo==name]
 par=c.parametro.replace({'ma.L1':'θ₁','ma.S.L12':'Θ₁','ma.S.L24':'Θ₂','ar.L1':'φ₁','ar.S.L12':'Φ₁'})
 rows.append([short(name),'\n'.join(par),'\n'.join(fmt(v) for v in c.coeficiente),'\n'.join(fmt(v) for v in c.erro_padrao),'\n'.join(fmt(v,2) for v in c.t),fmt(r.sigma2,2),fmt(r.AIC,2),fmt(r.BIC,2)])
b+=tabular(['SARIMA','Parâm.','Coef.','EP','t','σ²','AIC','BIC'],rows,[230,80,105,85,80,90,100,100],y=92,fs=16,minh=37)
b+=node(42,426,875,r'$(1-B)(1-B^{12})h_t=(1-0{,}4545B)(1-0{,}8204B^{12})\varepsilon_t$',21,True,raw=True)
add(b,'O candidato mais simples tem o menor AIC e BIC entre os dez testados. O produto dos dois fatores MA também gera o atraso 13, sem novo parâmetro livre. AIC próximos indicam que a separação não é esmagadora; precisamos considerar o diagnóstico residual e a incerteza das diferenças.', '3(a)')
b=start('3(a) Os resíduos dos candidatos ainda têm sazonalidade?');sacf=read('questao_3a/fac_residuos.csv')
for i,name in enumerate(names):
 z=sacf[(sacf.modelo==name)&sacf.lag.between(1,36)]
 b+=correlogram(35+(i%2)*460,87+(i//2)*177,440,162,'FAC · '+short(name),z.lag,z.FAC,359)
b+=node(42,440,870,'Bandas pontuais ≈ ±0,103. Ultrapassagens isoladas não equivalem ao teste conjunto Q.',15)
add(b,'A sequência de grandes picos anuais diminui bastante. Ainda existem barras fora das bandas, inclusive no escolhido; isso é compatível com não rejeitar os testes conjuntos de Q. A avaliação deve combinar os correlogramas com Q(12), Q(24) e Q(36), apresentados a seguir.', '3(a)')
b=start('3(a) Como comparar Q(12), Q(24), Q(36) e ARCH?');rows=[]
for name in names:
 r=sar[sar.modelo==name].iloc[0];rows.append([short(name)]+[fmt(r['Q'+str(k)],2)+'\n('+pv(r['p_Q'+str(k)])+')' for k in [12,24,36]]+[pv(r.ARCH12_p)])
b+=tabular(['SARIMA','Q12 (p)','Q24 (p)','Q36 (p)','p ARCH12'],rows,[290,150,150,150,140],y=100,fs=18,minh=55)
b+=node(42,399,868,'Escolha: (0,1,1)(0,1,1)₁₂. Q não rejeita a 5%; ARCH ainda rejeita.\nSensibilidade d=0,D=1 também passa Q, mas estima AR ≈ 0,986.',17,True)
add(b,'O SARIMA passa nos três testes de autocorrelação pedidos, mas não no ARCH: a variância ainda tem dependência. É uma melhoria na equação da média, não aprovação irrestrita. Mantemos a ressalva de diferenciação e não usamos AIC de transformações diferentes para resolver essa dúvida.', '3(a)')
# 4(a)-(c): preserve actual recursive exercise, explain its conditional interpretation.
question(19,'4(a)')
legacy(20,'A primeira origem é janeiro de 2015 e o primeiro alvo é fevereiro. A janela começa sempre em 1994 e se expande; reestimamos a cada mês. São 131 previsões por série. As ordens escolhidas até 2024 limitam a interpretação histórica: é uma avaliação condicional dessas especificações.', '4(a)')
b=start('4(a) Como foram calculados os erros de previsão?')
b+=node(55,110,850,r'$e_t=y_t-\widehat y_{t|t-1}$',28,raw=True)
b+=node(55,180,850,r'$\mathrm{RMSE}=\sqrt{\frac{1}{N}\sum e_t^2}\qquad \mathrm{MAE}=\frac{1}{N}\sum |e_t|$',26,raw=True)
b+=node(55,250,850,r'$\mathrm{MAPE}=\frac{100}{N}\sum\left|e_t/y_t\right|$',26,raw=True)
b+=node(55,333,840,'2025 só entra na estimação após cada observação ser prevista.\nOrdens fixadas com 2024: seleção não estritamente fora da amostra antes de 2025.\nDados revisados; datas de divulgação não reproduzidas.',19)
add(b,'RMSE dá maior peso a erros grandes; MAE resume o erro absoluto; MAPE é o erro relativo percentual. RMSE e MAE não são comparáveis entre as unidades originais de HOUST e HOUSTNSA. Mesmo MAPE descreve alvos distintos; a comparação direta exige a transformação do próximo item.', '4(a)')
question(21,'4(b)')
b=start('4(b) Como colocar as previsões no mesmo alvo?')
b+=node(50,113,855,r'$R_\tau=12h_\tau/s_\tau,\qquad \widehat F_{m|t}=\mathrm{média}\{R_\tau:\tau\leq t,\ \mathrm{mês}(\tau)=m\}$',22,raw=True)
b+=node(50,196,855,r'$\widehat h^{\,A}_{t+1|t}=\frac{\widehat s_{t+1|t}}{12}\widehat F_{m(t+1)|t}$',29,raw=True)
b+=tabular(['Rota','Saída comparável'],[['HOUST → ARIMA → ÷12 × fator','Mil unidades no mês, sem ajuste'],['HOUSTNSA → SARIMA direto','Mil unidades no mês, sem ajuste']],[505,375],y=280,fs=21,minh=48)
b+=node(43,439,867,'Fator calculado apenas com dados anteriores ao alvo. 2025: 31 anos por mês calendário.',15)
add(b,'Dividir por 12 muda a taxa anualizada para escala mensal; ainda falta recompor a sazonalidade. Estimamos o fator pela razão histórica do mesmo mês, sem usar o fator futuro observado. A recomposição é aproximada: não inverte exatamente o procedimento oficial e acrescenta incerteza.', '4(b)')
legacy(22,'As duas curvas agora preveem HOUSTNSA, com origens atualizadas mensalmente em 2025. O SARIMA tem erros menores nesta comparação. Os intervalos nominais de 95% são condicionais aos parâmetros e ao fator fixo; omitem a incerteza da recomposição, revisões e efeitos ARCH.', '4(b)')
question(23,'4(c)')
legacy(24,'Para o total mensal bruto, defendemos SARIMA como benchmark pontual, mantendo ARIMA de HOUST como referência auxiliar. O ganho de RMSE em 2025 é cerca de 25%, mas são só 12 observações e não fizemos teste de superioridade preditiva. Monitorar erros e recalibrar intervalos continua necessário.', '4(c)')
# Part 2(a): return calculation, complete description, ARCH.
question(25,'2ª parte (a)')
legacy(26,'Usamos rₜ=100 log(Pₜ/Pₜ₋₁), com o fechamento de 2019-12-31 apenas como base do primeiro retorno. Grandes oscilações se agrupam no tempo. Isso sugere volatilidade previsível, não previsibilidade do sinal dos retornos. O teste ARCH formaliza essa dependência nos resíduos ao quadrado.', '2ª parte (a)')
gs=json.loads((M/'parte_2_garch/item_a/estatisticas.json').read_text());ar=read('parte_2_garch/item_a/teste_ARCH_LM.csv')
b=start('Parte 2(a) O que a distribuição e o teste ARCH revelam?')
rows=[[label,fmt(gs[key],3)] for label,key in [('Média (%)','media_pct'),('Mediana (%)','mediana_pct'),('Desvio-padrão (p.p.)','desvio_padrao_pct'),('Mínimo (%)','min_pct'),('Máximo (%)','max_pct'),('Assimetria','assimetria'),('Curtose Pearson','curtose_Pearson')]]
b+=tabular(['Estatística','Valor'],rows,[285,120],y=91,fs=18,minh=36)
rows=[[str(r.defasagens),fmt(r.LM,2),pv(r.p_valor)] for r in ar[ar.media=='media_constante'].itertuples()]
b+=tabular(['ARCH-LM(q)','LM','p-valor'],rows,[150,130,150],x=490,y=91,fs=18,minh=45)
b+=node(500,329,408,'H₀: coeficientes dos resíduos²\ndefasados iguais a zero.\nLM = N auxiliar × R²; gl = q.',19)
b+=node(44,425,870,'N = 1.508 retornos. Caudas pesadas e assimetria negativa. ARCH rejeita em todos os lags.',17,True)
add(b,'A curtose de 17,69 supera muito a referência normal de 3; a distribuição tem caudas pesadas e assimetria negativa. No LM, explicamos resíduos quadrados por seus próprios atrasos. A rejeição é muito forte e permanece com média AR(5): há fundamento empírico para modelar variância condicional.', '2ª parte (a)')
# Part 2(b): model rationale and coefficients, identification, standardized diagnostics, tails/asymmetry.
question(27,'2ª parte (b)')
eg=json.loads((M/'parte_2_garch/item_b/diagnosticos_detalhados.json').read_text());ec=read('parte_2_garch/item_b/comparacao.csv');auto=read('parte_2_garch/item_b/busca_automatica.csv')
b=start('Parte 2(b) Por que EGARCH é adequado a retornos acionários?')
b+=node(43,95,876,r'$r_t=\mu+\sigma_tz_t,\quad \log\sigma_t^2=\omega+\beta\log\sigma_{t-1}^2+\alpha(|z_{t-1}|-\sqrt{2/\pi})+\gamma z_{t-1}$',20,raw=True)
rows=[]
for k,label in [('mu','μ'),('omega','ω'),('alpha[1]','α'),('gamma[1]','γ'),('beta[1]','β'),('nu','ν')]:rows.append([label,fmt(eg['parametros'][k],4),fmt(eg['std_errors_robustos'][k],4),pv(eg['p_valores'][k])])
b+=tabular(['Parâmetro','Estimativa','EP robusto','p-valor'],rows,[145,145,145,145],y=174,fs=17,minh=33)
b+=node(648,179,263,'Log-variância → σ² > 0\nβ: persistência\nα: tamanho do choque\nγ: efeito do sinal\nt: caudas pesadas',19)
b+=node(42,430,874,'Convenção do pacote arch; z tem distribuição t padronizada. N efetivo = 1.503.',15)
add(b,'EGARCH modela o log da variância, garantindo positividade após exponenciar, sem exigir coeficientes de choque positivos. A magnitude e o sinal têm efeitos separados; beta transmite persistência. A distribuição t acomoda caudas pesadas. O termo de centralização exibido é a convenção efetivamente usada pelo pacote arch.', '2ª parte (b)')
b=start('Parte 2(b) Como fizemos a identificação e a seleção?')
rows=[]
for name in ['AR0_EGARCH111_t','AR1_EGARCH111_t','AR5_EGARCH111_t','AR0_EGARCH101_t','AR0_EGARCH111_normal']:
 r=ec[ec.modelo==name].iloc[0];rows.append([name.replace('AR0_','Constante / ').replace('AR1_','AR(1) / ').replace('AR5_','AR(5) / ').replace('_',' '),fmt(r.AIC,2),fmt(r.BIC,2)])
b+=tabular(['Média / EGARCH / distribuição','AIC','BIC'],rows,[530,175,175],y=93,fs=18,minh=38)
b+=node(45,343,870,'1. Retornos: ADF p < 0,001; KPSS p ≥ 0,10; verificar dinâmica da média.\n2. Comparar 12 especificações: média constante/AR, normal/t, com/sem assimetria.\n3. Grade automática adicional: 24 EGARCH-t; p,q=1/2; o=0/1; média 0/1/5.',17)
add(b,'A identificação combina teoria, testes e comparação na mesma amostra de 1.503 retornos. A seleção inicial favorece média constante e EGARCH assimétrico com t. A grade automática confirma essa escolha por AIC e BIC. Convergência e estabilidade foram verificadas; isso ainda não substitui examinar os resíduos padronizados.', '2ª parte (b)')
res=read('parte_2_garch/item_b/residuos_volatilidade.csv').dropna();z=res.z.to_numpy()
b=start('Parte 2(b) Restou autocorrelação ou ARCH após o EGARCH?')
for k,(a,label) in enumerate([(z,'z = ε/σ'),(z*z,'z²')]):b+=correlogram(35+k*460,87,440,166,'FAC · '+label,np.arange(1,31),acf(a,nlags=30,fft=False)[1:],len(a))
r=ec[ec.modelo=='AR0_EGARCH111_t'].iloc[0];rows=[[str(h),pv(r[f'LB_z_{h}_p']),pv(r[f'LB_z2_{h}_p']),pv(r[f'ARCH_{h}_p'])] for h in [5,10,20]]
b+=tabular(['Defasagens','p Q(z)','p Q(z²)','p ARCH'],rows,[220]*4,y=281,fs=19,minh=38)
b+=node(44,439,870,'A 5%, nenhum desses testes rejeita. Bandas da FAC: referência pontual, não simultânea.',15)
add(b,'Padronizamos o resíduo pela volatilidade estimada. Q(z) verifica dinâmica restante da média; Q(z²) e ARCH verificam dependência restante na variância. Não há rejeição nas defasagens 5, 10 e 20. Isso apoia o ajuste, mas não prova independência, distribuição correta ou boa previsão de risco.', '2ª parte (b)')
b=start('Parte 2(b) Como ficam as caudas e a assimetria residual?')
theo=student_t.ppf((np.arange(len(z))+.5)/len(z),df=eg['parametros']['nu'])*np.sqrt((eg['parametros']['nu']-2)/eg['parametros']['nu']);ordered=np.sort(z)
b+=chart(30,91,470,288,'Q–Q · t padronizada',[(theo,ordered,'accent','only marks,mark=*,mark size=.7pt'),([-6,6],[-6,6],'black!45','no marks')],opts='xlabel={Quantil teórico},ylabel={Quantil observado},xmin=-6,xmax=6,ymin=-12,ymax=7')
rows=[['EGARCH simétrico',pv(eg['sign_size_rawlag']['AR0_EGARCH101_t']['p'])],['EGARCH assimétrico',pv(eg['sign_size_rawlag']['AR0_EGARCH111_t']['p'])],['Variante: atrasos de z',pv(r.sign_size_p)],['Variante com HC3',pv(r.sign_size_HC3_p)]]
b+=tabular(['Engle–Ng / variante','p-valor'],rows,[295,120],x=505,y=112,fs=17,minh=44)
b+=node(520,356,395,'Cauda esquerda ainda discrepante.\nResultado da assimetria residual\né sensível à implementação.',18)
b+=node(45,440,867,'Q–Q compara a distribuição de z com a t estimada. Não exigimos normalidade de z.',15)
add(b,'O gráfico Q–Q revela uma cauda esquerda mais extrema do que a t ajustada. O Engle–Ng usual não rejeita no EGARCH assimétrico, mas uma variante com atrasos padronizados rejeita; a correção HC3 altera a conclusão. Registramos essa sensibilidade, em vez de declarar que toda assimetria foi eliminada.', '2ª parte (b)')
legacy(28,'Gamma negativo e estatisticamente significativo indica impacto maior de um choque negativo que de um positivo de mesma magnitude. Para choques de uma unidade padronizada, a razão de variâncias é 1,438, ou cerca de 20% a mais em volatilidade. É assimetria de resposta; não prova causalidade financeira.', '2ª parte (b)')
# Part 2(c): multiple GARCH specifications, parameter estimates and persistence comparison.
question(29,'2ª parte (c)')
gc=read('parte_2_garch/item_c/comparacao_garch.csv');gp=json.loads((M/'parte_2_garch/item_c/persistencia.json').read_text())['AR0_GARCH11_t']
b=start('Parte 2(c) Quais GARCH foram estimados e comparados?');rows=[]
for name in ['AR0_GARCH11_t','AR0_GARCH21_t','AR0_GARCH12_t','AR5_GARCH11_t','AR0_GARCH11_normal']:
 r=gc[gc.modelo==name].iloc[0];rows.append([name.replace('AR0_','Constante / ').replace('AR5_','AR(5) / ').replace('_',' '),fmt(r.AIC,2),fmt(r.BIC,2),fmt(r.persistencia,4)])
rows.append(['Constante / EGARCH111 t',fmt(ec.iloc[0].AIC,2),fmt(ec.iloc[0].BIC,2),'β = 0,9753'])
b+=tabular(['Média / variância / distribuição','AIC','BIC','Persistência'],rows,[420,150,150,160],y=98,fs=18,minh=40)
b+=node(45,413,865,'18 GARCH: ordens (1,1), (1,2), (2,1); médias constante/AR(1)/AR(5); normal/t.\nMesma amostra efetiva: N=1.503. BIC escolhe GARCH(1,1)-t dentro da família GARCH.',16)
add(b,'Estimamos vários GARCH, não apenas um. Dentro da família, o BIC favorece média constante e GARCH(1,1)-t; o AIC prefere ligeiramente média AR(5). O EGARCH ainda tem critérios menores. A comparação de persistência exige distinguir variância, no GARCH, de log-variância, no EGARCH.', '2ª parte (c)')
b=start('Parte 2(c) Como os parâmetros determinam a persistência?')
b+=node(45,94,860,r'$\sigma_t^2=\omega+\alpha\varepsilon_{t-1}^2+\beta\sigma_{t-1}^2\qquad\text{(GARCH)}$',24,raw=True)
rows=[]
for key,gkey,label in [('mu','mu','μ'),('omega','omega','ω'),('alpha[1]','alpha[1]','α'),('beta[1]','beta[1]','β'),('gamma[1]',None,'γ'),('nu','nu','ν')]:
 rows.append([label,fmt(gp['params'][gkey],4) if gkey else '-',fmt(gp['se'][gkey],4) if gkey else '-',fmt(eg['parametros'][key],4),fmt(eg['std_errors_robustos'][key],4)])
b+=tabular(['Parâmetro','GARCH coef.','EP robusto','EGARCH coef.','EP robusto'],rows,[140,185,185,185,185],y=161,fs=18,minh=34)
b+=node(45,426,865,'GARCH: α+β = 0,9814; IC Wald 95% ≈ [0,9535; 1,0093].\nEGARCH: persistência na log-variância = β; não somar α+β.',16)
add(b,'No GARCH, choques grandes elevam a variância independentemente do sinal; alpha mais beta mede a propagação da variância esperada. No EGARCH, gamma diferencia sinais e beta transmite log-variância. O intervalo de alpha mais beta inclui 1: a reversão estimada não deve ser tratada como certeza.', '2ª parte (c)')
legacy(30,'As meias-vidas estimadas são 36,9 pregões no GARCH e 27,7 no EGARCH, mas se referem a grandezas diferentes. Ambos capturam persistência elevada. O GARCH deixa assimetria residual: Engle–Ng p=0,022, contra 0,456 no EGARCH usual. A preferência de ajuste pelo EGARCH não garante adequação a todo cálculo de risco.', '2ª parte (c)')
# Part 2(d): forecasts with all 15 dates and operational caveat.
question(31,'2ª parte (d)')
legacy(32,'As curvas mostram a mediana da volatilidade e quantis de 5% e 95%, não intervalos de retorno. No EGARCH-t estimado, a esperança da variância diverge a partir de dois passos; uma média simulada finita seria enganosa. Para proteção baseada em variância esperada, usamos GARCH como referência e EGARCH como cenário complementar.', '2ª parte (d)')
fore=read('parte_2_garch/item_d/previsoes_15_pregoes.csv');rows=[]
for h in range(1,16):
 g=fore[(fore.modelo=='GARCH')&(fore.horizonte==h)].iloc[0];e=fore[(fore.modelo=='EGARCH')&(fore.horizonte==h)].iloc[0]
 rows.append([str(h),pd.Timestamp(g.data).strftime('%d/%m/%Y')]+[fmt(v,3) for v in [g.sigma_mediana,g.sigma_q05,g.sigma_q95,e.sigma_mediana,e.sigma_q05,e.sigma_q95]])
b=start('Parte 2(d) Quais são as previsões dos 15 pregões?')
b+=tabular(['h','Data','G mediana','G q05','G q95','E mediana','E q05','E q95'],rows,[40,130,140,100,100,140,110,120],y=82,fs=15,minh=21,pad=4)
b+=node(43,444,867,'Volatilidade diária em p.p.; origem 31/12/2025. G = GARCH; E = EGARCH. 200 mil trajetórias.',14)
add(b,'São 15 pregões de 2 a 23 de janeiro de 2026, excluindo o feriado de 19 de janeiro. Não usamos observações futuras. O EGARCH termina com mediana maior e faixa mais ampla; o GARCH oferece variância esperada finita. A escolha operacional depende da medida usada para dimensionar a proteção.', '2ª parte (d)')

text=header+''.join(pages)+r'\end{document}'
# Additional Greek characters in inherited slide text are handled in newly authored nodes.
(OUT/'apresentacao.tex').write_text(text,encoding='utf-8')
(OUT/'roteiro.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2),encoding='utf-8')
mapping={}
for a in audit:mapping.setdefault(a['item'],[]).append(a['slide'])
requirements={
'1(a)':'Seis gráficos separados; estatísticas completas de nível e 100 Δlog; unidades e comparação.',
'1(b)':'FAC/FACP de h, s, Δlog h e Δlog s; FAC/FACP dos logs para discutir raízes; 48 defasagens e bandas.',
'1(c)':'Dois seasonal subseries plots efetivos (12 painéis cada), perfil médio e comparação.',
'2(a)':'d=1 em HOUST original, quatro candidatos não sazonais e justificativas FAC/FACP.',
'2(b)':'Tabela comparativa de 12 modelos, continuada em três slides: coeficientes, EP, t, σ², AIC/BIC e amostra comum.',
'2(c)':'Polinômios AR/MA e integração, raízes, círculo de raízes inversas, estacionariedade/invertibilidade e cancelamento.',
'2(d)':'FAC residual e quadrados; valores de Q(6,12,24), gl e p; ARCH-LM; caminho de 24 modelos e ressalvas.',
'2(e)':'Seleção manual/automática, configurações, termos sazonais e interpretação cuidadosa da restrição.',
'3(a)':'Identificação de p,q,P,Q; justificativas; estimativas e IC de quatro candidatos; FAC residual de cada um; Q(12,24,36) e ARCH; escolha.',
'4(a)':'131 previsões de um passo, janela expansível, RMSE/MAE/MAPE e fórmulas. Ressalva explícita de seleção histórica.',
'4(b)':'Alvo comum, fórmula do fator estimado só no passado, gráficos 2025 com intervalos e limitações.',
'4(c)':'Recomendação condicionada ao alvo bruto e às falhas residuais/limitações da avaliação.',
'2ª parte (a)':'Log-retornos, série temporal, distribuição descritiva, ARCH-LM em múltiplas defasagens e interpretação.',
'2ª parte (b)':'Equação e características EGARCH; estimação; seleção manual/automática; FAC z/z²; Q/ARCH; Q-Q t; assimetria e sensibilidade.',
'2ª parte (c)':'Vários GARCH, IC comuns, coeficientes/EP e comparação de persistência e meias-vidas em escalas diferentes.',
'2ª parte (d)':'Gráficos e tabela de 15 pregões, quantis, diferenças e recomendação operacional; divergência da esperança no EGARCH-t.'}
report='# Auditoria da apresentação revisada\n\nRevisão confrontada com Lista1_EconometriaII_2026.pdf. As perguntas seguem separadas das respostas; a tabela de 2(b) é uma única comparação continuada em três slides para preservar a leitura.\n\n| Item | Slides | Conteúdo conferido |\n|---|---|---|\n'
for k,v in mapping.items():report+='| '+k+' | '+', '.join(map(str,v))+' | '+requirements[k]+' |\n'
report+='\n## Limitações preservadas, sem mascarar resultados\n\n- O ARIMA não passou no diagnóstico completo; nenhuma das 24 alternativas passou em todos os testes.\n- O SARIMA melhora os testes Q pedidos, mas ainda apresenta ARCH e incerteza sobre diferenciação.\n- A previsão recursiva usa ordens escolhidas até 2024. Os ajustes e fatores usam apenas o passado de cada origem, mas a seleção das ordens não é estritamente fora da amostra nas primeiras origens. O exercício é condicional às especificações selecionadas; não foi refeito como seleção recursiva histórica.\n- As bases são revisadas, não vintages em tempo real; intervalos ignoram fontes de incerteza declaradas.\n- Diagnósticos EGARCH não são aprovação irrestrita: cauda esquerda, variantes de assimetria e momentos futuros permanecem ressalvas.\n- O PDF é uma apresentação. O enunciado também pede código e base na entrega; este repositório inclui um pacote dos materiais numéricos e scripts utilizados, separado do arquivo de slides.\n\n## Alterações visuais\n\n- Removido o rótulo dos lembretes de apresentação; o texto permanece discretamente no rodapé e foi ampliado moderadamente.\n- Mantidas fontes Latin Modern, inclusive gráficos e tabelas.\n- Acrescentados slides de resposta conforme necessidade; nenhum item do enunciado foi suprimido.\n'
(OUT/'AUDITORIA.md').write_text(report,encoding='utf-8')
print('Slides:',len(pages));print(json.dumps(mapping,ensure_ascii=False))
