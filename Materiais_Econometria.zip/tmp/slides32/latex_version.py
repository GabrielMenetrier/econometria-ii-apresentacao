from pathlib import Path
import zipfile,xml.etree.ElementTree as E,re,json,math,posixpath
W=Path.cwd(); OUT=W/'output/pdf/slides_latex';OUT.mkdir(parents=True,exist_ok=True)
NS={'p':'http://schemas.openxmlformats.org/presentationml/2006/main','a':'http://schemas.openxmlformats.org/drawingml/2006/main','c':'http://schemas.openxmlformats.org/drawingml/2006/chart','r':'http://schemas.openxmlformats.org/officeDocument/2006/relationships'}
summaries=[
'Descrever as duas séries, comparar suas transformações e respeitar as unidades distintas.',
'Usar FAC e FACP para identificar persistência, possível raiz unitária e sazonalidade.',
'Comparar o padrão médio dos meses do ano antes e depois do ajuste sazonal.',
'Escolher d e propor pelo menos três ARIMA não sazonais para HOUST.',
'Estimar os candidatos e comparar coeficientes, incerteza, AIC e BIC em condições iguais.',
'Verificar raízes AR e MA, estacionariedade, invertibilidade e possível cancelamento.',
'Testar autocorrelação e ARCH nos resíduos e revisar o modelo se necessário.',
'Comparar seleção manual e automática, observando a eventual inclusão de sazonalidade.',
'Propor, estimar e diagnosticar SARIMA para a série bruta; escolher um candidato.',
'Produzir previsões de um passo com janela expansível e medir os erros.',
'Colocar as duas previsões na mesma unidade e comparar com 2025, incluindo intervalos.',
'Recomendar ao comitê um modelo e deixar claras as limitações.',
'Descrever os log-retornos do S&P 500 e testar dependência na variância.',
'Justificar o EGARCH, percorrer os diagnósticos e testar assimetria.',
'Comparar GARCH e EGARCH, sobretudo a persistência estimada da volatilidade.',
'Prever 15 pregões de volatilidade e discutir o uso dos modelos na proteção.'
]
hints=[
'A bruta mostra sazonalidade mais forte. Os níveis têm unidades diferentes; comparar diferenças do log elimina uma constante de escala. O log, sozinho, não retira sazonalidade.',
'FAC lenta nos logs sugere persistência, sem provar raiz unitária. Os picos em 12 meses são mais fortes na bruta. FAC e FACP orientam a escolha, mas não alteram raízes.',
'O perfil bruto sobe no meio do ano. Após o ajuste, fica quase plano: amplitude de 32,56 para 2,81 p.p. Isso não elimina ciclo nem risco.',
'Usamos uma diferença de HOUST em nível. A dependência inicial motiva candidatos AR e MA. Depois, somamos as diferenças previstas ao último nível observado.',
'O (0,1,1) sem drift vence a comparação inicial. AIC e BIC só são comparáveis porque usamos a mesma transformação e amostra. Menor critério não garante bom diagnóstico.',
'A raiz MA está fora do círculo, logo o MA é invertível. A raiz em 1 vem da diferenciação: o nível é integrado. Não há par AR/MA para cancelamento.',
'Q em 24 meses e ARCH rejeitam. Testamos 24 alternativas e nenhuma passou em tudo. Mantivemos o modelo apenas como benchmark, declarando suas falhas.',
'O automático não sazonal confirma a escolha. Com sazonalidade, melhora os critérios, mas ainda reprova testes. A questão pede modelo principal não sazonal e permite essa comparação.',
'O SARIMA escolhido melhora o diagnóstico da média: Q não rejeita em 12, 24 e 36. Porém ARCH permanece, e a escolha das diferenças ainda exige cautela.',
'A janela cresce e mantém o início em 1994. São 131 previsões. As ordens escolhidas até 2024 usam informação posterior às primeiras origens, uma limitação do exercício.',
'Comparamos tudo contra HOUSTNSA. A rota ajustada exige dividir por 12 e recompor o fator mensal. O SARIMA erra menos; os intervalos ainda omitem fontes de incerteza.',
'Recomendamos SARIMA como benchmark do total mensal bruto pelo menor erro. A recomendação é condicionada às ressalvas de ARCH, diferenciação e seleção histórica.',
'Os grandes movimentos se agrupam. O teste ARCH rejeita fortemente variância sem dependência temporal. Isso justifica modelar volatilidade, sem implicar previsão do sinal do retorno.',
'Gamma negativo indica maior impacto de choques negativos. O EGARCH melhora o ajuste e os testes usuais, mas restam ressalvas de cauda e sensibilidade do teste de assimetria.',
'Ambos têm persistência elevada. No GARCH ela se refere à variância; no EGARCH, à log-variância. Portanto as meias-vidas não medem exatamente a mesma grandeza.',
'As curvas mostram medianas e quantis. No EGARCH-t estimado, a variância esperada futura não é finita a partir de dois passos. Para essa medida de risco, usamos GARCH como referência.'
]
def tx(s):
 s=str(s).replace('“','``').replace('”',"''")
 s=str(s).replace('–','-').replace('—','-').replace('−','-').replace('·',r'@@DOT@@')
 trans={'&':r'\&','%':r'\%','$':r'\$','#':r'\#','_':r'\_','{':r'\{','}':r'\}','^':r'\textasciicircum{}'}
 s=''.join(trans.get(c,c) for c in s)
 for c,v in {'σ':r'\sigma','θ':r'\theta','φ':r'\phi','α':r'\alpha','β':r'\beta','γ':r'\gamma','Δ':r'\Delta','≥':r'\geq','≤':r'\leq','×':r'\times','÷':r'\div','≈':r'\approx'}.items():s=s.replace(c,'$'+v+'$')
 su=str.maketrans('⁰¹²³⁴⁵⁶⁷⁸⁹⁻','0123456789-');sub=str.maketrans('₀₁₂₃₄₅₆₇₈₉ₜ','0123456789t')
 s=re.sub('[⁰¹²³⁴⁵⁶⁷⁸⁹⁻]+',lambda m:r'\textsuperscript{'+m[0].translate(su)+'}',s)
 s=re.sub('[₀₁₂₃₄₅₆₇₈₉ₜ]+',lambda m:r'\textsubscript{'+m[0].translate(sub)+'}',s)
 return s.replace('@@DOT@@',r'\,\textperiodcentered\,').replace('\n',r'\\ ')
def font(n):return rf'\fontsize{{{n:.2f}}}{{{n*1.18:.2f}}}\selectfont '
def node(x,y,w,t,size=18,bold=False,color='ink'):
 return rf'\node[anchor=north west,inner sep=0pt,text width={w:.2f}pt,align=left,text={color}] at ([xshift={x:.2f}pt,yshift=-{y:.2f}pt]current page.north west) {{{font(size)}'+(r'\bfseries ' if bold else '')+tx(t)+'};\n'
def pos(e):
 xf=e.find('p:spPr/a:xfrm',NS) if e.tag.endswith('sp') else e.find('p:xfrm',NS)
 a=xf.find('a:off',NS);b=xf.find('a:ext',NS)
 return [int(a.get('x'))/12700,int(a.get('y'))/12700,int(b.get('cx'))/12700,int(b.get('cy'))/12700]
def paragraphs(e):return '\n'.join(''.join(p.itertext()) if False else ''.join(t.text or '' for t in p.findall('.//a:t',NS)) for p in e.findall('.//a:p',NS))
def style(e):
 r=e.find('.//a:rPr',NS)
 if r is None:r=e.find('.//a:defRPr',NS)
 return (float(r.get('sz','1800'))/100,r.get('b')=='1') if r is not None else (18,False)
def scaled(y,h):return (90+(y-90)*.84,h*.84)
def numeric(e,path):
 a=e.find(path,NS)
 if a is None:return []
 pts=a.findall('.//c:pt',NS)
 return [float(p.find('c:v',NS).text) for p in sorted(pts,key=lambda p:int(p.get('idx')))]
def plot(e,x,y,w,h):
 title=''.join(t.text or '' for t in e.findall('c:chart/c:title//a:t',NS))
 area=e.find('c:chart/c:plotArea',NS)
 chart=next(z for z in area if z.tag.endswith('Chart'))
 kind=chart.tag.split('}')[-1];series=chart.findall('c:ser',NS)
 isbar=kind=='barChart'; scatter=kind=='scatterChart'
 small=h<165;fs=9 if small else 11
 legend=e.find('c:chart/c:legend',NS) is not None and len(series)>1
 out=node(x+13,y,w-25,title,12 if small else 15,True)
 axx=x+34;axy=y+29;aw=w-51;ah=h-58-(22 if legend else 0)
 if ah<44:ah=44
 opts=[f'width={aw:.2f}pt',f'height={ah:.2f}pt','scale only axis','anchor=north west',rf'at={{([xshift={axx:.2f}pt,yshift=-{axy:.2f}pt]current page.north west)}}','axis lines=left','axis line style={black!35}','tick style={black!30}','ymajorgrids=true','grid style={black!12}','scaled ticks=false',r'xticklabel style={font='+font(fs)+r',/pgf/number format/1000 sep={}}',r'yticklabel style={font='+font(fs)+r',/pgf/number format/1000 sep={}}','enlarge x limits=false','clip=true']
 axes=area.findall('c:valAx',NS)+area.findall('c:catAx',NS)
 for a in axes:
  ap=a.find('c:axPos',NS);axis='x' if ap is not None and ap.get('val') in ['b','t'] else 'y'
  for k in ['min','max']:
   v=a.find('c:scaling/c:'+k,NS)
   if v is not None:opts.append(axis+k+'='+v.get('val'))
  v=a.find('c:majorUnit',NS)
  if v is not None:opts.append(axis+'tick distance='+v.get('val'))
 cats=[];cat=series[0].find('c:cat',NS) if series else None
 if cat is not None:cats=[p.find('c:v',NS).text or '' for p in cat.findall('.//c:pt',NS)]
 if not scatter and cats:
  step=1 if len(cats)<=12 else 3 if len(cats)<=36 else 20
  inds=list(range(0,len(cats),step));opts+=['xmin=0','xmax='+str(len(cats)-1),'xtick={'+','.join(map(str,inds))+'}','xticklabels={'+','.join('{'+tx(cats[i])+'}' for i in inds)+'}']
 if isbar:opts+=['ybar',f'bar width={max(1.3,aw/max(1,len(cats))*0.57/len(series)):.2f}pt']
 if legend:opts+=['legend style={at={(0.5,-0.24)},anchor=north,draw=none,font='+font(9)+',/tikz/every even column/.append style={column sep=6pt}}','legend columns='+str(min(4,len(series)))]
 if 'Raízes' in title:opts.append('axis equal image')
 opts=[o for o in opts if not o.startswith('at=')]
 out+=rf'\coordinate (chartanchor) at ([xshift={axx:.2f}pt,yshift=-{axy:.2f}pt]current page.north west);'+'\n'
 opts.append('at={(chartanchor)}')
 out+='\\begin{axis}['+','.join(opts)+']\n'
 for j,se in enumerate(series):
  vals=numeric(se,'c:yVal' if scatter else 'c:val');xx=numeric(se,'c:xVal') if scatter else list(range(len(vals)))
  clr=se.find('c:spPr/a:solidFill/a:srgbClr',NS);color=clr.get('val') if clr is not None else ['246294','CE792D','A8B6C3'][j%3]
  cname='plotcolor'+str(j);out+=rf'\definecolor{{{cname}}}{{HTML}}{{{color}}}'+'\n'
  op=[cname,'line width=0.7pt','mark=none']
  if isbar:op+=['fill='+cname,'draw=none']
  if len(vals)==1:op=['only marks','mark=*','mark size=3.5pt',cname]
  if len(vals)>200:op[1]='line width=0.45pt'
  coords=' '.join(f'({a:.8f},{b:.8f})' for a,b in zip(xx,vals))
  out+='\\addplot['+','.join(op)+'] coordinates {'+coords+'};\n'
  if legend:
   name=se.find('c:tx/c:v',NS);text=name.text if name is not None else 'Série '+str(j+1)
   out+='\\addlegendentry{'+tx(text)+'}\n'
 return out+'\\end{axis}\n'
header=r'''\documentclass{article}
\usepackage[T1]{fontenc}\usepackage{lmodern}\usepackage{amsmath,amssymb,textcomp}
\usepackage[paperwidth=960pt,paperheight=540pt,margin=0pt]{geometry}
\usepackage{tikz,pgfplots,xcolor}\pgfplotsset{compat=1.18}
\definecolor{ink}{HTML}{18232B}\definecolor{muted}{HTML}{505B64}\definecolor{accent}{HTML}{27465D}
\pagestyle{empty}\setlength{\parindent}{0pt}
\begin{document}
'''
parts=[header]
with zipfile.ZipFile(W/'output/apresentacao/Econometria_32slides_Pergunta_Resposta.pptx') as z:
 for n in range(1,33):
  root=E.fromstring(z.read(f'ppt/slides/slide{n}.xml'));tree=root.find('p:cSld/p:spTree',NS);idx=(n-1)//2
  parts.append(r'\null\begin{tikzpicture}[remember picture,overlay]'+'\n')
  if n%2:
   texts=[paragraphs(e) for e in tree.findall('p:sp',NS)]
   label=texts[0];en=texts[1]
   parts.append(node(48,42,865,label,21,True,'accent'))
   parts.append(node(48,117,865,en,24 if len(en.split())>65 else 27))
   parts.append(node(48,411,865,'Resumo da pergunta',17,True,'accent'))
   parts.append(node(48,439,865,summaries[idx],19))
  else:
   rel=E.fromstring(z.read(f'ppt/slides/_rels/slide{n}.xml.rels'));relations={r.get('Id'):r.get('Target').lstrip('/') for r in rel}
   for el in tree:
    if el.tag.endswith('sp'):
     t=paragraphs(el);x,y,w,h=pos(el)
     if t.isdigit():continue
     size,bold=style(el)
     if y<80:
      parts.append(node(x,24,w,t,25,True))
     else:
      y,h=scaled(y,h);parts.append(node(x,y,w,t,min(23,size*.87),bold,'ink' if bold else 'muted'))
    elif el.tag.endswith('graphicFrame'):
     x,y,w,h=pos(el);y,h=scaled(y,h);tbl=el.find('.//a:tbl',NS)
     if tbl is not None:
      widths=[int(c.get('w'))/12700 for c in tbl.findall('a:tblGrid/a:gridCol',NS)]
      rows=tbl.findall('a:tr',NS);cury=y
      for ri,row in enumerate(rows):
       rh=int(row.get('h'))/12700*.84;cells=row.findall('a:tc',NS)
       lines=max(max(1,paragraphs(c).count('\n')+1) for c in cells)
       fs=min(17,style(cells[0])[0]*.87);rh=max(rh,lines*fs*1.1+10)
       if ri==0:parts.append(rf'\fill[black!6] ([xshift={x:.2f}pt,yshift=-{cury:.2f}pt]current page.north west) rectangle ++({w:.2f}pt,-{rh:.2f}pt);'+'\n')
       curx=x
       for ci,c in enumerate(cells):parts.append(node(curx+6,cury+5,widths[ci]-12,paragraphs(c),fs,ri==0));curx+=widths[ci]
       parts.append(rf'\draw[black!25,line width=.35pt] ([xshift={x:.2f}pt,yshift=-{cury+rh:.2f}pt]current page.north west) -- ++({w:.2f}pt,0);'+'\n');cury+=rh
     else:
      ch=el.find('.//c:chart',NS)
      if ch is not None:parts.append(plot(E.fromstring(z.read(relations[ch.get('{'+NS['r']+'}id')])),x,y,w,h))
   parts.append(r'\draw[black!25,line width=.4pt] ([xshift=40pt,yshift=-476pt]current page.north west) -- ++(880pt,0);'+'\n')
   parts.append(node(42,485,860,'Sugestão de fala: '+hints[idx],15,False,'muted'))
  parts.append(node(918,520,30,str(n),10,color='muted'))
  parts.append(r'\end{tikzpicture}\newpage'+'\n')
parts.append(r'\end{document}')
(OUT/'apresentacao.tex').write_text(''.join(parts),encoding='utf-8')
(OUT/'roteiro.json').write_text(json.dumps({'resumos':summaries,'falas':hints},ensure_ascii=False,indent=2),encoding='utf-8')
print(OUT/'apresentacao.tex')
