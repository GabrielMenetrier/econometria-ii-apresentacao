exec(open(__file__.replace('complemento_3a.py','questao_3a.py'),encoding='utf-8').read().split('orders=')[0])
from statsmodels.tsa.arima.model import ARIMAResults
rows=[]
for p,q,P,Q in [(1,0,0,1),(2,0,0,1),(1,1,0,1)]:
    y=trans['diff12'];f=ARIMA(y,order=(p,0,q),seasonal_order=(P,0,Q,12),trend='n',concentrate_scale=True).fit(cov_type='oim',method_kwargs={'maxiter':2000,'pgtol':1e-9,'factr':1e3})
    lb=acorr_ljungbox(f.resid,lags=[12,24,36],model_df=p+q+P+Q)
    r=dict(modelo=f'SARIMA({p},0,{q})({P},1,{Q})12',AIC=f.aic,BIC=f.bic,N=len(y),converged=bool(f.mle_retvals['converged']),min_AR=min(abs(f.arroots)),params=dict(f.params))
    for lag in [12,24,36]:r[f'p_Q{lag}']=lb.loc[lag,'lb_pvalue']
    rows.append(r)
pd.DataFrame(rows).to_csv(OUT/'sensibilidade_d0_D1.csv',index=False);print(rows)
f=ARIMAResults.load(OUT/'modelos/011_011.pickle');e=np.asarray(f.resid);a=acf(e,nlags=48,fft=False)
print('ESCOLHIDO',f.params,f.bse,'FAC excedentes',[(i,float(v)) for i,v in enumerate(a) if i and abs(v)>1.96/np.sqrt(len(e))],flush=True)
from scipy.stats import chi2
for lag in [12,24,36]:
    Q=len(e)*(len(e)+2)*sum(a[k]**2/(len(e)-k) for k in range(1,lag+1))
    lb=acorr_ljungbox(e,lags=[lag],model_df=2)
    assert np.isclose(Q,lb.loc[lag,'lb_stat']) and np.isclose(chi2.sf(Q,lag-2),lb.loc[lag,'lb_pvalue'])
fig,axes=plt.subplots(2,1,figsize=(11,7))
axes[0].plot(w.index,e,lw=1);axes[0].axhline(0,color='black',lw=.5);axes[0].set_title('Resíduos — SARIMA(0,1,1)(0,1,1)₁₂');axes[0].set_ylabel('Mil unidades')
axes[1].stem(range(1,49),a[1:],basefmt=' ');axes[1].axhline(0,color='black',lw=.5)
for sign in [-1,1]:axes[1].axhline(sign*1.96/np.sqrt(len(e)),color='gray',ls='--')
axes[1].set_title('FAC residual — bandas pontuais aproximadas de 95%');axes[1].set_xticks([1,6,12,18,24,30,36,42,48]);axes[1].set_xlabel('Defasagem em meses')
fig.tight_layout();fig.savefig(OUT/'graficos/modelo_escolhido.png',dpi=170);fig.savefig(OUT/'graficos/modelo_escolhido.svg')
pd.DataFrame({'data':w.index,'residuo':e}).to_csv(OUT/'residuos_escolhido.csv',index=False)
(OUT/'modelos/escolhido_resumo.txt').write_text(str(f.summary()),encoding='utf-8')
