exec(open(__file__.replace('parte2_d.py','parte2_b.py'),encoding='utf-8').read().split('rows=[]')[0])
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
OUT=BASE/'item_d';(OUT/'graficos').mkdir(parents=True,exist_ok=True)
with (BASE/'item_c/modelos/AR0_GARCH11_t.pickle').open('rb') as file:g=pickle.load(file)
with (BASE/'item_b/modelos/AR0_EGARCH111_t.pickle').open('rb') as file:e=pickle.load(file)
assert r.index[-1]==pd.Timestamp('2025-12-31')
dates=pd.bdate_range('2026-01-01','2026-01-23').difference(pd.to_datetime(['2026-01-01','2026-01-19']));assert len(dates)==15
B=200000;rows=[];audit={}
for name,f,seed in [('GARCH',g,20260101),('EGARCH',e,20260102)]:
 p=f.params;nu=p['nu'];omega=p['omega'];alpha=p['alpha[1]'];beta=p['beta[1]'];rng=np.random.default_rng(seed)
 lastvar=float(f.conditional_volatility.iloc[-1]**2);lasteps=float(f.resid.iloc[-1]);lastz=lasteps/np.sqrt(lastvar)
 first=omega+alpha*lasteps**2+beta*lastvar if name=='GARCH' else np.exp(omega+alpha*(abs(lastz)-np.sqrt(2/np.pi))+p['gamma[1]']*lastz+beta*np.log(lastvar))
 official=float(f.forecast(horizon=1,reindex=False).residual_variance.iloc[-1,0]);assert np.isclose(first,official,rtol=1e-8)
 v=np.full(B,first);vols=np.empty((B,15));analytic=f.forecast(horizon=15,reindex=False).residual_variance.iloc[-1].to_numpy() if name=='GARCH' else None
 for h in range(15):
  if h:
   z=rng.standard_t(nu,size=B)*np.sqrt((nu-2)/nu)
   v=omega+(alpha*z*z+beta)*v if name=='GARCH' else np.exp(omega+alpha*(np.abs(z)-np.sqrt(2/np.pi))+p['gamma[1]']*z+beta*np.log(v))
  vols[:,h]=np.sqrt(v)
  qs=np.quantile(vols[:,h],[.05,.5,.95]);rows.append(dict(modelo=name,horizonte=h+1,data=dates[h],sigma_q05=qs[0],sigma_mediana=qs[1],sigma_q95=qs[2],sigma_mediana_anualizada=qs[1]*np.sqrt(252),raiz_variancia_esperada=np.sqrt(analytic[h]) if analytic is not None else (np.sqrt(first) if h==0 else None)))
 audit[name]={'seed':seed,'B':B,'ultimo_sigma':np.sqrt(lastvar),'ultimo_residuo':lasteps,'primeira_variancia':first,'diferenca_mediana_15_metades':float(np.median(vols[:B//2,-1])-np.median(vols[B//2:,-1])),'parametros':p.to_dict()}
 if name=='GARCH':audit[name]['raiz_media_variancia_simulada15']=float(np.sqrt(np.mean(vols[:,-1]**2)))
result=pd.DataFrame(rows);result.to_csv(OUT/'previsoes_15_pregoes.csv',index=False);(OUT/'metodologia.json').write_text(json.dumps(audit,indent=2),encoding='utf-8')
fig,axes=plt.subplots(1,2,figsize=(13,5),sharey=True)
for ax,(name,df) in zip(axes,result.groupby('modelo',sort=False)):
 x=df.horizonte;ax.fill_between(x,df.sigma_q05,df.sigma_q95,alpha=.2,label='Quantis 5%–95% da volatilidade futura');ax.plot(x,df.sigma_mediana,marker='o',label='Mediana prevista')
 if name=='GARCH':ax.plot(x,df.raiz_variancia_esperada,ls='--',label='Raiz da variância esperada')
 ax.set_title(name+' com inovações t');ax.set_xlabel('Horizonte em pregões');ax.set_xticks([1,5,10,15]);ax.legend(fontsize=8);ax.grid(alpha=.2)
axes[0].set_ylabel('Volatilidade diária (p.p. de log-retorno)');fig.suptitle('Origem: 31/12/2025 — 02/01/2026 a 23/01/2026');fig.tight_layout();fig.savefig(OUT/'graficos/previsoes_volatilidade.png',dpi=170);fig.savefig(OUT/'graficos/previsoes_volatilidade.svg')
print(result.to_string(index=False));print(json.dumps(audit,indent=2))
