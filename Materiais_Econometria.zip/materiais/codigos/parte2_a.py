from pathlib import Path
import sys,os,json,hashlib
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parents[1];sys.path.append(str(ROOT/'.dependencias'));sys.stdout.reconfigure(encoding='utf-8')
os.environ['MPLCONFIGDIR']=str(ROOT/'.cache_matplotlib')
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.stats import skew,kurtosis,jarque_bera,chi2,norm
from statsmodels.stats.diagnostic import het_arch,acorr_ljungbox
from statsmodels.tsa.stattools import acf
BASE=ROOT/'parte_2_garch';OUT=BASE/'item_a';(OUT/'graficos').mkdir(parents=True,exist_ok=True)
raw=BASE/'dados/GSPC_yahoo_bruto.json';j=json.loads(raw.read_text());z=j['chart']['result'][0]
dates=pd.to_datetime(z['timestamp'],unit='s',utc=True).tz_convert('America/New_York').tz_localize(None).normalize()
prices=pd.DataFrame(z['indicators']['quote'][0],index=dates);prices['adjclose']=z['indicators']['adjclose'][0]['adjclose'];prices.index.name='data'
assert not prices.index.duplicated().any();assert prices.close.notna().all() and (prices.close>0).all()
prices=prices.sort_index();prices['log_retorno']=np.log(prices.close).diff();prices['retorno_log_pct']=100*prices.log_retorno
sample=prices.loc['2020-01-01':'2025-12-31'].copy();assert sample.retorno_log_pct.notna().all()
assert prices.loc['2019-12-31','close']>0
prices.to_csv(BASE/'dados/GSPC_cotacoes_com_base.csv');sample.to_csv(BASE/'dados/GSPC_retornos_2020_2025.csv')
r=sample.retorno_log_pct;e=r-r.mean();N=len(r)
stats={'N':N,'inicio':str(r.index.min().date()),'fim':str(r.index.max().date()),'media_pct':r.mean(),'mediana_pct':r.median(),'desvio_padrao_pct':r.std(ddof=1),'variancia_pp2':r.var(ddof=1),'min_pct':r.min(),'data_min':str(r.idxmin().date()),'max_pct':r.max(),'data_max':str(r.idxmax().date()),'q01_pct':r.quantile(.01),'q25_pct':r.quantile(.25),'q75_pct':r.quantile(.75),'q99_pct':r.quantile(.99),'assimetria':skew(r,bias=False),'curtose_Pearson':kurtosis(r,fisher=False,bias=False),'excesso_curtose':kurtosis(r,fisher=True,bias=False),'JB':jarque_bera(r).statistic,'JB_p':jarque_bera(r).pvalue,'vol_anualizada_pct':r.std(ddof=1)*np.sqrt(252)}
(OUT/'estatisticas.json').write_text(json.dumps(stats,indent=2),encoding='utf-8')
tests=[]
# Controle de sensibilidade: retirar também uma média AR(5), sem selecionar GARCH neste item.
rr=np.asarray(r);X=np.column_stack([np.ones(N-5)]+[rr[5-k:N-k] for k in range(1,6)]);beta=np.linalg.lstsq(X,rr[5:],rcond=None)[0];ear=rr[5:]-X@beta
for label,resid in [('media_constante',np.asarray(e)),('media_AR5_sensibilidade',ear)]:
    for lag in [1,5,10,20]:
        lm,p,f,fp=het_arch(resid,nlags=lag,ddof=0)
        sq=resid**2;Y=sq[lag:];XX=np.column_stack([np.ones(len(Y))]+[sq[lag-k:len(sq)-k] for k in range(1,lag+1)])
        b=np.linalg.lstsq(XX,Y,rcond=None)[0];R2=1-np.sum((Y-XX@b)**2)/np.sum((Y-Y.mean())**2)
        assert np.isclose(lm,len(Y)*R2) and np.isclose(p,chi2.sf(lm,lag))
        tests.append(dict(media=label,defasagens=lag,N_residuos=len(resid),N_auxiliar=len(Y),R2=R2,LM=lm,gl=lag,p_valor=p,F=f,p_F=fp))
pd.DataFrame(tests).to_csv(OUT/'teste_ARCH_LM.csv',index=False)
lb=acorr_ljungbox(e,lags=[5,10,20],model_df=0);lb.to_csv(OUT/'ljung_box_retornos.csv')
fig,axes=plt.subplots(3,1,figsize=(12,10),sharex=True)
axes[0].plot(sample.index,sample.close,color='#234e70');axes[0].set_title('S&P 500 (^GSPC) — fechamento');axes[0].set_ylabel('Pontos')
axes[1].plot(r.index,r,lw=.65,color='#234e70');axes[1].axhline(0,color='black',lw=.5);axes[1].set_title('Log-retornos diários');axes[1].set_ylabel('% log')
axes[2].plot(r.index,r.rolling(21).std()*np.sqrt(252),color='#b24e28');axes[2].set_title('Volatilidade histórica: desvio-padrão móvel de 21 pregões × √252');axes[2].set_ylabel('% ao ano (aprox.)')
fig.tight_layout();fig.savefig(OUT/'graficos/serie_retornos_volatilidade.png',dpi=170);fig.savefig(OUT/'graficos/serie_retornos_volatilidade.svg');plt.close(fig)
fig,axes=plt.subplots(1,3,figsize=(15,4.5));axes[0].hist(r,bins=65,density=True,alpha=.6,color='#234e70');x=np.linspace(r.min(),r.max(),500);axes[0].plot(x,norm.pdf(x,r.mean(),r.std()),color='#b24e28',label='Normal com mesma média/desvio');axes[0].set_title('Distribuição dos log-retornos');axes[0].set_xlabel('% log');axes[0].legend(fontsize=8)
arows=[]
for ax,values,label in [(axes[1],e,'FAC dos retornos centrados'),(axes[2],e**2,'FAC dos resíduos ao quadrado')]:
    a=acf(values,nlags=30,fft=False);ax.stem(range(1,31),a[1:],basefmt=' ')
    for sign in [-1,1]:ax.axhline(sign*1.96/np.sqrt(N),color='gray',ls='--')
    ax.set_title(label);ax.set_xlabel('Defasagem em pregões')
    for lag in range(31):arows.append(dict(serie=label,lag=lag,FAC=a[lag]))
fig.tight_layout();fig.savefig(OUT/'graficos/distribuicao_fac.png',dpi=170);fig.savefig(OUT/'graficos/distribuicao_fac.svg');plt.close(fig)
pd.DataFrame(arows).to_csv(OUT/'fac.csv',index=False)
meta={'ticker':'^GSPC','fonte':'Yahoo Finance chart API','url':'https://query1.finance.yahoo.com/v8/finance/chart/%5EGSPC?period1=1577750400&period2=1767312000&interval=1d','processado_UTC':datetime.now(timezone.utc).isoformat(),'sha256':hashlib.sha256(raw.read_bytes()).hexdigest(),'campo':'close','base_retorno_inicial':'2019-12-31','n_pregoes_por_ano':{str(k):int(v) for k,v in sample.groupby(sample.index.year).size().items()},'close_adjclose_max_diferenca':float(abs(sample.close-sample.adjclose).max()),'ARCH_convencao':'LM=n_auxiliar*R2; ddof=0; chi-quadrado com q graus; principal q=5, sensibilidades 1,10,20','media_AR5_coeficientes':beta.tolist()}
(BASE/'dados/metadados.json').write_text(json.dumps(meta,indent=2),encoding='utf-8')
print(json.dumps(stats,indent=2));print(pd.DataFrame(tests).to_string(index=False));print(lb);print(meta['n_pregoes_por_ano'])
