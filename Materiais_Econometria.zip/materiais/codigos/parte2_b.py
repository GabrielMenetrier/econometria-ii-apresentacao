from pathlib import Path
import sys,os,json,pickle,warnings
ROOT=Path(__file__).resolve().parents[1];sys.path.append(str(ROOT/'.dependencias'));sys.stdout.reconfigure(encoding='utf-8');os.environ['MPLCONFIGDIR']=str(ROOT/'.cache_matplotlib')
import numpy as np
import pandas as pd
from arch import arch_model
from statsmodels.stats.diagnostic import acorr_ljungbox,het_arch
from scipy.stats import jarque_bera,chi2
import statsmodels.api as sm
BASE=ROOT/'parte_2_garch';OUT=BASE/'item_b';(OUT/'modelos').mkdir(parents=True,exist_ok=True)
r=pd.read_csv(BASE/'dados/GSPC_retornos_2020_2025.csv',index_col=0,parse_dates=True).retorno_log_pct
rows=[];coefs=[];audit=[]
for lags in [0,1,5]:
 for dist in ['normal','t']:
  for o in [0,1]:
   label=f'AR{lags}_EGARCH1{o}1_{dist}'
   m=arch_model(r,mean='Constant' if lags==0 else 'AR',lags=lags if lags else None,vol='EGARCH',p=1,o=o,q=1,dist=dist,hold_back=5,rescale=False)
   with warnings.catch_warnings(record=True) as ws:
    warnings.simplefilter('always');f=m.fit(disp='off',cov_type='robust',options={'maxiter':3000,'ftol':1e-10})
   audit.append(dict(modelo=label,converged=f.convergence_flag==0,warnings=[str(w.message) for w in ws]))
   if f.convergence_flag!=0:raise RuntimeError(label)
   with (OUT/'modelos'/f'{label}.pickle').open('wb') as file:pickle.dump(f,file)
   z=f.std_resid.dropna();assert len(z)==1503
   lb=acorr_ljungbox(z,lags=[5,10,20],model_df=0);lb2=acorr_ljungbox(z*z,lags=[5,10,20],model_df=0)
   row=dict(modelo=label,lags=lags,dist=dist,o=o,N=f.nobs,AIC=f.aic,BIC=f.bic,llf=f.loglikelihood,JB=jarque_bera(z).statistic,JB_p=jarque_bera(z).pvalue)
   for h in [5,10,20]:
    row[f'LB_z_{h}_p']=lb.loc[h,'lb_pvalue'];row[f'LB_z2_{h}_p']=lb2.loc[h,'lb_pvalue'];row[f'ARCH_{h}_p']=het_arch(z,nlags=h,ddof=0)[1]
   # Engle-Ng style joint sign/size bias, standardized lagged shock convention.
   prev=np.asarray(z)[:-1];Y=np.asarray(z)[1:]**2;neg=(prev<0).astype(float);X=np.column_stack([np.ones(len(prev)),neg,neg*prev,(1-neg)*prev])
   aux=sm.OLS(Y,X).fit();row['sign_size_LM']=len(Y)*aux.rsquared;row['sign_size_p']=chi2.sf(row['sign_size_LM'],3)
   robust=sm.OLS(Y,X).fit(cov_type='HC3');wt=robust.wald_test(np.column_stack([np.zeros(3),np.eye(3)]),scalar=True);row['sign_size_HC3_p']=float(wt.pvalue)
   rows.append(row)
   for name in f.params.index:coefs.append(dict(modelo=label,parametro=name,valor=f.params[name],erro_padrao_robusto=f.std_err[name],t=f.tvalues[name],p=f.pvalues[name]))
   print(label,round(f.aic,2),round(f.bic,2),'LBz20',round(row['LB_z_20_p'],4),'LBz2',round(row['LB_z2_20_p'],4),'ARCH20',round(row['ARCH_20_p'],4),'bias',round(row['sign_size_p'],4),flush=True)
pd.DataFrame(rows).sort_values('BIC').to_csv(OUT/'comparacao.csv',index=False);pd.DataFrame(coefs).to_csv(OUT/'coeficientes.csv',index=False)
(OUT/'otimizacao.json').write_text(json.dumps(audit,indent=2),encoding='utf-8')
