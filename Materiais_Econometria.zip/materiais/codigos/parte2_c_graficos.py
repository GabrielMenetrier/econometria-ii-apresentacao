exec(open(__file__.replace('parte2_c_graficos.py','parte2_b.py'),encoding='utf-8').read().split('rows=[]')[0])
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
OUT=BASE/'item_c';(OUT/'graficos').mkdir(exist_ok=True)
with (OUT/'modelos/AR0_GARCH11_t.pickle').open('rb') as file:g=pickle.load(file)
with (BASE/'item_b/modelos/AR0_EGARCH111_t.pickle').open('rb') as file:e=pickle.load(file)
check=g.model.fit(starting_values=g.params,disp='off',options={'maxiter':3000,'ftol':1e-10});assert check.convergence_flag==0 and abs(check.loglikelihood-g.loglikelihood)<1e-5
rho=g.params['alpha[1]']+g.params['beta[1]'];beta=e.params['beta[1]'];h=np.arange(101)
fig,ax=plt.subplots(2,1,figsize=(11,8))
ax[0].plot(g.conditional_volatility,label='GARCH(1,1)-t',lw=.9);ax[0].plot(e.conditional_volatility,label='EGARCH assimétrico-t',lw=.9,alpha=.85);ax[0].set_ylabel('Volatilidade diária (p.p.)');ax[0].legend();ax[0].set_title('Volatilidades condicionais estimadas — média constante')
ax[1].plot(h,rho**h,label='GARCH: desvio da variância esperada');ax[1].plot(h,beta**h,label='EGARCH: perturbação na log-variância');ax[1].axhline(.5,color='gray',ls='--');ax[1].set_xlabel('Pregões após a perturbação');ax[1].set_ylabel('Persistência relativa, início = 1');ax[1].legend();ax[1].set_title('Decaimento nas respectivas escalas — não são respostas na mesma unidade')
fig.tight_layout();fig.savefig(OUT/'graficos/comparacao_persistencia.png',dpi=170);fig.savefig(OUT/'graficos/comparacao_persistencia.svg')
pd.DataFrame({'GARCH_sigma':g.conditional_volatility,'EGARCH_sigma':e.conditional_volatility}).to_csv(OUT/'volatilidades.csv')
