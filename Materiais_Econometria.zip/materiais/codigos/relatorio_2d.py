"""Consolida o caminho de diagnóstico já calculado por questao_2d.py."""
from pathlib import Path
import sys
import json
sys.stdout.reconfigure(encoding='utf-8')
ROOT=Path(__file__).resolve().parents[1]
sys.path.append(str(ROOT/'.dependencias'))
import pandas as pd
import numpy as np
from statsmodels.tsa.arima.model import ARIMAResults
OUT=ROOT/'questao_2d'
d=pd.read_csv(OUT/'comparacao_diagnosticos.csv')
tests=pd.read_csv(OUT/'testes_residuos.csv')
initial=d[d.modelo=='ARIMA(0,1,1) sem drift'].iloc[0]
alternative=d[d.modelo=='ARIMA(2,1,3) sem drift'].iloc[0]
fit=ARIMAResults.load(OUT/'modelos/arima_2_1_3_sem_drift.pickle')
roots=[]
for label,values in [('AR',fit.arroots),('MA',fit.maroots)]:
    for z in values:
        roots.append({'polinomio':label,'real':z.real,'imaginaria':z.imag,'modulo':abs(z),'inversa_real':(1/z).real,'inversa_imaginaria':(1/z).imag})
pd.DataFrame(roots).to_csv(OUT/'raizes_alternativa_213.csv',index=False,float_format='%.12g')
def f(v,digits=3):
    return f'{v:,.{digits}f}'.replace(',','_').replace('.',',').replace('_','.')
def pv(v):
    return f'{v:.3e}'.replace('.',',') if v<.0001 else f(v,4)
def diagnostic_table(rows):
    lines=['| Modelo | AIC | BIC | p LB(6) | p LB(12) | p LB(24) | p ARCH(12) |',
           '|:--|--:|--:|--:|--:|--:|--:|']
    for _,r in rows.iterrows():
        lines.append('| '+r.modelo+' | '+ ' | '.join([f(r.AIC,2),f(r.BIC,2)]+[pv(r[k]) for k in ['p_Q6','p_Q12','p_Q24','p_ARCH12']])+' |')
    return '\n'.join(lines)
lb=['| Defasagem h | Q de Ljung–Box | Graus de liberdade h−1 | p-valor | Decisão a 5% |',
    '|:--|--:|--:|--:|:--|']
arch=['| Defasagens no ARCH-LM | LM corrigido | Graus de liberdade | p-valor |',
      '|:--|--:|--:|--:|']
for h in [6,12,24]:
    lb.append(f'| {h} | {f(initial[f"Q{h}"])} | {h-1} | {pv(initial[f"p_Q{h}"])} | '+('Rejeita H₀' if initial[f'p_Q{h}']<.05 else 'Não rejeita H₀')+' |')
    arch.append(f'| {h} | {f(initial[f"ARCH{h}"])} | {h} | {pv(initial[f"p_ARCH{h}"])} |')
selected=d[d.modelo.isin(['ARIMA(0,1,1) sem drift','ARIMA(3,1,0) sem drift','ARIMA(1,1,1) sem drift','ARIMA(0,1,2) sem drift','ARIMA(2,1,3) sem drift'])]
new=d[d.etapa=='reidentificacao']
fulltable=diagnostic_table(d)
(OUT/'tabela_caminho_completo.md').write_text(fulltable+'\n',encoding='utf-8')
report=f'''# Questão 2(d) — Diagnóstico residual e retorno à identificação

## Conclusão e situação do modelo

**O ARIMA(0,1,1) sem drift não passa no diagnóstico completo convencional a 5%.** Os testes não rejeitam ausência de autocorrelação até 6 e 12 meses, mas rejeitam até 24 meses. O ARCH-LM rejeita ausência de efeitos ARCH.

Retornamos à identificação e examinamos **24 especificações**: as 12 da questão 2(b) e 12 extensões não sazonais. Nenhuma passou simultaneamente pelos Ljung–Box de 6, 12 e 24 meses e pelo ARCH-LM de 12 defasagens. Isso é um resultado da busca realizada, não uma prova de que nenhum ARIMA não sazonal possível funcionaria.

O ARIMA(0,1,1) sem drift pode ser preservado como **benchmark parcimonioso com inadequações documentadas**, pois continua com o menor BIC no conjunto ampliado. Ele não deve ser apresentado como modelo validado. O menor AIC ampliado pertence a uma solução ARIMA(2,1,3) numericamente próxima de uma fronteira e de cancelamento, sem resolver os problemas residuais; não a adotamos como substituta.

## Dados, resíduos e hipóteses

Mantivemos HOUST original, sem log e sem divisão por 12, com d=1 e sem termos sazonais. Todos os modelos usam a mesma amostra efetiva ΔHOUST de 1994M2 a 2024M12, N=371; 2025 não foi utilizado.

O resíduo e_t é o erro de previsão de um passo, em unidades de HOUST, devolvido pelo filtro do modelo estimado. É também o erro de previsão do nível de um passo, pois o nível anterior é conhecido. Todos os testes principais usam esses resíduos **não padronizados** e o mesmo vetor de 371 datas. Os resíduos padronizados também foram preservados; pequenas diferenças numéricas entre as versões decorrem principalmente da variância inicial do filtro.

Adotamos nível de significância de 5%. “Não rejeitar” não comprova a hipótese nula; “passar” é apenas uma abreviação para não encontrar rejeição nesses diagnósticos.

## Gráficos do modelo inicial

![Diagnóstico do ARIMA(0,1,1) sem drift](graficos/diagnostico_inicial.png)

A FAC dos resíduos mostra pouca dependência nos primeiros meses, mas há valores além das bandas pontuais de referência: aproximadamente −0,106 no lag 12, +0,149 no 13 e −0,139 no 24. O padrão remanescente em torno de defasagens anuais motiva atenção, sem demonstrar sozinho a causa ou um modelo sazonal específico.

A FAC dos resíduos ao quadrado e o desvio-padrão móvel de 24 meses mostram variação da dispersão e agrupamento de erros grandes. Os gráficos de resíduos não exibem apenas oscilações de tamanho constante. A média residual é {f(initial.media_residuo)} e o desvio-padrão amostral é {f(initial.desvio_residuo)}. A média pequena é uma descrição, não um teste formal de ausência de viés.

## Ljung–Box: dependência na média

H₀: as autocorrelações residuais das defasagens 1 até h são conjuntamente zero. A estatística é Q(h)=N(N+2)Σ[k=1,…,h] r_k²/(N−k). Não é um teste apenas da autocorrelação no lag h.

Para o modelo estimado, usamos a referência qui-quadrado com h−p−q graus de liberdade. No ARIMA(0,1,1), p+q=1, portanto os graus de liberdade são 5, 11 e 23. Não subtraímos d; não se trata de um coeficiente ARMA estimado. [Documentação Ljung–Box](https://www.statsmodels.org/stable/generated/statsmodels.stats.diagnostic.acorr_ljungbox.html).

{chr(10).join(lb)}

O Q(24) rejeita H₀: pelo diagnóstico convencional, há dependência temporal remanescente que o modelo não capturou. A não rejeição em 6 e 12 meses não garante que não exista dependência em horizontes maiores.

## ARCH-LM: dependência na variância

Usamos **12 defasagens como teste principal**, cobrindo um ano mensal, e 6 e 24 como sensibilidade. A regressão auxiliar inclui intercepto e os quadrados dos resíduos defasados:

e_t² = a₀ + a₁e_(t−1)² + … + a_me_(t−m)² + u_t.

H₀: a₁=…=a_m=0, isto é, ausência de efeitos ARCH até a ordem testada. A rejeição aponta previsibilidade nos resíduos ao quadrado, compatível com heterocedasticidade condicional.

Aplicamos a correção ddof=p+q recomendada para resíduos ARMA: LM=(N−m−p−q)R², com referência qui-quadrado de m graus de liberdade. Para o modelo inicial e m=12, a regressão auxiliar tem 359 observações e o multiplicador corrigido é 358. O LM convencional sem essa correção seria (N−m)R². [Documentação ARCH-LM](https://www.statsmodels.org/stable/generated/statsmodels.stats.diagnostic.het_arch.html).

{chr(10).join(arch)}

O resultado principal, **LM(12)={f(initial.ARCH12)} e p={pv(initial.p_ARCH12)}**, rejeita fortemente a ausência de ARCH. A conclusão se mantém nas ordens 6 e 24. Isso não demonstra que um GARCH particular seja o processo verdadeiro: autocorrelação não modelada, quebras de variância e observações extremas também podem afetar esse diagnóstico.

Como complemento, Jarque–Bera={f(initial.JB)}, p={pv(initial.p_JB)}, assimetria={f(initial.assimetria)} e curtose={f(initial.curtose)} indicam afastamento da normalidade gaussiana. Normalidade não é requisito para ausência de autocorrelação, mas a rejeição reforça a cautela com inferência e intervalos gaussianos. O JB não foi usado como critério adicional para forçar seleção.

## Caminho percorrido na reidentificação

1. **Modelo inicial:** o menor AIC/BIC da comparação original, ARIMA(0,1,1) sem drift, falhou em Q(24) e ARCH.
2. **Reavaliação das 12 especificações de 2(b):** todas falharam em Q(24) e no ARCH(12), inclusive versões com drift. Portanto, incluir drift ou escolher outra ordem já testada não resolveu.
3. **Expansão limitada:** estimamos as ordens adicionais (2,1,1), (1,1,2), (2,1,2), (3,1,1), (1,1,3), (3,1,2), (2,1,3), (0,1,3), (4,1,0), (5,1,0), (0,1,4) e (0,1,5), todas sem drift. As alternativas exploram maior memória AR e MA e combinações mistas, sem mudar variável, d, período ou restrição não sazonal. Limitamos p+q≤5 para manter positivos os graus de liberdade do Q(6) e evitar uma busca crescente guiada apenas por p-valores.
4. **Resultado:** nenhuma das 12 extensões passou em Q(24) ou ARCH(12). Aumentar p e q, nesse conjunto, não corrigiu a dependência residual e a variância.
5. **Exame da solução de menor AIC ampliado:** o ARIMA(2,1,3) ganhou apenas {f(initial.AIC-alternative.AIC,3)} ponto de AIC, piorou o BIC em {f(alternative.BIC-initial.BIC,3)} pontos e permaneceu inadequado. Não foi promovido a modelo final.

Comparação de modelos representativos:

{diagnostic_table(selected)}

O ARIMA(2,1,3) apresenta menor módulo de raiz AR de {f(alternative.raiz_AR_min,6)}, menor módulo de raiz MA de {f(alternative.raiz_MA_min,6)} e distância mínima entre raízes AR/MA de {f(alternative.distancia_AR_MA_min,6)}. Há quase cancelamento e uma raiz MA praticamente na fronteira de invertibilidade. Os erros-padrão MA são aproximadamente 9,19, 6,41 e 4,53, muito grandes relativamente às estimativas. Isso exemplifica o problema de identificação fraca discutido teoricamente em 2(c). Na alternativa, os testes e a inferência assintótica são especialmente frágeis por essa proximidade à fronteira.

![Diagnóstico da alternativa de menor AIC ampliado, não adotada](graficos/diagnostico_alternativa.png)

## Interpretação e limites

Menor AIC/BIC não garante resíduos adequados. O diagnóstico aponta dois problemas distintos: dependência residual da média e dependência na variância. Acrescentar termos AR/MA não é, por si só, um tratamento da heterocedasticidade.

Os p-valores apresentados são os convencionais solicitados. A presença de heterocedasticidade pode alterar a calibração do Ljung–Box usual, e uma média mal especificada pode contaminar o ARCH-LM; logo, não são provas isoladas da origem exata do problema. Ainda assim, em conjunto com os gráficos, não sustentam declarar o modelo plenamente adequado.

Não mudamos silenciosamente para log, não introduzimos termos sazonais nem eliminamos meses ou choques para obter aprovação. Não continuamos a aumentar ordens até encontrar um p-valor acima de 5%. A seleção e os testes pós-busca têm caráter exploratório.

**Conclusão para o trabalho:** retornamos à identificação e documentamos o fracasso das alternativas consideradas. Preservamos ARIMA(0,1,1) sem drift somente como benchmark parcimonioso não validado no diagnóstico completo. Nenhum modelo aprovado foi encontrado neste conjunto. Se a tarefa exigir corrigir a variância condicional, a próxima extensão seria modelá-la explicitamente (por exemplo ARCH/GARCH), após reexaminar a média; isso vai além do ARIMA homocedástico estimado aqui. Reexaminar a transformação e a possível dependência anual exigiria explicitar a mudança de especificação. Não foram estimadas essas extensões neste item.

## Comparação completa das 24 especificações

{fulltable}

## Reprodutibilidade e arquivos

- [Código dos testes e reidentificação](../codigos/questao_2d.py) e [geração deste relatório](../codigos/relatorio_2d.py).
- [Todos os testes, com estatísticas, graus de liberdade e p-valores](testes_residuos.csv).
- [Comparação completa](comparacao_diagnosticos.csv) e [tabela em Markdown](tabela_caminho_completo.md).
- [FAC residual e dos quadrados](fac_residuos.csv).
- [Coeficientes dos modelos destacados](coeficientes_modelos_destacados.csv) e [raízes da alternativa](raizes_alternativa_213.csv).
- [Metodologia](metodologia.json) e [registro de otimização](otimizacao.json).
- Modelos novos, resumos e resíduos na pasta modelos; gráficos em PNG e SVG.
- Verificações: Q recalculado pela fórmula; ARCH-LM conferido por regressão auxiliar independente; mesma amostra efetiva em todas as estimativas.
'''
(OUT/'resposta_questao_2d.md').write_text(report,encoding='utf-8')
print('\n'.join(lb));print('\n'.join(arch))
print('JB:',initial.JB,initial.p_JB)
print('Relatório salvo; modelos diagnosticados:',len(d),'aprovados:',int(d.passa_conjunto_5pct.sum()))
