from pathlib import Path
import sys, os, json, contextlib, time, pickle
ROOT=Path(__file__).resolve().parents[1]
sys.path.append(str(ROOT/'.dependencias'))
os.environ['MPLCONFIGDIR']=str(ROOT/'.cache_matplotlib')
sys.stdout.reconfigure(encoding='utf-8')
import numpy as np
import pandas as pd
import pmdarima as pm
from statsmodels.stats.diagnostic import acorr_ljungbox, het_arch
OUT=ROOT/'questao_2e'; OUT.mkdir(exist_ok=True)
s=pd.read_csv(ROOT/'dados/brutos/housing_fred_1994_2025_python.csv',parse_dates=['observation_date']).set_index('observation_date')['HOUST'].loc['1994-01-01':'2024-12-01'].asfreq('MS')
assert len(s)==372 and s.notna().all()
tests={'d_KPSS':pm.arima.ndiffs(s,test='kpss'), 'D_OCSB':pm.arima.nsdiffs(s,m=12,test='ocsb'), 'versao':pm.__version__}
(OUT/'testes_integracao.json').write_text(json.dumps(tests,indent=2))
print(tests,flush=True)
rows=[]
for name,seasonal in [('nao_sazonal',False),('sazonal',True)]:
    start=time.time()
    with (OUT/(name+'_trace.txt')).open('w',encoding='utf-8') as log, contextlib.redirect_stdout(log),contextlib.redirect_stderr(log):
        fits=pm.auto_arima(s,d=None,D=None,m=12 if seasonal else 1,seasonal=seasonal,start_p=2,start_q=2,max_p=5,max_q=5,start_P=1,start_Q=1,max_P=2,max_Q=2,max_d=2,max_D=1,test='kpss',seasonal_test='ocsb',information_criterion='aic',stepwise=True,with_intercept='auto',maxiter=500,trace=True,error_action='trace',suppress_warnings=False,return_valid_fits=True)
    best=fits[0]
    with (OUT/(name+'.pickle')).open('wb') as f: pickle.dump(best,f)
    (OUT/(name+'_resumo.txt')).write_text(str(best.summary()),encoding='utf-8')
    records=[]
    for fit in fits:
        records.append({'order':str(fit.order),'seasonal_order':str(fit.seasonal_order),'intercept':fit.with_intercept,'AIC':fit.aic(),'BIC':fit.bic(),'converged':fit.arima_res_.mle_retvals.get('converged')})
    pd.DataFrame(records).to_csv(OUT/(name+'_candidatos.csv'),index=False)
    r=best.arima_res_; burn=max(r.loglikelihood_burn,best.order[1]+12*best.seasonal_order[1]); e=np.asarray(r.resid)[burn:]
    df=best.order[0]+best.order[2]+best.seasonal_order[0]+best.seasonal_order[2]
    lb=acorr_ljungbox(e,lags=[6,12,24],model_df=df)
    row=dict(busca=name,order=list(best.order),seasonal_order=list(best.seasonal_order),intercept=best.with_intercept,AIC=best.aic(),BIC=best.bic(),N=len(e),burn=burn,converged=bool(r.mle_retvals.get('converged')),segundos=time.time()-start,ARCH12_p=het_arch(e,nlags=12,ddof=df)[1])
    for h in [6,12,24]: row['Q'+str(h)]=lb.loc[h,'lb_stat']; row['Q'+str(h)+'_p']=lb.loc[h,'lb_pvalue']
    rows.append(row)
    (OUT/'resultados.json').write_text(json.dumps(rows,indent=2),encoding='utf-8')
    print(row,flush=True)
