"""Identificação preliminar não sazonal em HOUST original; sem estimar modelos."""
from pathlib import Path
import sys
import os
sys.stdout.reconfigure(encoding='utf-8')
ROOT=Path(__file__).resolve().parents[1]
sys.path.append(str(ROOT/'.dependencias'))
os.environ['MPLCONFIGDIR']=str(ROOT/'.cache_matplotlib')
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
OUT=ROOT/'questao_2a'
(OUT/'graficos').mkdir(parents=True,exist_ok=True)
s=pd.read_csv(ROOT/'dados/brutos/housing_fred_1994_2025_python.csv',index_col=0,parse_dates=True).loc['1994-01-01':'2024-12-01','HOUST']
assert s.index.equals(pd.date_range('1994-01-01','2024-12-01',freq='MS'))
w=s.diff().dropna()
assert len(w)==371 and w.notna().all()
w.to_csv(OUT/'primeira_diferenca_houst.csv',header=['delta_HOUST'])
z=w.to_numpy()-w.mean()
r=np.array([z[k:]@z[:len(z)-k]/(z@z) for k in range(49)])
p=np.ones(49)
for k in range(1,49):
    p[k]=np.linalg.solve(r[np.abs(np.arange(k)[:,None]-np.arange(k)[None,:])],r[1:k+1])[-1]
previous=np.empty(0)
for k in range(1,49):
    a=(r[k]-previous@r[1:k][::-1])/(1-previous@r[1:k])
    assert np.isclose(a,p[k],atol=1e-10)
    previous=np.r_[previous-a*previous[::-1],a]
pd.DataFrame({'lag':range(49),'FAC':r,'FACP':p,'N':len(w),'limite_95':1.96/np.sqrt(len(w))}).to_csv(OUT/'fac_facp_delta_houst.csv',index=False,float_format='%.12g')
plt.rcParams.update({'font.family':'DejaVu Sans','axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none'})
fig,axes=plt.subplots(1,2,figsize=(13,4.6))
for ax,label,v in zip(axes,['FAC','FACP'],[r,p]):
    limit=1.96/np.sqrt(len(w))
    ax.axhspan(-limit,limit,color='#e6edf5')
    ax.axhline(0,color='#64748b',lw=.8)
    for sign in [-1,1]:
        ax.axhline(sign*limit,color='#8394a8',ls='--',lw=.8)
    ax.vlines(range(1,49),0,v[1:],color='#d97927')
    ax.scatter(range(1,49),v[1:],color='#d97927',s=12)
    ax.set(title=label+' de Δsₜ — HOUST',xlabel='Defasagem (meses)',ylim=(-.5,.3),xlim=(.3,48.7))
    ax.set_xticks([1,6,12,18,24,30,36,42,48])
    for lag in [12,24,36,48]:
        ax.axvline(lag,color='#cbd5e1',ls=':',lw=.8,zorder=0)
fig.suptitle('Identificação em HOUST original | Primeira diferença, sem log',fontsize=16,x=.07,ha='left',weight='bold')
fig.subplots_adjust(left=.07,right=.985,top=.80,bottom=.22,wspace=.17)
fig.text(.07,.06,'1994M2–2024M12 • N = 371 • Bandas pontuais de 95% sob ruído branco • Fonte: FRED',fontsize=10)
for ext in ['png','svg']:
    fig.savefig(OUT/'graficos'/('fac_facp_delta_houst.'+ext),dpi=180)
plt.close(fig)
print('FAC/FACP de ΔHOUST verificadas por Yule–Walker e Durbin–Levinson; N=371.')
print(pd.DataFrame({'FAC':r,'FACP':p}).iloc[[1,2,3,4,5,6,12,24]].round(4).to_string())
