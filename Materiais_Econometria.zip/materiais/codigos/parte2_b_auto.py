exec(open(__file__.replace('parte2_b_auto.py','parte2_b.py'),encoding='utf-8').read().split('rows=[]')[0])
rows=[];fits={}
for lag in [0,1,5]:
 for p in [1,2]:
  for o in [0,1]:
   for q in [1,2]:
    name=f'AR{lag}_EGARCH{p}{o}{q}_t'
    model=arch_model(r,mean='Constant' if lag==0 else 'AR',lags=lag or None,vol='EGARCH',p=p,o=o,q=q,dist='t',hold_back=5,rescale=False)
    with warnings.catch_warnings(record=True) as caught:
     warnings.simplefilter('always');f=model.fit(disp='off',cov_type='robust',options={'maxiter':2000,'ftol':1e-9})
    row=dict(modelo=name,p=p,o=o,q=q,AR=lag,N=f.nobs,AIC=f.aic,BIC=f.bic,converged=f.convergence_flag==0,warnings='; '.join(str(w.message) for w in caught))
    rows.append(row);fits[name]=f
table=pd.DataFrame(rows).sort_values('BIC');table.to_csv(OUT/'busca_automatica.csv',index=False)
valid=table[table.converged];chosen=set([valid.iloc[0].modelo,valid.sort_values('AIC').iloc[0].modelo]);details={}
for name in chosen:
 f=fits[name];z=f.std_resid.dropna();diag={'parametros':f.params.to_dict(),'p_coef':f.pvalues.to_dict()}
 for h in [5,10,20]:
  diag[f'LB_z_{h}_p']=float(acorr_ljungbox(z,lags=[h],model_df=0).iloc[0].lb_pvalue);diag[f'LB_z2_{h}_p']=float(acorr_ljungbox(z*z,lags=[h],model_df=0).iloc[0].lb_pvalue);diag[f'ARCH_{h}_p']=float(het_arch(z,nlags=h,ddof=0)[1])
 eps=f.resid.dropna().to_numpy()[:-1];neg=(eps<0).astype(float);X=np.column_stack([np.ones(len(eps)),neg,neg*eps,(1-neg)*eps]);aux=sm.OLS(z.to_numpy()[1:]**2,X).fit();diag['Engle_Ng_p']=float(chi2.sf(len(eps)*aux.rsquared,3))
 details[name]=diag
 with (OUT/'modelos'/f'auto_{name}.pickle').open('wb') as file:pickle.dump(f,file)
(OUT/'busca_automatica_diagnosticos.json').write_text(json.dumps(details,indent=2),encoding='utf-8')
print(table[['modelo','AIC','BIC','converged']].head(8).to_string(index=False));print('AIC WINNER',valid.sort_values('AIC').iloc[0].modelo);print(json.dumps(details,indent=2))
