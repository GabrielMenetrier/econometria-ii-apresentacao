"""Doze ARIMA em HOUST: ML gaussiana exata do mesmo vetor de primeiras diferenças."""
from pathlib import Path
import sys
import os
import json
import warnings
import hashlib
sys.stdout.reconfigure(encoding='utf-8')
ROOT=Path(__file__).resolve().parents[1]
sys.path.append(str(ROOT/'.dependencias'))
os.environ['MPLCONFIGDIR']=str(ROOT/'.cache_matplotlib')
import numpy as np
import pandas as pd
import scipy
from scipy.linalg import toeplitz, cholesky, solve_triangular
import statsmodels
from statsmodels.tsa.arima.model import ARIMA
from statsmodels.tsa.arima_process import arma_acovf

OUT=ROOT/'questao_2b'
(OUT/'modelos').mkdir(parents=True,exist_ok=True)
RAW=ROOT/'dados/brutos/housing_fred_1994_2025_python.csv'
s=pd.read_csv(RAW,index_col=0,parse_dates=True).loc['1994-01-01':'2024-12-01','HOUST'].asfreq('MS')
assert len(s)==372 and s.notna().all()
w=s.diff().dropna().rename('delta_HOUST')
assert w.index.equals(pd.date_range('1994-02-01','2024-12-01',freq='MS'))
w.to_csv(OUT/'amostra_efetiva_comum.csv')
ORDERS=[(0,1),(1,0),(2,0),(3,0),(1,1),(0,2)]
LABELS={'const':'μ','ar.L1':'φ₁','ar.L2':'φ₂','ar.L3':'φ₃','ma.L1':'θ₁','ma.L2':'θ₂'}
allrows=[]
paramrows=[]
audits=[]
fitted={}
for p,q in ORDERS:
    for drift in [False,True]:
        ident=f'ARIMA({p},1,{q})'+(' com drift' if drift else ' sem drift')
        model=ARIMA(w,order=(p,0,q),trend='c' if drift else 'n',
                    enforce_stationarity=True,enforce_invertibility=True,concentrate_scale=True)
        starts=[None, np.r_[[w.mean()] if drift else [], np.zeros(p+q)]]
        if (p,q)==(1,1):
            starts.extend([np.r_[[w.mean()] if drift else [],a,b] for a,b in [(.6,-.8),(.9,-.95),(-.5,.1)]])
        attempts=[]
        candidates=[]
        for start in starts:
            with warnings.catch_warnings(record=True) as caught:
                warnings.simplefilter('always')
                try:
                    fit=model.fit(start_params=start,method='statespace',cov_type='oim',
                                  method_kwargs={'method':'lbfgs','maxiter':2000,'pgtol':1e-9,'factr':1e3,'disp':0})
                    conv=bool(fit.mle_retvals.get('converged',False))
                    attempts.append({'llf':float(fit.llf),'converged':conv,'warnings':[str(a.message) for a in caught]})
                    if conv and np.isfinite(fit.llf):
                        candidates.append(fit)
                except Exception as e:
                    attempts.append({'error':str(e),'warnings':[str(a.message) for a in caught]})
        if not candidates:
            raise RuntimeError(f'Nenhuma otimização convergiu: {ident}; {attempts}')
        fit=max(candidates,key=lambda a:a.llf)
        n=int(fit.nobs_effective)
        k=p+q+int(drift)+1
        assert n==371 and fit.loglikelihood_burn==0
        assert int(fit.df_model)==k
        assert np.isclose(fit.aic,-2*fit.llf+2*k)
        assert np.isclose(fit.bic,-2*fit.llf+k*np.log(n))
        assert np.isfinite(fit.bse).all() and (fit.bse>0).all()
        assert np.all(np.abs(fit.arroots)>1) and np.all(np.abs(fit.maroots)>1)
        # Recalcular ℓ pela densidade normal multivariada, sem filtro de Kalman.
        mu=float(fit.params.get('const',0))
        covariance=toeplitz(arma_acovf(np.r_[1,-fit.arparams],np.r_[1,fit.maparams],nobs=n,sigma2=fit.scale))
        L=cholesky(covariance,lower=True)
        u=solve_triangular(L,w.to_numpy()-mu,lower=True)
        independent_ll=-.5*(n*np.log(2*np.pi)+2*np.log(np.diag(L)).sum()+u@u)
        assert np.isclose(fit.llf,independent_ll,atol=1e-5,rtol=0), (ident,fit.llf,independent_ll)
        row={'modelo':ident,'p':p,'d':1,'q':q,'drift':drift,'N':n,'k':k,'log_verossimilhanca':float(fit.llf),
             'sigma2':float(fit.scale),'AIC':float(fit.aic),'BIC':float(fit.bic),'convergiu':True}
        for name in fit.params.index:
            estimate=float(fit.params[name])
            se=float(fit.bse[name])
            t=estimate/se
            assert np.isclose(t,float(fit.tvalues[name]))
            row[name]=estimate
            row[name+'_ep']=se
            row[name+'_t']=t
            paramrows.append({'modelo':ident,'parametro':LABELS[name],'estimativa':estimate,'erro_padrao':se,'t_assintotico':t})
        allrows.append(row)
        fitted[ident]=fit
        audits.append({'modelo':ident,'attempts':attempts,'selected_llf':float(fit.llf),
                       'independent_llf':float(independent_ll),'N':n,'burn':int(fit.loglikelihood_burn),
                       'min_ar_root_modulus':float(min(np.abs(fit.arroots))) if p else None,
                       'min_ma_root_modulus':float(min(np.abs(fit.maroots))) if q else None})
        slug=f'arima_{p}_1_{q}_'+('drift' if drift else 'sem_drift')
        fit.save(OUT/'modelos'/(slug+'.pickle'))
        (OUT/'modelos'/(slug+'_resumo.txt')).write_text(fit.summary().as_text(),encoding='utf-8')
        print(ident, 'AIC',round(fit.aic,3),'BIC',round(fit.bic,3),flush=True)

ranking=pd.DataFrame(allrows).sort_values('AIC').reset_index(drop=True)
ranking['delta_AIC']=ranking.AIC-ranking.AIC.min()
ranking['delta_BIC']=ranking.BIC-ranking.BIC.min()
ranking.to_csv(OUT/'resultados_completos.csv',index=False,float_format='%.12g')
pd.DataFrame(paramrows).to_csv(OUT/'coeficientes_erros_t.csv',index=False,float_format='%.12g')
pd.DataFrame({key:fit.resid for key,fit in fitted.items()}).to_csv(OUT/'inovacoes_estimadas.csv',float_format='%.12g')

def fmt(x,digits=3):
    return f'{x:,.{digits}f}'.replace(',','_').replace('.',',').replace('_','.')

headers=['Modelo','Drift μ','AR: φ₁; φ₂; φ₃','MA: θ₁; θ₂','σ̂²','AIC','BIC']
table=['| '+' | '.join(headers)+' |','|:--|:--|:--|:--|--:|--:|--:|']
htmlrows=[]
for _,row in ranking.iterrows():
    def cell(name):
        if name not in row or pd.isna(row[name]):
            return '—'
        return f'{fmt(row[name])} ({fmt(row[name+"_ep"])}; {fmt(row[name+"_t"],2)})'
    cells=[f'({int(row.p)},1,{int(row.q)}) '+('com drift' if row.drift else 'sem drift'),
           cell('const'),'; '.join(cell(f'ar.L{k}') for k in range(1,int(row.p)+1)) or '—',
           '; '.join(cell(f'ma.L{k}') for k in range(1,int(row.q)+1)) or '—',
           fmt(row.sigma2,2),fmt(row.AIC,2),fmt(row.BIC,2)]
    table.append('| '+' | '.join(cells)+' |')
    htmlrows.append('<tr>'+''.join('<td>'+v+'</td>' for v in cells)+'</tr>')
mdtable='\n'.join(table)
(OUT/'tabela_comparativa.md').write_text(mdtable+'\n',encoding='utf-8')
best_a=ranking.loc[ranking.AIC.idxmin()]
best_b=ranking.loc[ranking.BIC.idxmin()]
meta={'source_sha256':hashlib.sha256(RAW.read_bytes()).hexdigest(),
      'input':'HOUST original, sem log e sem divisão por 12','levels_period':['1994-01-01','2024-12-01'],
      'effective_period':['1994-02-01','2024-12-01'],'N':371,'d':1,
      'likelihood':'exact Gaussian stationary likelihood of delta_HOUST; stationary state initialization; no likelihood burn; concentrated innovation variance',
      'parameterization':'Phi(B)(delta_s_t-mu)=Theta(B) epsilon_t; MA plus signs; mu=0 if no drift',
      'covariance':'OIM (Harvey observed information), model-based; t=estimate/se, asymptotic normal reference',
      'k':'p+q+drift_indicator+1 (innovation variance counted even though concentrated)',
      'scope':'6 orders x with/without drift; no use of 2025; no residual adequacy claim',
      'versions':{'numpy':np.__version__,'pandas':pd.__version__,'scipy':scipy.__version__,'statsmodels':statsmodels.__version__},
      'audit':audits}
(OUT/'metodologia_e_verificacoes.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2),encoding='utf-8')
report=f'''# Questão 2(b) — Estimação e comparação de 12 modelos ARIMA

## Especificações e amostra

Estimamos seis ordens não sazonais — (0,1,1), (1,1,0), (2,1,0), (3,1,0), (1,1,1) e (0,1,2) — cada uma com e sem drift, totalizando **12 especificações**. As três propostas em 2(a) estão incluídas. ARIMA(1,1,0) e (2,1,0) verificam alternativas AR mais simples ao AR(3) nas diferenças; ARIMA(0,1,2) verifica a necessidade de um segundo termo MA. A inclusão de drift também é avaliada, e não presumida.

Preservamos HOUST nas unidades originais, sem log e sem divisão por 12. O período em nível é 1994M1–2024M12 (372 meses). Para todos os modelos, usamos exatamente w_t = Δs_t no período **1994M2–2024M12, N=371**. Nenhuma observação de 2025 participou da estimação ou da comparação.

## Método e convenção dos coeficientes

A estimação usa máxima verossimilhança gaussiana exata do vetor de primeiras diferenças, com inicialização estacionária da parte ARMA, calculada em espaço de estados. Estimar ARMA(p,q) nesse vetor corresponde a estimar a dinâmica ARIMA(p,1,q) para s_t, tomando o primeiro nível observado como ponto de partida. Não aplicamos uma segunda diferenciação. A variância da inovação foi concentrada analiticamente na otimização e contada como parâmetro nos critérios de informação.

Convenção: **Φ(B)(w_t − μ) = Θ(B)ε_t**, com Φ(B)=1−φ₁B−…−φₚBᵖ e Θ(B)=1+θ₁B+…+θ_qB^q. Nos modelos sem drift, μ=0. Nos modelos com drift, μ=E[Δs_t], isto é, a variação média mensal do nível, nas unidades de HOUST. Não se trata de uma taxa percentual. Se a equação for escrita com intercepto c, então c=μ(1−Σφᵢ); logo, μ e c não devem ser confundidos.

Erros-padrão: matriz de informação observada (OIM, método de Harvey), sob o modelo gaussiano; não são erros robustos à má especificação. A estatística solicitada é **t=estimativa/erro-padrão**. Em máxima verossimilhança ARIMA, sua referência usual é normal assintótica (o software a denomina z), não uma distribuição t de Student exata em amostra finita. [Documentação do método](https://www.statsmodels.org/stable/generated/statsmodels.tsa.arima.model.ARIMA.fit.html).

## Tabela comparativa única

Cada entrada de coeficiente está no formato **estimativa (erro-padrão; t)**. Nas colunas AR e MA, os parâmetros aparecem em ordem de defasagem. O traço significa parâmetro ausente/fixado, não estimativa igual a zero. σ̂² é a variância da inovação por máxima verossimilhança, em unidades de HOUST ao quadrado, sem correção por graus de liberdade. N=371 em todas as linhas. Ordem crescente de AIC.

{mdtable}

## AIC e BIC

**AIC — Critério de Informação de Akaike:** equilibra ajuste e complexidade. **BIC — Critério de Informação Bayesiano (Schwarz):** também faz esse equilíbrio, com penalização que depende do tamanho da amostra.

**AIC = −2ℓ̂ + 2k** e **BIC = −2ℓ̂ + k ln(N)**, em que ℓ̂ é a log-verossimilhança maximizada, k é o número de parâmetros estimados (incluindo a variância da inovação e o drift, quando presente), e N é o número de observações efetivas.

Mais parâmetros podem melhorar a verossimilhança, mas recebem uma penalização. Aqui ln(371)={fmt(np.log(371),3)}, de modo que o BIC penaliza cada parâmetro adicional em cerca de 5,916, contra 2 no AIC. **Menor é melhor dentro do conjunto comparável.** Os critérios não são testes de hipótese, não possuem interpretação em porcentagem e não comprovam adequação dos resíduos nem desempenho fora da amostra. [Referência sobre seleção de ordens](https://otexts.com/fpp3/arima-estimation.html).

## Por que a comparabilidade importa e como foi garantida

A log-verossimilhança depende das observações, da transformação e da escala da variável, além do modelo. Alterar a amostra pode mudar o critério mesmo sem melhorar a descrição dos mesmos dados; mudar para log transforma o problema estatístico e a densidade. Comparar diretamente AIC/BIC de níveis e logs sem colocar as verossimilhanças na mesma medida (incluindo o jacobiano apropriado) seria incorreto. Mudar d também muda o vetor diferenciado observado e os termos da verossimilhança; por isso os critérios não foram usados aqui para escolher d.

Garantias concretas:

1. Mesmo vetor ΔHOUST, mesmas 371 datas, sem faltantes, sem log e sem reescala.
2. Mesmo d=1 e mesmo método de máxima verossimilhança gaussiana exata.
3. Inicialização estacionária da parte ARMA em todos os modelos; **zero observações descartadas da verossimilhança**. Ordens AR/MA maiores não encurtaram a amostra: os estados iniciais são tratados probabilisticamente, não por cortes diferentes de dados.
4. Mesmo tipo de erro-padrão e mesma convenção de sinais.
5. Contagem k=p+q+1 nos modelos sem drift e k=p+q+2 nos modelos com drift. O parâmetro de variância conta mesmo sendo concentrado na otimização.
6. AIC/BIC recalculados pelas fórmulas e conferidos com o software. As 12 log-verossimilhanças foram também recalculadas pela densidade normal multivariada, usando a matriz de autocovariâncias ARMA, e coincidiram com o filtro de Kalman.

As versões com e sem drift são comparáveis: a amostra e a variável não mudam, e a diferença na quantidade de parâmetros é justamente o que a penalização considera.

## Resultado da comparação

O menor AIC é do **{best_a.modelo}**, com **{fmt(best_a.AIC,2)}**. O menor BIC é do **{best_b.modelo}**, com **{fmt(best_b.BIC,2)}**. Esses resultados são relativos às 12 especificações consideradas, não a todos os modelos possíveis. A escolha final ainda depende dos diagnósticos dos resíduos previstos nas próximas partes.

Todas as soluções selecionadas convergiram, os erros-padrão foram finitos e positivos, e as raízes da parte AR estacionária e da parte MA invertível ficaram fora do círculo unitário. Essa checagem é sobre a parte ARMA nas diferenças; o fator (1−B) do ARIMA continua contendo a raiz unitária imposta por d=1.

O modelo de menor AIC/BIC tem Δs_t = ε_t − 0,426 ε_(t−1), com σ̂² = 8.547,94. O ARIMA(1,1,1) sem drift e o ARIMA(0,1,2) sem drift ficam a cerca de 1,97 pontos de AIC do primeiro: a vantagem por AIC é modesta. Nessas extensões, os termos extras têm t próximos de zero (φ₁≈−0,16 em estatística t no modelo misto; θ₂≈0,14 no MA(2)). Todos os drifts apresentam |t| inferior a 0,12 e pioram os critérios. O ARIMA(3,1,0) reduz um pouco mais a variância, mas o ganho não compensa sua maior quantidade de parâmetros.

## Materiais

- [Tabela comparativa](tabela_comparativa.md) e [versão HTML legível](tabela_comparativa.html).
- [Resultados completos, com log-verossimilhança e contagem de parâmetros](resultados_completos.csv).
- [Coeficientes, erros-padrão e estatísticas t sem arredondamento de apresentação](coeficientes_erros_t.csv).
- [Amostra efetiva comum](amostra_efetiva_comum.csv).
- [Método, versões e verificações](metodologia_e_verificacoes.json).
- [Código reprodutível](../codigos/questao_2b.py). Modelos estimados e resumos preservados na pasta modelos.
- Fonte dos dados: [FRED — HOUST](https://fred.stlouisfed.org/series/HOUST), mesma cópia da questão 1(a).
'''
(OUT/'resposta_questao_2b.md').write_text(report,encoding='utf-8')
html='''<!doctype html><html lang=\"pt-BR\"><meta charset=\"utf-8\"><title>Questão 2(b) — Comparação ARIMA</title>
<style>body{font:15px system-ui;margin:32px;color:#173047}h1{font-size:26px}table{border-collapse:collapse;width:100%;font-size:14px}td,th{padding:12px 9px;border-bottom:1px solid #ccd6df;text-align:left;vertical-align:top}thead{background:#e6eef5}tbody tr:nth-child(even){background:#f6f8fa}td:nth-child(n+5){white-space:nowrap}p{max-width:1100px;line-height:1.5}.scroll{overflow:auto}</style>
<h1>HOUST — Comparação de 12 especificações ARIMA</h1>
<p>Mesma amostra efetiva: 1994M2–2024M12, N=371. HOUST original, primeira diferença, sem log. Máxima verossimilhança gaussiana exata. Cada coeficiente: <b>estimativa (erro-padrão; t)</b>. AR/MA em ordem de defasagem. μ é o drift; t tem referência normal assintótica.</p><div class=\"scroll\"><table><thead><tr>'''
html+=''.join('<th>'+v+'</th>' for v in headers)+'</tr></thead><tbody>'+''.join(htmlrows)+'</tbody></table></div>'
html+='<p>σ̂²: variância da inovação por ML. Erros-padrão OIM. k inclui a variância e, quando estimado, o drift. AIC = −2ℓ̂ + 2k; BIC = −2ℓ̂ + k ln(371). Menor é melhor. Modelos ordenados por AIC. Fonte dos dados: FRED (HOUST). Nenhum dado de 2025 utilizado.</p></html>'
(OUT/'tabela_comparativa.html').write_text(html,encoding='utf-8')
print('\n'+mdtable)
print('\nMELHOR AIC:',best_a.modelo,'MELHOR BIC:',best_b.modelo)
