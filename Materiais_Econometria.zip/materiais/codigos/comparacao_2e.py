from pathlib import Path
import sys,os,json,pickle
ROOT=Path(__file__).resolve().parents[1]; sys.path.append(str(ROOT/'.dependencias'))
sys.stdout.reconfigure(encoding='utf-8')
import numpy as np
import pandas as pd
from statsmodels.tsa.arima.model import ARIMA,ARIMAResults
from statsmodels.stats.diagnostic import acorr_ljungbox,het_arch
OUT=ROOT/'questao_2e'
w=pd.read_csv(ROOT/'questao_2b/amostra_efetiva_comum.csv',index_col=0,parse_dates=True).iloc[:,0].asfreq('MS')
manual=ARIMAResults.load(ROOT/'questao_2b/modelos/arima_0_1_1_sem_drift.pickle')
with (OUT/'sazonal.pickle').open('rb') as f: auto=pickle.load(f)
model=ARIMA(w,order=(0,0,1),seasonal_order=(0,0,2,12),trend='n',concentrate_scale=True)
fits=[model.fit(start_params=start,cov_type='oim',method_kwargs={'maxiter':2000,'pgtol':1e-9,'factr':1e3}) for start in [None,np.asarray(auto.params())[:-1]]]
fit=max([f for f in fits if f.mle_retvals['converged']],key=lambda f:f.llf)
assert fit.nobs_effective==371 and fit.loglikelihood_burn==0
fit.save(OUT/'sazonal_amostra_comum.pickle')
(OUT/'sazonal_amostra_comum_resumo.txt').write_text(str(fit.summary()),encoding='utf-8')
rows=[]
for name,f,k in [('Manual / automático não sazonal',manual,1),('Automático sazonal',fit,3)]:
    e=np.asarray(f.resid); lb=acorr_ljungbox(e,lags=[6,12,24],model_df=k)
    row={'modelo':name,'AIC':f.aic,'BIC':f.bic,'sigma2':f.scale,'N':len(e),'ARCH12_p':het_arch(e,nlags=12,ddof=k)[1]}
    for h in [6,12,24]: row[f'Q{h}']=lb.loc[h,'lb_stat'];row[f'Q{h}_p']=lb.loc[h,'lb_pvalue']
    rows.append(row)
pd.DataFrame(rows).to_csv(OUT/'comparacao_amostra_comum.csv',index=False)
pd.DataFrame({'coeficiente':fit.param_names,'valor':fit.params,'erro_padrao':fit.bse,'t':fit.tvalues}).to_csv(OUT/'coeficientes_sazonal.csv',index=False)
print(pd.DataFrame(rows).to_string(index=False))
print('parameters',fit.params.to_dict(),'min MA root',min(abs(fit.maroots)))
