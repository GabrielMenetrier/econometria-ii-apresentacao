﻿exec(open(__file__.replace('parte2_b_diagnosticos.py','parte2_b.py'),encoding='utf-8').read().split('rows=[]')[0])
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.stats import t as student,skew,kurtosis
from statsmodels.tsa.stattools import adfuller,kpss,acf
(OUT/'graficos').mkdir(exist_ok=True)
with (OUT/'modelos/AR0_EGARCH111_t.pickle').open('rb') as file:f=pickle.load(file)
# Verificação numérica do candidato central com duas inicializações adicionais.
checks=[]
for shift in [-.03,.03]:
    start=f.params.copy();start['gamma[1]']+=shift
    ff=f.model.fit(starting_values=start,disp='off',cov_type='robust',options={'maxiter':3000,'ftol':1e-10})
    checks.append({'converged':ff.convergence_flag==0,'llf':ff.loglikelihood,'dif_llf':ff.loglikelihood-f.loglikelihood})
    assert ff.convergence_flag==0 and abs(ff.loglikelihood-f.loglikelihood)<1e-4
z=f.std_resid.dropna();params=f.params;nu=params['nu'];g=params['gamma[1]'];beta=params['beta[1]']
diag={'parametros':params.to_dict(),'std_errors_robustos':f.std_err.to_dict(),'p_valores':f.pvalues.to_dict(),'beta_abs_menor_1':abs(beta)<1,'persistencia_meia_vida_log_dias':np.log(.5)/np.log(beta),'razao_variancia_neg_pos_1sd':np.exp(-2*g),'razao_vol_neg_pos_1sd':np.exp(-g),'media_z':z.mean(),'variancia_z':z.var(),'assimetria_z':skew(z,bias=False),'curtose_z':kurtosis(z,fisher=False,bias=False),'inicializacoes':checks}
adf=adfuller(r,regression='c',autolag='AIC');kp=kpss(r,regression='c',nlags='auto');diag['ADF']={'estatistica':adf[0],'p':adf[1],'lags':adf[2]};diag['KPSS']={'estatistica':kp[0],'p_tabelado':kp[1],'lags':kp[2]}
diag['sign_size_rawlag']={}
for name in ['AR0_EGARCH101_t','AR0_EGARCH111_t']:
    with (OUT/'modelos'/f'{name}.pickle').open('rb') as file:ff=pickle.load(file)
    zz=ff.std_resid.dropna().to_numpy();eps=ff.resid.dropna().to_numpy()[:-1];neg=(eps<0).astype(float);X=np.column_stack([np.ones(len(eps)),neg,neg*eps,(1-neg)*eps]);aux=sm.OLS(zz[1:]**2,X).fit();rob=sm.OLS(zz[1:]**2,X).fit(cov_type='HC3');wald=rob.wald_test(np.column_stack([np.zeros(3),np.eye(3)]),scalar=True)
    diag['sign_size_rawlag'][name]={'LM':len(eps)*aux.rsquared,'p':chi2.sf(len(eps)*aux.rsquared,3),'p_HC3':float(wald.pvalue),'coeficientes':aux.params.tolist(),'p_individuais_OLS':aux.pvalues.tolist()}
(OUT/'diagnosticos_detalhados.json').write_text(json.dumps(diag,indent=2,default=lambda x:x.item()),encoding='utf-8')
(OUT/'modelos/resumo_preferido.txt').write_text(str(f.summary()),encoding='utf-8')
pd.DataFrame({'r':r,'residuo':f.resid,'sigma':f.conditional_volatility,'z':f.std_resid}).to_csv(OUT/'residuos_volatilidade.csv')
fig,axes=plt.subplots(2,2,figsize=(12,8))
axes[0,0].plot(z.index,z,lw=.6);axes[0,0].set_title('Resíduos padronizados z = ε/σ')
for ax,values,title in [(axes[0,1],z,'FAC de z'),(axes[1,0],z*z,'FAC de z²')]:
    a=acf(values,nlags=30,fft=False);ax.stem(range(1,31),a[1:],basefmt=' ')
    for sign in [-1,1]:ax.axhline(sign*1.96/np.sqrt(len(z)),color='gray',ls='--')
    ax.set_title(title);ax.set_xlabel('Pregões')
theory=student.ppf((np.arange(len(z))+.5)/len(z),nu)*np.sqrt((nu-2)/nu);axes[1,1].scatter(theory,np.sort(z),s=8);lo=min(theory.min(),z.min());hi=max(theory.max(),z.max());axes[1,1].plot([lo,hi],[lo,hi],color='gray',ls='--');axes[1,1].set_title('Q–Q: t de Student padronizada estimada');axes[1,1].set_xlabel('Quantil teórico');axes[1,1].set_ylabel('Quantil observado')
fig.suptitle('EGARCH assimétrico com t — média constante');fig.tight_layout();fig.savefig(OUT/'graficos/diagnosticos.png',dpi=170);fig.savefig(OUT/'graficos/diagnosticos.svg');plt.close(fig)
fig,axes=plt.subplots(1,2,figsize=(12,4.5));axes[0].plot(f.conditional_volatility.index,f.conditional_volatility,lw=.9);axes[0].set_title('Volatilidade condicional diária estimada');axes[0].set_ylabel('Pontos percentuais de log-retorno')
x=np.linspace(-3,3,301);impact=np.exp(params['alpha[1]']*np.abs(x)+g*x);axes[1].plot(x,impact,color='#a3472a');axes[1].axvline(0,color='gray',ls='--');axes[1].axhline(1,color='gray',ls='--');axes[1].set_xlabel('Choque padronizado anterior');axes[1].set_ylabel('Variância relativa ao choque zero');axes[1].set_title('Impacto de notícias, mantendo σ anterior fixa')
fig.tight_layout();fig.savefig(OUT/'graficos/volatilidade_assimetria.png',dpi=170);fig.savefig(OUT/'graficos/volatilidade_assimetria.svg');plt.close(fig)
print(json.dumps(diag,indent=2,default=lambda x:x.item()))

