from pathlib import Path
import sys,os,json,warnings
ROOT=Path(__file__).resolve().parents[1];sys.path.append(str(ROOT/'.dependencias'))
os.environ['MPLCONFIGDIR']=str(ROOT/'.cache_matplotlib');sys.stdout.reconfigure(encoding='utf-8')
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from statsmodels.tsa.stattools import acf,pacf
from statsmodels.tsa.arima.model import ARIMA
from statsmodels.stats.diagnostic import acorr_ljungbox,het_arch
import pmdarima as pm
OUT=ROOT/'questao_3a'
for sub in ['graficos','modelos']:(OUT/sub).mkdir(parents=True,exist_ok=True)
h=pd.read_csv(ROOT/'dados/brutos/housing_fred_1994_2025_python.csv',parse_dates=['observation_date']).set_index('observation_date')['HOUSTNSA'].loc['1994-01-01':'2024-12-01'].asfreq('MS')
assert len(h)==372 and h.notna().all()
trans={'h':h,'diff1':h.diff().dropna(),'diff12':h.diff(12).dropna(),'diff1_diff12':h.diff(12).diff().dropna()}
ident=[]
fig,ax=plt.subplots(4,2,figsize=(12,13))
for i,(name,y) in enumerate(trans.items()):
    a=acf(y,nlags=48,fft=False);pa=pacf(y,nlags=48,method='ywm')
    for lag in range(49):ident.append(dict(transformacao=name,lag=lag,FAC=a[lag],FACP=pa[lag],N=len(y)))
    for j,(v,title) in enumerate([(a,'FAC'),(pa,'FACP')]):
        ax[i,j].stem(range(1,49),v[1:],basefmt=' ');ax[i,j].axhline(0,color='black',lw=.6)
        for sign in [-1,1]:ax[i,j].axhline(sign*1.96/np.sqrt(len(y)),color='gray',ls='--')
        ax[i,j].set_title(name+' — '+title);ax[i,j].set_xticks([1,6,12,18,24,30,36,42,48])
fig.suptitle('HOUSTNSA: identificação — 1994–2024, unidades originais');fig.tight_layout()
fig.savefig(OUT/'graficos/identificacao.png',dpi=170);fig.savefig(OUT/'graficos/identificacao.svg');plt.close(fig)
pd.DataFrame(ident).to_csv(OUT/'identificacao.csv',index=False)
test={'KPSS_d_nivel':pm.arima.ndiffs(h,test='kpss'),'OCSB_D_nivel':pm.arima.nsdiffs(h,m=12,test='ocsb'),'KPSS_d_apos_diff12':pm.arima.ndiffs(trans['diff12'],test='kpss')}
(OUT/'testes_diferenciacao.json').write_text(json.dumps(test,indent=2))
print(test,flush=True)
print(pd.DataFrame(ident).query('lag in [1,2,3,12,24,36]').to_string(index=False),flush=True)
w=trans['diff1_diff12'];w.to_csv(OUT/'amostra_efetiva.csv')
orders=[(0,1,0,1),(1,0,0,1),(1,1,0,1),(0,1,1,0),(0,1,1,1),(0,2,0,1),(2,0,0,1),(1,0,1,0),(1,1,1,0),(0,1,0,2)]
rows=[];coefs=[];audit=[];fits={}
for p,q,P,Q in orders:
    label=f'SARIMA({p},1,{q})({P},1,{Q})12';slug=f'{p}1{q}_{P}1{Q}'
    model=ARIMA(w,order=(p,0,q),seasonal_order=(P,0,Q,12),trend='n',concentrate_scale=True)
    candidates=[]
    for start in [None,np.zeros(p+q+P+Q)]:
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter('always')
            try:
                f=model.fit(start_params=start,cov_type='oim',method_kwargs={'maxiter':2000,'pgtol':1e-8,'factr':1e4})
                audit.append(dict(modelo=label,converged=bool(f.mle_retvals['converged']),llf=f.llf,warnings=[str(c.message) for c in caught]))
                if f.mle_retvals['converged']:candidates.append(f)
            except Exception as e:audit.append(dict(modelo=label,error=str(e)))
    if not candidates:continue
    f=max(candidates,key=lambda x:x.llf);fits[label]=f;f.save(OUT/'modelos'/f'{slug}.pickle')
    assert f.nobs_effective==359 and f.loglikelihood_burn==0
    e=np.asarray(f.resid);k=p+q+P+Q;lb=acorr_ljungbox(e,lags=[12,24,36],model_df=k)
    r=dict(modelo=label,p=p,q=q,P=P,Q=Q,N=len(e),AIC=f.aic,BIC=f.bic,sigma2=f.scale,ARCH12_p=het_arch(e,nlags=12,ddof=k)[1],min_AR=min(abs(f.arroots)) if p+P else None,min_MA=min(abs(f.maroots)) if q+Q else None)
    for lag in [12,24,36]:r[f'Q{lag}']=lb.loc[lag,'lb_stat'];r[f'p_Q{lag}']=lb.loc[lag,'lb_pvalue']
    r['passa_LB']=all(r[f'p_Q{lag}']>=.05 for lag in [12,24,36]);rows.append(r)
    for name,value,se,t in zip(f.param_names,f.params,f.bse,f.tvalues):coefs.append(dict(modelo=label,parametro=name,coeficiente=value,erro_padrao=se,t=t))
    print(r,flush=True)
pd.DataFrame(rows).sort_values('AIC').to_csv(OUT/'comparacao.csv',index=False)
pd.DataFrame(coefs).to_csv(OUT/'coeficientes.csv',index=False)
(OUT/'otimizacao.json').write_text(json.dumps(audit,indent=2),encoding='utf-8')
fig,axes=plt.subplots(5,2,figsize=(13,16));arows=[]
for ax,(label,f) in zip(axes.flat,fits.items()):
    a=acf(f.resid,nlags=48,fft=False);ax.stem(range(1,49),a[1:],basefmt=' ');ax.axhline(0,color='black',lw=.6)
    for sign in [-1,1]:ax.axhline(sign*1.96/np.sqrt(359),color='gray',ls='--')
    ax.set_title(label);ax.set_xticks([1,12,24,36,48])
    for lag in range(49):arows.append(dict(modelo=label,lag=lag,FAC=a[lag]))
fig.suptitle('FAC dos resíduos — bandas pontuais aproximadas de 95%');fig.tight_layout();fig.savefig(OUT/'graficos/fac_residuos.png',dpi=170);fig.savefig(OUT/'graficos/fac_residuos.svg');plt.close(fig)
pd.DataFrame(arows).to_csv(OUT/'fac_residuos.csv',index=False)
