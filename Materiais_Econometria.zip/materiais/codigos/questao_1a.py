"""Questão 1(a). Execute da pasta desejada; caminhos relativos a este arquivo.

python materiais/codigos/questao_1a.py          # usa a cópia preservada do FRED
python materiais/codigos/questao_1a.py --baixar # atualiza a cópia (sujeita a revisões)
"""
from pathlib import Path
import os
import sys
sys.stdout.reconfigure(encoding='utf-8')
import json
import hashlib
import statistics
from datetime import datetime, timezone
from urllib.request import urlopen

ROOT = Path(__file__).resolve().parents[1]
sys.path.append(str(ROOT / '.dependencias'))
os.environ['MPLCONFIGDIR'] = str(ROOT / '.cache_matplotlib')
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from matplotlib.ticker import FuncFormatter

OUT = ROOT / 'questao_1a'
FIG = OUT / 'graficos'
RAW = ROOT / 'dados/brutos/housing_fred_1994_2025_python.csv'
URL = 'https://fred.stlouisfed.org/graph/fredgraph.csv?id=HOUSTNSA,HOUST&cosd=1994-01-01&coed=2025-12-01'
FIG.mkdir(parents=True, exist_ok=True)
if '--baixar' in sys.argv:
    with urlopen(URL, timeout=45) as response:
        RAW.write_bytes(response.read())

raw = pd.read_csv(RAW, index_col=0, parse_dates=True)
d = raw.loc['1994-01-01':'2025-12-01', ['HOUSTNSA', 'HOUST']].copy()
expected = pd.date_range('1994-01-01', '2025-12-01', freq='MS')
assert d.index.equals(expected), 'Meses ausentes, duplicados ou fora de ordem.'
assert d.notna().all().all() and (d > 0).all().all()
d.index.name = 'data'
d['log_HOUSTNSA'] = np.log(d.HOUSTNSA)
d['log_HOUST'] = np.log(d.HOUST)
d['dlog_HOUSTNSA'] = d.log_HOUSTNSA.diff()
d['dlog_HOUST'] = d.log_HOUST.diff()
d['100_dlog_HOUSTNSA'] = 100 * d.dlog_HOUSTNSA
d['100_dlog_HOUST'] = 100 * d.dlog_HOUST
d['janela'] = np.where(d.index.year <= 2024, 'estimacao', 'avaliacao')
assert len(d.loc[:'2024-12-01']) == 372
assert d.dlog_HOUSTNSA.count() == 383
assert np.isclose(d.dlog_HOUSTNSA.sum(), np.log(d.HOUSTNSA.iloc[-1] / d.HOUSTNSA.iloc[0]))
assert np.isclose(d['100_dlog_HOUSTNSA'].std(), statistics.stdev(d['100_dlog_HOUSTNSA'].dropna()))
d.to_csv(ROOT / 'dados/housing_transformado_1994_2025.csv', float_format='%.12g')

def stats(frame):
    return pd.DataFrame({
        'N': frame.count(), 'Média': frame.mean(), 'Desvio-padrão': frame.std(ddof=1),
        'Mínimo': frame.min(), '1º quartil': frame.quantile(.25), 'Mediana': frame.median(),
        '3º quartil': frame.quantile(.75), 'Máximo': frame.max(),
        'Assimetria': frame.skew(), 'Excesso de curtose': frame.kurt(),
    }).T

def fmt(x, digits=3):
    return f'{x:,.{digits}f}'.replace(',', '_').replace('.', ',').replace('_', '.')

def md_table(table):
    rows = ['| Estatística | ' + ' | '.join(table.columns) + ' |',
            '|:--|' + '--:|' * len(table.columns)]
    for key, row in table.iterrows():
        rows.append('| ' + key + ' | ' + ' | '.join(fmt(x, 0 if key == 'N' else 3) for x in row) + ' |')
    return '\n'.join(rows)

tables = {}
for label, frame in [('completa_1994_2025', d), ('estimacao_1994_2024', d.loc[:'2024-12-01'])]:
    level = stats(frame[['HOUSTNSA', 'HOUST']])
    growth = stats(frame[['100_dlog_HOUSTNSA', '100_dlog_HOUST']])
    level.columns = ['h: HOUSTNSA (mil unidades no mês)', 's: HOUST (mil unidades, taxa anualizada)']
    growth.columns = ['100 Δln(h)', '100 Δln(s)']
    level.to_csv(OUT / f'estatisticas_nivel_{label}.csv', float_format='%.12g')
    growth.to_csv(OUT / f'estatisticas_dlog_{label}.csv', float_format='%.12g')
    tables[label] = (level, growth)

plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 10,
    'axes.spines.top': False, 'axes.spines.right': False, 'axes.titleweight': 'bold',
    'axes.labelcolor': '#334155', 'text.color': '#172b42', 'axes.edgecolor': '#cbd5e1',
    'svg.fonttype': 'none', 'figure.facecolor': 'white'})
BLUE, ORANGE = '#176899', '#d97927'
specs = [
    ('01_houstnsa_nivel', 'HOUSTNSA | Nível', 'Mil unidades no mês', 'HOUSTNSA', BLUE),
    ('02_houst_nivel', 'HOUST | Nível', 'Mil unidades — taxa anualizada', 'HOUST', ORANGE),
    ('03_houstnsa_log', 'HOUSTNSA | Logaritmo natural', 'ln(HOUSTNSA)', 'log_HOUSTNSA', BLUE),
    ('04_houst_log', 'HOUST | Logaritmo natural', 'ln(HOUST)', 'log_HOUST', ORANGE),
    ('05_houstnsa_diferenca_log', 'HOUSTNSA | Primeira diferença do log', '100 × Δln  (≈ % ao mês)', '100_dlog_HOUSTNSA', BLUE),
    ('06_houst_diferenca_log', 'HOUST | Primeira diferença do log', '100 × Δln  (≈ % ao mês)', '100_dlog_HOUST', ORANGE),
]
def draw(ax, spec):
    _, title, ylabel, a, color = spec
    ax.plot(d.index, d[a], color=color, lw=1.2)
    ax.axvspan(pd.Timestamp('2025-01-01'), pd.Timestamp('2025-12-31'), color='#d8e1ec', alpha=.75)
    ax.axvline(pd.Timestamp('2025-01-01'), color='#72859c', lw=.7, ls='--')
    if a.startswith('100_'):
        ax.axhline(0, color='#94a3b8', lw=.6)
        ax.set_ylim(-45, 55)
    ax.set_title(title, loc='left', pad=13, fontsize=12)
    ax.set_ylabel(ylabel)
    ax.grid(axis='y', alpha=.18)
    lo, hi = ax.get_ylim()
    ax.set_ylim(lo, hi + .10 * (hi - lo))
    ax.set_xlim(pd.Timestamp('1994-01-01'), pd.Timestamp('2025-12-31'))
    ticks = [pd.Timestamp(f'{y}-01-01') for y in [1994, 1998, 2002, 2006, 2010, 2014, 2018, 2022, 2025]]
    ax.set_xticks(ticks)
    ax.xaxis.set_major_formatter(mdates.DateFormatter('%Y'))
    ax.yaxis.set_major_formatter(FuncFormatter(lambda v, pos: fmt(v, 2 if a.startswith('log_') else 0)))

for spec in specs:
    fig, ax = plt.subplots(figsize=(12, 4.6))
    draw(ax, spec)
    fig.subplots_adjust(left=.09, right=.985, top=.87, bottom=.16)
    fig.text(.09, .035, 'Fonte: FRED (HOUSTNSA e HOUST). 1994M1–2025M12. Faixa cinza: avaliação em 2025.', fontsize=9, color='#52667c')
    for ext in ['png', 'svg']:
        fig.savefig(FIG / f'{spec[0]}.{ext}', dpi=180)
    plt.close(fig)

fig, axes = plt.subplots(3, 2, figsize=(16, 12))
for ax, spec in zip(axes.flat, specs):
    draw(ax, spec)
fig.subplots_adjust(left=.075, right=.985, top=.88, bottom=.075, hspace=.42, wspace=.24)
fig.suptitle('Construção residencial nos Estados Unidos', x=.075, y=.979, ha='left', fontsize=19, weight='bold')
fig.text(.075, .946, '1994M1–2025M12 • Unidades originais • Níveis e logs com escalas próprias; diferenças do log com escala comum', fontsize=11)
fig.text(.075, .914, 'HOUSTNSA: sem ajuste sazonal', color=BLUE, fontsize=12, weight='bold')
fig.text(.58, .914, 'HOUST: dessazonalizada e anualizada', color=ORANGE, fontsize=12, weight='bold')
fig.text(.075, .025, 'Fonte: FRED. Faixa cinza: avaliação em 2025. Níveis absolutos não são diretamente comparáveis entre as séries.', fontsize=10, color='#52667c')
for ext in ['png', 'svg']:
    fig.savefig(FIG / f'painel_questao_1a.{ext}', dpi=180)
plt.close(fig)

level, growth = tables['completa_1994_2025']
lev_train, gro_train = tables['estimacao_1994_2024']
sdh, sds = growth.loc['Desvio-padrão']
report = f'''# Questão 1(a) — Análise preliminar e comparação das séries

## Dados e amostra

Foram utilizadas as séries mensais HOUSTNSA e HOUST, obtidas diretamente do FRED, de janeiro de 1994 a dezembro de 2025. A amostra contém 384 observações em nível para cada série, sem valores ausentes. Definimos h_t = HOUSTNSA_t e s_t = HOUST_t. As estatísticas principais descrevem a amostra completa; a janela de estimação termina em dezembro de 2024 (372 meses), e as 12 observações de 2025 permanecem reservadas à avaliação fora da amostra. Nenhum modelo foi estimado nesta etapa.

## Unidades e comparabilidade

HOUSTNSA mede o total de unidades habitacionais iniciadas no mês, em milhares, sem ajuste sazonal. HOUST mede o ritmo de construção do mês como taxa anualizada dessazonalizada, também em milhares. Portanto, a frequência de observação é mensal nas duas séries, mas a escala temporal da medida é diferente: uma mede o mês e a outra expressa um ritmo anualizado. HOUST não é o total realizado no ano nem uma soma móvel de 12 meses.

Mantivemos as unidades originais e apresentamos seis gráficos separados: nível, log e primeira diferença do log de cada série. HOUST não foi dividido por 12. Os gráficos em nível e em log têm eixos verticais próprios, explicitamente identificados. Isso permite examinar a trajetória e a sazonalidade de cada série, mas não torna seus níveis absolutos diretamente comparáveis; tampouco se deve comparar a amplitude visual sem observar as escalas dos eixos.

Para uma comparação quantitativa legítima entre as séries, usamos as primeiras diferenças do log, que são adimensionais e invariantes à multiplicação por uma constante positiva. Os dois gráficos dessa transformação usam a mesma escala vertical. Tomar somente o log não elimina a diferença de escala dos níveis. Para qualquer constante c > 0:

**Δln(c x_t) = [ln(c) + ln(x_t)] − [ln(c) + ln(x_{{t−1}})] = Δln(x_t).**

Calculamos Δln(x_t) = ln(x_t) − ln(x_{{t−1}}). Nas tabelas e gráficos, multiplicamos essa diferença por 100 para expressá-la em pontos logarítmicos, aproximadamente a variação percentual mensal. A variação percentual exata é 100[exp(Δln(x_t)) − 1]; a aproximação é menos precisa quando a mudança é grande. Não se trata de diferença sazonal de 12 meses.

## Estatísticas descritivas — amostra completa

Níveis nas unidades originais: h em milhares de unidades no mês; s em milhares de unidades como taxa anualizada dessazonalizada. Médias, desvios-padrão, quartis e extremos em nível devem ser interpretados dentro da unidade de cada série, sem comparação direta entre suas magnitudes.

{md_table(level)}

Primeiras diferenças do log, multiplicadas por 100:

{md_table(growth)}

O desvio-padrão é amostral (divisor N−1). Os quartis usam interpolação linear; assimetria e excesso de curtose usam as correções amostrais do pandas (a normal tem excesso de curtose zero). Existem 383 diferenças, de 1994M2 a 2025M12: não se utiliza dezembro de 1993 para preencher a primeira variação. Os cálculos usam a precisão integral; apenas a apresentação foi arredondada.

## Gráficos

![Seis gráficos separados, mantendo as unidades originais](graficos/painel_questao_1a.png)

Cada gráfico também está disponível individualmente, em PNG e SVG, na pasta `graficos`: `01_houstnsa_nivel`, `02_houst_nivel`, `03_houstnsa_log`, `04_houst_log`, `05_houstnsa_diferenca_log` e `06_houst_diferenca_log`.

## Interpretação

Examinadas separadamente em suas unidades originais, as séries apresentam trajetórias de longo prazo semelhantes, com expansão até meados dos anos 2000, forte retração posterior e recuperação ao longo dos anos seguintes. A série bruta exibe oscilações recorrentes dentro do ano, compatíveis com sazonalidade; a série ajustada torna mais visível o movimento subjacente da atividade. Essa leitura compara a evolução temporal, não a magnitude dos níveis entre séries.

O log preserva os movimentos gerais e permite interpretar variações relativas, reduzindo o peso visual de diferenças absolutas nos períodos de nível mais elevado. Entretanto, o log não elimina a sazonalidade. A primeira diferença do log reduz visualmente os movimentos persistentes de nível e oscila ao redor de valores próximos de zero, mas o padrão sazonal da série bruta permanece. A inspeção gráfica, isoladamente, não comprova estacionariedade nem ausência de sazonalidade residual.

O desvio-padrão de 100Δln(h_t) é {fmt(sdh)} pontos logarítmicos, contra {fmt(sds)} em 100Δln(s_t), cerca de {fmt(sdh/sds, 2)} vezes maior. Essa diferença é compatível com a remoção de parte importante das oscilações sazonais na série ajustada, mas não deve ser interpretada como uma decomposição exata da variância em componente sazonal e não sazonal.

## Apêndice — somente a janela de estimação (1994M1–2024M12)

Estatísticas preservadas para apoiar decisões futuras de modelagem sem utilizar 2025. São 372 níveis e 371 primeiras diferenças.

{md_table(lev_train)}

{md_table(gro_train)}

## Fontes e reprodutibilidade

- FRED — HOUSTNSA: https://fred.stlouisfed.org/series/HOUSTNSA
- FRED — HOUST: https://fred.stlouisfed.org/series/HOUST
- Download direto: {URL}
- Fonte original das séries: U.S. Census Bureau e U.S. Department of Housing and Urban Development.
- Data de extração e hash do arquivo original: `../dados/metadados_fred.json`.
- Código: `../codigos/questao_1a.py`.
- Os dados representam a versão disponível na extração, sujeita a revisões; não são uma reconstrução das informações disponíveis em tempo real em dezembro de 2024. O período de 2025 está separado cronologicamente, mas uma avaliação estritamente em tempo real exigiria vintages históricos.
'''
(OUT / 'resposta_questao_1a.md').write_text(report, encoding='utf-8')

meta = {
    'download_url': URL, 'source_pages': [f'https://fred.stlouisfed.org/series/{x}' for x in ['HOUSTNSA','HOUST']],
    'raw_file': RAW.name, 'raw_file_download_time_utc': datetime.fromtimestamp(RAW.stat().st_mtime, timezone.utc).isoformat(),
    'sha256': hashlib.sha256(RAW.read_bytes()).hexdigest(),
    'sample': ['1994-01-01','2025-12-01'], 'n_levels': 384, 'n_log_differences':383,
    'estimation_end':'2024-12-01', 'test_period':['2025-01-01','2025-12-01'],
    'missing_values':0, 'log':'natural', 'scale_policy':'original units; no division of HOUST by 12; six separate charts',
    'vintage':'latest available at download, not real-time vintages',
    'versions': {'python':sys.version.split()[0], 'pandas':pd.__version__, 'numpy':np.__version__, 'matplotlib':matplotlib.__version__}
}
(ROOT / 'dados/metadados_fred.json').write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding='utf-8')
print(md_table(level))
print(md_table(growth))
print('Validações concluídas: 384 níveis, 383 diferenças, 372 meses de estimação, 12 de avaliação; sem faltantes; seis gráficos nas unidades originais.')
