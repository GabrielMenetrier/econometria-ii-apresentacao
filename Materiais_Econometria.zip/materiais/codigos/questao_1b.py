"""FAC/FACP: unidades originais, janela de estimação 1994M1–2024M12.

FAC: autocovariâncias com divisor N. FACP: Yule–Walker, sem ajuste N-k.
Reproduzir com Python + numpy + pandas + matplotlib; sem novo download.
"""
from pathlib import Path
import sys
import os
import json
import hashlib

sys.stdout.reconfigure(encoding='utf-8')
ROOT = Path(__file__).resolve().parents[1]
sys.path.append(str(ROOT / '.dependencias'))
os.environ['MPLCONFIGDIR'] = str(ROOT / '.cache_matplotlib')
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter

OUT = ROOT / 'questao_1b'
FIG = OUT / 'graficos'
FIG.mkdir(parents=True, exist_ok=True)
RAW = ROOT / 'dados/brutos/housing_fred_1994_2025_python.csv'
d = pd.read_csv(RAW, index_col=0, parse_dates=True).loc['1994-01-01':'2024-12-01', ['HOUSTNSA', 'HOUST']]
assert d.index.equals(pd.date_range('1994-01-01', '2024-12-01', freq='MS'))
assert d.notna().all().all() and (d > 0).all().all()
LAGS = 48

def correlogram(x):
    z = np.asarray(x, dtype=float)
    z = z - z.mean()
    acf = np.array([z[k:] @ z[:len(z)-k] / (z @ z) for k in range(LAGS+1)])
    pacf = np.ones(LAGS+1)
    for k in range(1, LAGS+1):
        toeplitz = acf[np.abs(np.arange(k)[:, None] - np.arange(k)[None, :])]
        pacf[k] = np.linalg.solve(toeplitz, acf[1:k+1])[-1]
    # Verificação independente por recursão de Durbin–Levinson.
    previous = np.empty(0)
    recursive = [1.]
    for k in range(1, LAGS+1):
        reflection = (acf[k] - previous @ acf[1:k][::-1]) / (1 - previous @ acf[1:k])
        recursive.append(reflection)
        previous = np.r_[previous - reflection * previous[::-1], reflection]
    assert np.allclose(pacf, recursive, atol=1e-10)
    assert np.isclose(acf[0], 1) and np.isclose(acf[1], pacf[1])
    assert np.all(np.abs(acf) <= 1 + 1e-12) and np.all(np.abs(pacf) <= 1 + 1e-12)
    return acf, pacf

BLUE, ORANGE = '#176899', '#d97927'
series = [
    ('h_nivel', 'hₜ = HOUSTNSA | nível', d.HOUSTNSA, BLUE),
    ('s_nivel', 'sₜ = HOUST | nível', d.HOUST, ORANGE),
    ('dlog_h', 'Δln(hₜ) | primeira diferença do log', np.log(d.HOUSTNSA).diff().dropna(), BLUE),
    ('dlog_s', 'Δln(sₜ) | primeira diferença do log', np.log(d.HOUST).diff().dropna(), ORANGE),
    ('log_h', 'ln(hₜ) | logaritmo natural', np.log(d.HOUSTNSA), BLUE),
    ('log_s', 'ln(sₜ) | logaritmo natural', np.log(d.HOUST), ORANGE),
]
results = {}
rows = []
for key, label, x, color in series:
    acf, pacf = correlogram(x)
    results[key] = {'FAC': acf, 'FACP': pacf, 'N': len(x)}
    for lag in range(LAGS+1):
        rows.append({'serie':key, 'defasagem':lag, 'FAC':acf[lag], 'FACP':pacf[lag], 'N':len(x), 'limite_95_ruido_branco':1.96 / np.sqrt(len(x))})
pd.DataFrame(rows).to_csv(OUT / 'coeficientes_fac_facp.csv', index=False, float_format='%.12g')

plt.rcParams.update({'font.family':'DejaVu Sans', 'font.size':10, 'axes.spines.top':False,
    'axes.spines.right':False, 'axes.titleweight':'bold', 'text.color':'#172b42',
    'axes.labelcolor':'#334155', 'axes.edgecolor':'#cbd5e1', 'svg.fonttype':'none'})

def draw(ax, spec, kind):
    key, label, x, color = spec
    values = results[key][kind][1:]
    k = np.arange(1, LAGS+1)
    limit = 1.96 / np.sqrt(len(x))
    ax.axhspan(-limit, limit, color='#e6edf5', zorder=0)
    for sign in [-1, 1]:
        ax.axhline(sign * limit, color='#8394a8', ls='--', lw=.8)
    ax.axhline(0, color='#64748b', lw=.7)
    for seasonal_lag in [12,24,36,48]:
        ax.axvline(seasonal_lag, color='#cbd5e1', ls=':', lw=.9, zorder=0)
    ax.vlines(k, 0, values, color=color, lw=1.3)
    ax.scatter(k, values, color=color, s=11, zorder=3)
    ax.set(xlim=(.3,48.7), ylim=(-.65,1.05), xlabel='Defasagem (meses)', ylabel=kind)
    ax.set_xticks([1,6,12,18,24,30,36,42,48])
    ax.set_yticks([-.5,0,.5,1])
    ax.yaxis.set_major_formatter(FuncFormatter(lambda v, pos: f'{v:.1f}'.replace('.',',')))
    ax.set_title(f'{kind} — {label}', fontsize=11, loc='left', pad=12)
    ax.grid(axis='y', alpha=.12)

def save(fig, name):
    for ext in ['png','svg']:
        fig.savefig(FIG / f'{name}.{ext}', dpi=170, facecolor='white')
    plt.close(fig)

for spec in series:
    for kind in ['FAC','FACP']:
        fig, ax = plt.subplots(figsize=(10,4))
        draw(ax, spec, kind)
        fig.subplots_adjust(left=.09, right=.98, top=.86, bottom=.22)
        fig.text(.09,.035,'FRED • Estimação até 2024M12 • Bandas pontuais: ±1,96/√N sob ruído branco • Lag 0 omitido',fontsize=9,color='#52667c')
        save(fig, f'{spec[0]}_{kind.lower()}')

for name, selection, title in [
    ('painel_niveis_diferencas', series[:4], 'FAC e FACP | Níveis e primeiras diferenças do log'),
    ('painel_logs', series[4:], 'FAC e FACP | Complemento: séries em log'),
]:
    fig, axes = plt.subplots(len(selection),2,figsize=(14,3.2*len(selection)+1.2))
    for pair, spec in zip(axes,selection):
        for ax,kind in zip(pair,['FAC','FACP']):
            draw(ax,spec,kind)
    fig.subplots_adjust(left=.065,right=.98,top=.90 if len(selection)==4 else .83,bottom=.075 if len(selection)==4 else .12,hspace=.55,wspace=.20)
    fig.suptitle(title,x=.065,y=.975,ha='left',fontsize=18,weight='bold')
    fig.text(.065,.941 if len(selection)==4 else .919,'1994M1–2024M12 • 48 defasagens • HOUSTNSA em azul; HOUST em laranja',fontsize=11)
    fig.text(.065,.025,'Fonte: FRED. Bandas: ±1,96/√N, referência pontual de 95% sob ruído branco; não são um teste de raiz unitária.',fontsize=10,color='#52667c')
    save(fig,name)

meta = {'sample_levels_logs':['1994-01-01','2024-12-01'], 'sample_differences':['1994-02-01','2024-12-01'],
    'N_levels_logs':372,'N_differences':371,'max_lag':LAGS,
    'acf':'centered products with fixed denominator sum((x-mean(x))^2)',
    'pacf':'Yule-Walker with autocovariance divisor N (unadjusted / method mle); verified by Durbin-Levinson',
    'bands':'pointwise +/-1.96/sqrt(N) under white noise; not simultaneous; not a stationarity test',
    'units':'original; no rescaling of HOUST; correlations dimensionless',
    'input_sha256':hashlib.sha256(RAW.read_bytes()).hexdigest(),
    'versions':{'numpy':np.__version__,'pandas':pd.__version__,'matplotlib':matplotlib.__version__}}
(OUT / 'metodologia.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2),encoding='utf-8')
for key, *_ in series:
    print(key, 'N=',results[key]['N'])
    for kind in ['FAC','FACP']:
        print(kind, {k:round(float(results[key][kind][k]),4) for k in [1,2,3,6,11,12,13,24,36,48]})
print('Verificação: FACP por Yule–Walker coincide com Durbin–Levinson nas seis séries.')
