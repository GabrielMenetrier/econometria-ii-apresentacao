"""Diagnóstico residual e reidentificação limitada, sem usar dados de 2025."""
from pathlib import Path
import sys,os,json,warnings
sys.stdout.reconfigure(encoding='utf-8')
ROOT=Path(__file__).resolve().parents[1]
sys.path.append(str(ROOT/'.dependencias'))
os.environ['MPLCONFIGDIR']=str(ROOT/'.cache_matplotlib')
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.stats import chi2,probplot
from statsmodels.tsa.arima.model import ARIMA,ARIMAResults
from statsmodels.stats.diagnostic import acorr_ljungbox,het_arch
from statsmodels.stats.stattools import jarque_bera
OUT=ROOT/'questao_2d'
for folder in ['modelos','graficos']:
    (OUT/folder).mkdir(parents=True,exist_ok=True)
w=pd.read_csv(ROOT/'questao_2b/amostra_efetiva_comum.csv',index_col=0,parse_dates=True).iloc[:,0].asfreq('MS')
assert len(w)==371 and w.index[-1]==pd.Timestamp('2024-12-01')
def acf(x,lags=48):
    z=np.asarray(x)-np.mean(x)
    return np.array([z[k:]@z[:len(z)-k]/(z@z) for k in range(lags+1)])
rows=[]; tests=[]; fits={}; attempts=[]
def diagnose(fit,label,p,q,drift,stage):
    e=np.asarray(fit.resid)
    assert len(e)==371 and np.isfinite(e).all()
    r=acf(e)
    lb=acorr_ljungbox(e,lags=[6,12,24],model_df=p+q,return_df=True)
    row={'modelo':label,'p':p,'q':q,'drift':drift,'etapa':stage,'N':len(e),'AIC':float(fit.aic),'BIC':float(fit.bic),'sigma2':float(fit.scale)}
    for h in [6,12,24]:
        manual=len(e)*(len(e)+2)*sum(r[k]**2/(len(e)-k) for k in range(1,h+1))
        assert np.isclose(manual,lb.loc[h,'lb_stat'],atol=1e-10)
        assert np.isclose(chi2.sf(manual,h-p-q),lb.loc[h,'lb_pvalue'])
        row[f'Q{h}']=float(lb.loc[h,'lb_stat'])
        row[f'p_Q{h}']=float(lb.loc[h,'lb_pvalue'])
        tests.append({'modelo':label,'teste':'Ljung-Box','defasagem':h,'estatistica':row[f'Q{h}'],'gl':h-p-q,'p_valor':row[f'p_Q{h}']})
    for h in [6,12,24]:
        with warnings.catch_warnings():
            warnings.simplefilter('ignore',FutureWarning)
            lm,pv,f,fp=het_arch(e,nlags=h,ddof=p+q)
        sq=e**2
        X=np.column_stack([np.ones(len(e)-h)]+[sq[h-k:len(e)-k] for k in range(1,h+1)])
        y=sq[h:]
        b=np.linalg.lstsq(X,y,rcond=None)[0]
        R2=1-np.sum((y-X@b)**2)/np.sum((y-y.mean())**2)
        assert np.isclose(lm,(len(y)-p-q)*R2,atol=1e-7)
        row[f'ARCH{h}']=float(lm); row[f'p_ARCH{h}']=float(pv)
        tests.append({'modelo':label,'teste':'ARCH-LM','defasagem':h,'estatistica':float(lm),'gl':h,'p_valor':float(pv)})
    jb,jbp,sk,ku=jarque_bera(e)
    row.update({'media_residuo':float(e.mean()),'desvio_residuo':float(e.std(ddof=1)),
                'JB':float(jb),'p_JB':float(jbp),'assimetria':float(sk),'curtose':float(ku),
                'passa_LB_5pct':all(row[f'p_Q{h}']>.05 for h in [6,12,24]),
                'passa_ARCH12_5pct':row['p_ARCH12']>.05,
                'raiz_AR_min':float(min(abs(fit.arroots))) if p else None,
                'raiz_MA_min':float(min(abs(fit.maroots))) if q else None,
                'distancia_AR_MA_min':float(np.min(abs(fit.arroots[:,None]-fit.maroots[None,:]))) if p and q else None})
    row['passa_conjunto_5pct']=row['passa_LB_5pct'] and row['passa_ARCH12_5pct']
    rows.append(row);fits[label]=fit
    pd.DataFrame({'data':w.index,'residuo':e,'residuo_padronizado':fit.filter_results.standardized_forecasts_error[0]}).to_csv(OUT/'modelos'/(label.replace(' ','_')+'_residuos.csv'),index=False)
    print(label,'AIC',round(fit.aic,2),'LB',[round(row[f'p_Q{h}'],5) for h in [6,12,24]],'ARCH12',f'{row["p_ARCH12"]:.3g}',flush=True)

prior=pd.read_csv(ROOT/'questao_2b/resultados_completos.csv')
for _,r in prior.iterrows():
    p,q=int(r.p),int(r.q);drift=bool(r.drift)
    slug=f'arima_{p}_1_{q}_'+('drift' if drift else 'sem_drift')
    fit=ARIMAResults.load(ROOT/'questao_2b/modelos'/(slug+'.pickle'))
    diagnose(fit,r.modelo,p,q,drift,'modelos_2b')

# Extensões finitas: AR/MA de ordens até 5 e mistos com p+q<=5.
# Isso mantém positivos os graus de liberdade do Ljung-Box até na defasagem 6.
new_orders=[(2,1),(1,2),(2,2),(3,1),(1,3),(3,2),(2,3),(0,3),(4,0),(5,0),(0,4),(0,5)]
for p,q in new_orders:
    label=f'ARIMA({p},1,{q}) sem drift'
    model=ARIMA(w,order=(p,0,q),trend='n',enforce_stationarity=True,enforce_invertibility=True,concentrate_scale=True)
    candidates=[]
    for start in [None,np.zeros(p+q)]:
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter('always')
            try:
                fit=model.fit(start_params=start,method='statespace',cov_type='oim',method_kwargs={'method':'lbfgs','maxiter':2000,'pgtol':1e-8,'factr':1e4,'disp':0})
                conv=bool(fit.mle_retvals.get('converged',False))
                attempts.append({'modelo':label,'converged':conv,'llf':float(fit.llf),'warnings':[str(x.message) for x in caught]})
                if conv and np.isfinite(fit.bse).all() and (fit.bse>0).all():
                    candidates.append(fit)
            except Exception as exc:
                attempts.append({'modelo':label,'error':str(exc)})
    if not candidates:
        print('SEM SOLUCAO VALIDA',label,flush=True);continue
    fit=max(candidates,key=lambda x:x.llf)
    assert fit.nobs_effective==371 and fit.loglikelihood_burn==0
    fit.save(OUT/'modelos'/f'arima_{p}_1_{q}_sem_drift.pickle')
    (OUT/'modelos'/f'arima_{p}_1_{q}_resumo.txt').write_text(fit.summary().as_text(),encoding='utf-8')
    diagnose(fit,label,p,q,False,'reidentificacao')

results=pd.DataFrame(rows).sort_values('AIC')
results.to_csv(OUT/'comparacao_diagnosticos.csv',index=False,float_format='%.12g')
pd.DataFrame(tests).to_csv(OUT/'testes_residuos.csv',index=False,float_format='%.12g')
(OUT/'otimizacao.json').write_text(json.dumps(attempts,ensure_ascii=False,indent=2),encoding='utf-8')
print('\nRANKING',results[['modelo','AIC','BIC','p_Q6','p_Q12','p_Q24','p_ARCH12','passa_conjunto_5pct']].to_string(index=False),flush=True)

plt.rcParams.update({'font.family':'DejaVu Sans','axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none','font.size':10})
initial='ARIMA(0,1,1) sem drift'
eligible=results[results.passa_LB_5pct]
alternative=str(eligible.iloc[0].modelo) if len(eligible) else str(results.iloc[0].modelo)
if alternative==initial:
    alternative=str(results[results.modelo!=initial].iloc[0].modelo)
acfrows=[]
for label in [initial,alternative]:
    fit=fits[label];e=np.asarray(fit.resid);r=acf(e);r2=acf(e**2)
    for k in range(49):
        acfrows.append({'modelo':label,'lag':k,'FAC_residuos':r[k],'FAC_residuos_quadrados':r2[k]})
    fig,axes=plt.subplots(2,2,figsize=(13,8))
    axes[0,0].plot(w.index,e,color='#176899',lw=.85)
    axes[0,0].axhline(0,color='#64748b',lw=.7)
    axes[0,0].set_title('Resíduos: erros de previsão de um passo',loc='left')
    axes[0,0].set_ylabel('Unidades de HOUST')
    axes[0,1].plot(w.index,pd.Series(e,index=w.index).rolling(24).std(),color='#d97927',lw=1.3)
    axes[0,1].set_title('Desvio-padrão móvel: janela de 24 meses',loc='left')
    for ax,v,title in [(axes[1,0],r,'FAC dos resíduos'),(axes[1,1],r2,'FAC dos resíduos ao quadrado')]:
        limit=1.96/np.sqrt(len(e))
        ax.axhspan(-limit,limit,color='#e6edf5')
        ax.axhline(0,color='#64748b',lw=.7)
        for sign in [-1,1]:
            ax.axhline(sign*limit,color='#8394a8',lw=.8,ls='--')
        ax.vlines(range(1,49),0,v[1:],color='#176899')
        ax.scatter(range(1,49),v[1:],color='#176899',s=10)
        for k in [6,12,24]:
            ax.axvline(k,color='#cbd5e1',ls=':',lw=.7)
        ax.set(title=title,xlabel='Defasagem (meses)',ylim=(-.3,.4),xticks=[1,6,12,18,24,30,36,42,48])
    fig.suptitle('Diagnóstico | '+label,x=.07,y=.98,ha='left',fontsize=18,weight='bold')
    fig.text(.07,.935,'HOUST original • Resíduos 1994M2–2024M12 • N = 371 • Bandas da FAC: referência pontual de 95%',fontsize=10)
    fig.subplots_adjust(left=.07,right=.985,top=.86,bottom=.10,hspace=.40,wspace=.22)
    fig.text(.07,.025,'Fonte: FRED; cálculos próprios. A variabilidade dos resíduos e sua dependência temporal são diagnósticos distintos.',fontsize=9)
    slug='inicial' if label==initial else 'alternativa'
    for ext in ['png','svg']:
        fig.savefig(OUT/'graficos'/f'diagnostico_{slug}.{ext}',dpi=170,facecolor='white')
    plt.close(fig)
pd.DataFrame(acfrows).to_csv(OUT/'fac_residuos.csv',index=False,float_format='%.12g')
coef=[]
for label in [initial,alternative]:
    fit=fits[label]
    for name in fit.params.index:
        coef.append({'modelo':label,'parametro':name,'estimativa':float(fit.params[name]),'EP_OIM':float(fit.bse[name]),'t':float(fit.tvalues[name])})
pd.DataFrame(coef).to_csv(OUT/'coeficientes_modelos_destacados.csv',index=False,float_format='%.12g')
meta={'initial':initial,'alternative_diagnostic':alternative,'primary_residual':'raw one-step prediction errors (fit.resid); N=371',
      'alpha':.05,'LB_lags':[6,12,24],'LB_df':'h-p-q; drift not subtracted',
      'ARCH_primary_lags':12,'ARCH_sensitivity_lags':[6,24],'ARCH_ddof':'p+q','ARCH_LM_formula':'(N-h-p-q)*R^2; auxiliary regression has N-h rows',
      'notes':'No use of 2025; residual tests after model search are exploratory; ARIMA restrictions maintained; JB supplemental only',
      'passing_count':int(results.passa_conjunto_5pct.sum())}
(OUT/'metodologia.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2),encoding='utf-8')
print('ALTERNATIVA PARA DIAGNOSTICO',alternative,'APROVADOS',meta['passing_count'])
