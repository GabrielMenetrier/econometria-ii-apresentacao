"""Raízes do modelo preferido, sem reestimação ou utilização de 2025."""
from pathlib import Path
import sys
import os
import json
sys.stdout.reconfigure(encoding='utf-8')
ROOT=Path(__file__).resolve().parents[1]
sys.path.append(str(ROOT/'.dependencias'))
os.environ['MPLCONFIGDIR']=str(ROOT/'.cache_matplotlib')
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter
from statsmodels.tsa.arima.model import ARIMAResults
OUT=ROOT/'questao_2c'
(OUT/'graficos').mkdir(parents=True,exist_ok=True)
fit=ARIMAResults.load(ROOT/'questao_2b/modelos/arima_0_1_1_sem_drift.pickle')
assert fit.model.order==(0,0,1) and fit.nobs==371
theta=float(fit.params['ma.L1'])
ar_roots=np.polynomial.polynomial.polyroots([1.])
ma_roots=np.polynomial.polynomial.polyroots([1.,theta])
integration_roots=np.polynomial.polynomial.polyroots([1.,-1.])
assert len(ar_roots)==0 and len(fit.arroots)==0
assert np.allclose(ma_roots,fit.maroots)
assert np.allclose(1+theta*ma_roots,0)
assert np.all(np.abs(ma_roots)>1)
root=float(ma_roots[0])
inverse=1/root
assert np.isclose(inverse,-theta)
pd.DataFrame([
    {'polinomio':'AR da parte ARMA: Phi(z)=1','raiz_real':np.nan,'raiz_imaginaria':np.nan,'modulo':np.nan,'inversa_real':np.nan,'inversa_imaginaria':np.nan,'observacao':'Sem raízes: p=0; não representar como raiz zero'},
    {'polinomio':'MA: Theta(z)=1+theta*z','raiz_real':root,'raiz_imaginaria':0.,'modulo':abs(root),'inversa_real':inverse,'inversa_imaginaria':0.,'observacao':'Invertível'},
    {'polinomio':'Diferenciacao: 1-z','raiz_real':1.,'raiz_imaginaria':0.,'modulo':1.,'inversa_real':1.,'inversa_imaginaria':0.,'observacao':'Raiz unitária imposta por d=1; nível não estacionário'}
]).to_csv(OUT/'raizes_modelo_preferido.csv',index=False,float_format='%.12g')
meta={'modelo':'ARIMA(0,1,1) sem drift em HOUST original','theta1':theta,'AR_polynomial':[1.],
      'MA_polynomial':[1.,theta],'differencing_polynomial':[1.,-1.],
      'ARMA_stationary':True,'level_stationary':False,'MA_invertible':True,
      'AR_MA_cancellation':False,'reason':'p=0, não há raízes AR da parte ARMA',
      'MA_root':root,'MA_inverse_root':inverse,'distance_inverse_MA_to_unit_root':1-inverse,
      'MA_polynomial_at_unit_root':1+theta,
      'source_model':'../questao_2b/modelos/arima_0_1_1_sem_drift.pickle',
      'no_refit':True,'training_end':'2024-12-01'}
(OUT/'verificacao_raizes.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2),encoding='utf-8')
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'svg.fonttype':'none','text.color':'#173047','axes.labelcolor':'#334155'})
fig,ax=plt.subplots(figsize=(9,8))
angles=np.linspace(0,2*np.pi,800)
ax.fill(np.cos(angles),np.sin(angles),color='#edf3f8',zorder=0)
ax.plot(np.cos(angles),np.sin(angles),color='#64748b',lw=1.5,label='Círculo unitário |z| = 1')
ax.axhline(0,color='#94a3b8',lw=.8)
ax.axvline(0,color='#94a3b8',lw=.8)
ax.scatter([inverse],[0],s=100,color='#d97927',marker='o',zorder=5,label='Raiz inversa MA')
ax.scatter([1],[0],s=150,color='#176899',marker='X',zorder=5,label='Fator de diferenciação (1 − B)')
ax.annotate(f'MA: {inverse:.4f}'.replace('.',','),xy=(inverse,0),xytext=(.12,.28),
            arrowprops={'arrowstyle':'->','color':'#d97927'},color='#a55112',fontsize=12)
ax.annotate('Diferenciação: 1,0000',xy=(1,0),xytext=(.18,-.38),
            arrowprops={'arrowstyle':'->','color':'#176899'},color='#176899',fontsize=12)
ax.text(-1.12,1.08,'AR da parte ARMA: sem raízes (p = 0)',fontsize=11)
ax.set(xlim=(-1.22,1.22),ylim=(-1.18,1.18),xlabel='Parte real',ylabel='Parte imaginária')
ax.set_aspect('equal',adjustable='box')
for axis in [ax.xaxis,ax.yaxis]:
    axis.set_major_formatter(FuncFormatter(lambda x,pos:f'{x:.1f}'.replace('.',',')))
ax.grid(alpha=.15)
ax.legend(loc='upper center',bbox_to_anchor=(.5,-.12),ncol=1,frameon=False,fontsize=10)
fig.suptitle('Raízes inversas | ARIMA(0,1,1) sem drift',x=.10,y=.97,ha='left',fontsize=18,weight='bold')
fig.text(.10,.925,'HOUST original • Estimação até 2024M12 • θ₁ = '+f'{theta:.6f}'.replace('.',','),fontsize=11)
fig.subplots_adjust(left=.1,right=.96,top=.87,bottom=.23)
fig.text(.10,.025,'MA dentro do círculo: invertível. Diferenciação na borda: sₜ não estacionário; Δsₜ estacionário no modelo.',fontsize=9)
for ext in ['png','svg']:
    fig.savefig(OUT/'graficos'/('raizes_inversas.'+ext),dpi=180,facecolor='white')
plt.close(fig)
print(json.dumps(meta,ensure_ascii=False,indent=2))
