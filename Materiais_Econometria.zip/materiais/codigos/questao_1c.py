"""Perfis médios mensais e seasonal subseries plots, estimação 1994–2024."""
from pathlib import Path
import os
import sys
import json
import hashlib
sys.stdout.reconfigure(encoding='utf-8')
ROOT = Path(__file__).resolve().parents[1]
sys.path.append(str(ROOT / '.dependencias'))
os.environ['MPLCONFIGDIR'] = str(ROOT / '.cache_matplotlib')
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter
from matplotlib.lines import Line2D

OUT = ROOT / 'questao_1c'
FIG = OUT / 'graficos'
FIG.mkdir(parents=True, exist_ok=True)
RAW = ROOT / 'dados/brutos/housing_fred_1994_2025_python.csv'
d = pd.read_csv(RAW, index_col=0, parse_dates=True).loc['1994-01-01':'2024-12-01', ['HOUSTNSA','HOUST']]
assert d.index.equals(pd.date_range('1994-01-01','2024-12-01',freq='MS'))
assert d.notna().all().all() and (d>0).all().all()
MONTHS = ['Jan','Fev','Mar','Abr','Mai','Jun','Jul','Ago','Set','Out','Nov','Dez']
FULL = ['janeiro','fevereiro','março','abril','maio','junho','julho','agosto','setembro','outubro','novembro','dezembro']
means = d.groupby(d.index.month).mean()
counts = d.groupby(d.index.month).count()
assert (counts == 31).all().all()
relative = 100 * (means / d.mean() - 1)
assert np.allclose(means.mean(), d.mean())
assert np.allclose(relative.mean(), 0, atol=1e-10)
table = pd.DataFrame({'mes':range(1,13),'nome_mes':MONTHS,'n_por_serie':31,
    'media_HOUSTNSA':means.HOUSTNSA.values,'media_HOUST':means.HOUST.values,
    'desvio_percentual_HOUSTNSA':relative.HOUSTNSA.values,'desvio_percentual_HOUST':relative.HOUST.values})
table.to_csv(OUT / 'perfil_medio_mensal.csv',index=False,float_format='%.12g')
obs = d.copy()
obs['ano'] = d.index.year
obs['mes'] = d.index.month
obs.to_csv(OUT / 'observacoes_subseries.csv',float_format='%.12g')

def fmt(x, digits=2):
    return f'{x:,.{digits}f}'.replace(',','_').replace('.',',').replace('_','.')

plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,
    'axes.spines.right':False,'axes.titleweight':'bold','text.color':'#172b42',
    'axes.labelcolor':'#334155','axes.edgecolor':'#cbd5e1','svg.fonttype':'none'})
specs = [('HOUSTNSA','HOUSTNSA | Série bruta, sem ajuste sazonal','Mil unidades no mês','#176899'),
         ('HOUST','HOUST | Série dessazonalizada','Mil unidades — taxa anualizada','#d97927')]

def save(fig,name):
    for ext in ['png','svg']:
        fig.savefig(FIG / f'{name}.{ext}',dpi=180,facecolor='white')
    plt.close(fig)

def subseries(ax,spec):
    key,title,unit,color=spec
    for m in range(1,13):
        values = d.loc[d.index.month==m,key]
        xx=np.linspace(m-.36,m+.36,len(values))
        if m%2==0:
            ax.axvspan(m-.49,m+.49,color='#f3f6f9',zorder=0)
        ax.plot(xx,values.to_numpy(),color=color,lw=1,marker='.',ms=2.8,alpha=.8)
        ax.hlines(means.loc[m,key],m-.40,m+.40,color='#a62240',lw=2.4,zorder=4)
    ax.axhline(d[key].mean(),color='#738296',lw=1,ls='--',zorder=1)
    ax.set_title(title,loc='left',fontsize=13,pad=15)
    ax.set(xlim=(.48,12.52),xticks=range(1,13),xticklabels=MONTHS,ylabel=unit)
    ax.set_xlabel('Dentro de cada mês, os anos avançam da esquerda para a direita: 1994 → 2024',labelpad=10,fontsize=9)
    ax.yaxis.set_major_formatter(FuncFormatter(lambda v,pos:fmt(v,0)))
    ax.grid(axis='y',alpha=.16)
    ax.margins(y=.15)
    handles=[Line2D([0],[0],color=color,lw=1,label='Observações anuais do mesmo mês'),
             Line2D([0],[0],color='#a62240',lw=2.4,label='Média do mês (31 observações)'),
             Line2D([0],[0],color='#738296',lw=1,ls='--',label='Média geral da série')]
    ax.legend(handles=handles,loc='upper center',ncol=3,frameon=False,fontsize=8)

for spec in specs:
    fig,ax=plt.subplots(figsize=(13,5))
    subseries(ax,spec)
    fig.subplots_adjust(left=.085,right=.985,top=.88,bottom=.18)
    fig.text(.085,.025,'Fonte: FRED • 1994M1–2024M12 • Unidades originais • 2025 reservado para avaliação',fontsize=9,color='#52667c')
    save(fig,'subseries_'+spec[0].lower())

fig,axes=plt.subplots(2,1,figsize=(14,10))
for ax,spec in zip(axes,specs):
    subseries(ax,spec)
fig.subplots_adjust(left=.085,right=.985,top=.85,bottom=.09,hspace=.42)
fig.suptitle('Sazonalidade | Sub-séries mensais',x=.085,y=.972,ha='left',fontsize=21,weight='bold')
fig.text(.085,.931,'31 observações por mês • Jan/1994–Dez/2024 • Médias mensais em vermelho',fontsize=12)
fig.text(.085,.025,'Fonte: FRED. Eixos verticais nas unidades originais de cada série; magnitudes absolutas não são diretamente comparáveis.',fontsize=10,color='#52667c')
save(fig,'painel_subseries')

fig,axes=plt.subplots(2,1,figsize=(11,8),sharex=True)
limit=max(abs(relative.min().min()),abs(relative.max().max()))+4
for ax,spec in zip(axes,specs):
    key,title,unit,color=spec
    ax.axhline(0,color='#64748b',ls='--',lw=1)
    ax.plot(range(1,13),relative[key],color=color,marker='o',lw=2)
    ax.fill_between(range(1,13),0,relative[key],color=color,alpha=.08)
    ax.set_title(title,loc='left',fontsize=12)
    ax.set(ylim=(-limit,limit),ylabel='Desvio da média geral (%)',xticks=range(1,13),xticklabels=MONTHS)
    ax.tick_params(labelbottom=True)
    ax.grid(axis='y',alpha=.16)
    ax.yaxis.set_major_formatter(FuncFormatter(lambda v,pos:fmt(v,0)))
fig.subplots_adjust(left=.11,right=.98,top=.82,bottom=.10,hspace=.4)
fig.suptitle('Perfil médio por mês | Comparação relativa',x=.11,y=.97,ha='left',fontsize=19,weight='bold')
fig.text(.11,.916,'100 × (média do mês / média geral da própria série − 1) • 1994–2024',fontsize=11)
fig.text(.11,.028,'Fonte: FRED. Escala percentual comum; esta medida descritiva não é um fator sazonal estimado.',fontsize=9,color='#52667c')
save(fig,'perfil_relativo')

summary={}
for key,*_ in specs:
    v=means[key]
    summary[key]={'media_geral':float(d[key].mean()),'mes_minimo':int(v.idxmin()),'mes_maximo':int(v.idxmax()),
        'media_minima':float(v.min()),'media_maxima':float(v.max()),
        'amplitude_relativa_pp':float(relative[key].max()-relative[key].min()),
        'maximo_sobre_minimo_pct':float(100*(v.max()/v.min()-1))}
meta={'amostra':['1994-01-01','2024-12-01'],'N':372,'n_por_mes':31,'unidades_originais':True,
    'formula_perfil_relativo':'100 * (monthly mean / overall series mean - 1)',
    'nota':'perfil descritivo; não isola formalmente tendência/ciclo e sazonalidade',
    'raw_sha256':hashlib.sha256(RAW.read_bytes()).hexdigest(),'resumo':summary}
(OUT/'metodologia.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2),encoding='utf-8')

rows=['| Mês | Média de h (mil no mês) | Média de s (mil, anualizada) | Desvio de h (%) | Desvio de s (%) |',
      '|:--|--:|--:|--:|--:|']
for m in range(1,13):
    rows.append('| '+MONTHS[m-1]+' | '+' | '.join(fmt(v) for v in [means.loc[m,'HOUSTNSA'],means.loc[m,'HOUST'],relative.loc[m,'HOUSTNSA'],relative.loc[m,'HOUST']])+' |')
mdtable='\n'.join(rows)
h,s=summary['HOUSTNSA'],summary['HOUST']
report=f'''# Questão 1(c) — Caracterização da sazonalidade

## Método e amostra

Utilizamos a janela de estimação 1994M1–2024M12: 372 observações por série e 31 observações para cada mês do ano. Mantemos 2025 reservado para avaliação dos modelos. Os dados são a mesma cópia do FRED utilizada nas questões anteriores, sem novos downloads ou revisões.

Preservamos as unidades originais: h_t = HOUSTNSA_t, em milhares de unidades iniciadas no mês, sem ajuste sazonal; s_t = HOUST_t, em milhares de unidades como taxa anualizada dessazonalizada. HOUST não foi dividido por 12.

O seasonal subseries plot reúne todos os janeiros em um bloco, todos os fevereiros no seguinte e assim sucessivamente. Dentro de cada bloco, as observações seguem a ordem dos anos (1994 a 2024). A linha vermelha mostra a média daquele mês e a linha tracejada mostra a média geral da série. Assim, é possível observar tanto diferenças entre os meses quanto a evolução histórica dentro de cada mês. [Referência: gráficos de sub-séries sazonais](https://otexts.com/fpp3/subseries.html).

Para cada série x e mês m, a média mensal é a soma das 31 observações daquele mês dividida por 31. Como as unidades diferem, comparamos a intensidade do perfil por D_m = 100 × (média do mês / média geral da própria série − 1), mantendo os dois gráficos separados. D_m é um desvio percentual descritivo, não uma taxa de crescimento mensal e não um fator sazonal estimado por decomposição.

## Gráficos de sub-séries sazonais

![Sub-séries sazonais nas unidades originais](graficos/painel_subseries.png)

## Perfil médio mensal

{mdtable}

![Perfis relativos em gráficos separados com escala percentual comum](graficos/perfil_relativo.png)

## Série bruta: sazonalidade anual acentuada

A série bruta apresenta médias mais baixas no inverno do Hemisfério Norte, especialmente janeiro e fevereiro, e mais altas na primavera e no verão. A atividade aumenta fortemente de fevereiro para março, mantém patamar elevado entre abril e agosto e recua no final do ano. Essa recorrência caracteriza sazonalidade anual de período 12.

A menor média ocorre em **{FULL[h['mes_minimo']-1]}: {fmt(h['media_minima'])} mil unidades no mês**, e a maior em **{FULL[h['mes_maximo']-1]}: {fmt(h['media_maxima'])} mil unidades**. A média geral é {fmt(h['media_geral'])} mil. Esses extremos correspondem a {fmt(relative.loc[h['mes_minimo'],'HOUSTNSA'])}% e {fmt(relative.loc[h['mes_maximo'],'HOUSTNSA'])}% em relação à média geral. A diferença entre máximo e mínimo do perfil relativo é **{fmt(h['amplitude_relativa_pp'])} pontos percentuais**; a média do mês de pico supera a do mês de vale em {fmt(h['maximo_sobre_minimo_pct'])}%.

O padrão é compatível com as condições climáticas recorrentes e o calendário de execução das obras. O ajuste sazonal do Census busca retirar efeitos regulares do calendário e do clima típico, não necessariamente condições meteorológicas excepcionais. [Metodologia do Census Bureau](https://www.census.gov/construction/soc/methodology.html).

Dentro dos blocos mensais, também se observa forte variação entre anos, associada aos movimentos de longo prazo já vistos na questão 1(a). Portanto, as linhas finas dentro de cada bloco não representam apenas sazonalidade; mostram também ciclo, tendência e flutuações irregulares.

## Série ajustada: perfil médio muito mais plano

Na série dessazonalizada, as médias dos meses ficam próximas umas das outras. A menor é a de **{FULL[s['mes_minimo']-1]}: {fmt(s['media_minima'])} mil unidades em taxa anualizada**, e a maior é a de **{FULL[s['mes_maximo']-1]}: {fmt(s['media_maxima'])} mil**, diante de média geral de {fmt(s['media_geral'])} mil. Os desvios extremos são {fmt(relative.loc[s['mes_minimo'],'HOUST'])}% e {fmt(relative.loc[s['mes_maximo'],'HOUST'])}%, e a amplitude relativa é de apenas **{fmt(s['amplitude_relativa_pp'])} pontos percentuais**.

Essa amplitude é muito menor que os {fmt(h['amplitude_relativa_pp'])} pontos percentuais da série bruta. Logo, o ajuste sazonal reduz substancialmente o padrão mensal médio. A conclusão decorre da forma e dos desvios relativos dos perfis, não da comparação dos valores absolutos nem da altura das curvas em eixos com unidades diferentes. A anualização, por ser uma mudança constante de escala, não altera os desvios relativos.

O perfil mais plano não significa ausência de ciclos econômicos, de flutuações mensais ou de toda dependência sazonal. Isso é coerente com a questão 1(b): a série bruta possui picos anuais positivos fortes na FAC, enquanto a ajustada ainda apresenta algumas correlações em defasagens sazonais. Perfil médio por mês e FAC medem aspectos distintos: o primeiro descreve diferenças de média entre meses; a segunda descreve associação temporal.

## Limites da interpretação

O perfil usa os mesmos 31 anos em todos os meses, evitando composição desigual de anos entre meses. Ainda assim, a média em nível não isola formalmente o componente sazonal de tendências, ciclos e choques, e pode ocultar mudanças de padrão ao longo do tempo. As pequenas diferenças entre as médias da série ajustada não demonstram, por si sós, sazonalidade residual estatisticamente significativa. A análise é descritiva: não foi realizado teste formal nem estimado modelo nesta questão.

## Arquivos e fontes

- [Perfil médio mensal e desvios relativos](perfil_medio_mensal.csv).
- [Observações usadas nas sub-séries](observacoes_subseries.csv).
- [Metodologia e resumo numérico](metodologia.json).
- [Código reprodutível](../codigos/questao_1c.py).
- Gráficos individuais e painéis em PNG e SVG na pasta graficos.
- Dados: [FRED — HOUSTNSA](https://fred.stlouisfed.org/series/HOUSTNSA) e [FRED — HOUST](https://fred.stlouisfed.org/series/HOUST). Cópia preservada na questão 1(a), sujeita às revisões incorporadas na extração.
'''
(OUT/'resposta_questao_1c.md').write_text(report,encoding='utf-8')
print(mdtable)
print(json.dumps(summary,ensure_ascii=False,indent=2))
print('Verificado: 31 observações em cada mês; médias mensais reconciliadas com a média geral; desvios relativos com média zero.')
