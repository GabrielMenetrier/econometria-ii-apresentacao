from pathlib import Path
import sys,os,json
ROOT=Path(__file__).resolve().parents[1];sys.path.append(str(ROOT/'.dependencias'))
os.environ['MPLCONFIGDIR']=str(ROOT/'.cache_matplotlib');sys.stdout.reconfigure(encoding='utf-8')
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.stats import norm
from statsmodels.tsa.arima.model import ARIMA
OUT=ROOT/'questao_4b';(OUT/'graficos').mkdir(parents=True,exist_ok=True)
data=pd.read_csv(ROOT/'dados/brutos/housing_fred_1994_2025_python.csv',parse_dates=['observation_date']).set_index('observation_date')[['HOUST','HOUSTNSA']].loc['1994-01-01':'2025-12-01'].asfreq('MS')
prior=pd.read_csv(ROOT/'questao_4a/previsoes_recursivas.csv',parse_dates=['origem','alvo'])
ratio=12*data.HOUSTNSA/data.HOUST
rows=[]
for r in prior.itertuples():
    hist=ratio.loc[:r.origem];same=hist[hist.index.month==r.alvo.month]
    factor=float(same.mean());assert same.index.max()<=r.origem and same.index.max()<r.alvo
    seasonal=r.serie=='HOUSTNSA';mult=1 if seasonal else factor/12
    row=dict(metodo='SARIMA direto' if seasonal else 'ARIMA recomposto',origem=r.origem,alvo=r.alvo,observado=float(data.loc[r.alvo,'HOUSTNSA']),previsao=r.previsao*mult,fator_estimado=factor,N_fator=len(same),ultima_data_fator=same.index.max(),previsao_original=r.previsao)
    if r.alvo.year==2025:
        train=data.loc[:r.origem,r.serie];y=train.diff(12).diff().dropna() if seasonal else train.diff().dropna()
        model=ARIMA(y,order=(0,0,1),seasonal_order=(0,0,1,12) if seasonal else (0,0,0,0),trend='n',concentrate_scale=True)
        f=model.filter([r.theta,r.Theta] if seasonal else [r.theta]);fc=f.get_forecast(1)
        assert np.isclose(f.scale,r.sigma2,rtol=1e-8)
        assert np.isclose(float(np.asarray(fc.predicted_mean)[0]),r.previsao_transformada,atol=1e-7)
        se=float(np.asarray(fc.se_mean)[0])*mult
        row.update(erro_padrao_condicional=se,limite_inferior95=row['previsao']-norm.ppf(.975)*se,limite_superior95=row['previsao']+norm.ppf(.975)*se)
    row['erro']=row['observado']-row['previsao'];rows.append(row)
result=pd.DataFrame(rows);result.to_csv(OUT/'previsoes_alvo_comum.csv',index=False)
year=result[result.alvo.dt.year==2025].copy();assert len(year)==24
year['coberto95']=(year.observado>=year.limite_inferior95)&(year.observado<=year.limite_superior95)
year.to_csv(OUT/'previsoes_intervalos_2025.csv',index=False)
metrics=[]
for method,g in result.groupby('metodo'):
    for period,part in [('2015M2–2025M12',g),('2025M1–2025M12',g[g.alvo.dt.year==2025])]:
        metrics.append(dict(metodo=method,periodo=period,N=len(part),RMSE=np.sqrt(np.mean(part.erro**2)),MAE=np.mean(abs(part.erro)),MAPE=100*np.mean(abs(part.erro/part.observado))))
pd.DataFrame(metrics).to_csv(OUT/'metricas_alvo_comum.csv',index=False)
fig,axes=plt.subplots(2,1,figsize=(11,8),sharex=True,sharey=True)
colors={'ARIMA recomposto':'#2563a6','SARIMA direto':'#b85020'}
for ax,(method,g) in zip(axes,year.groupby('metodo')):
    g=g.sort_values('alvo');x=np.arange(12)
    ax.fill_between(x,g.limite_inferior95,g.limite_superior95,color=colors[method],alpha=.18,label='Intervalo preditivo nominal de 95%*')
    ax.plot(x,g.previsao,color=colors[method],marker='o',lw=1.6,label='Previsão de um mês à frente')
    ax.plot(x,g.observado,color='#17202a',marker='s',lw=1.6,label='HOUSTNSA observada')
    ax.set_title('HOUST ajustada → ARIMA → recomposição sazonal' if method=='ARIMA recomposto' else 'HOUSTNSA bruta → SARIMA direto',loc='left')
    ax.set_ylabel('Mil unidades no mês');ax.legend(fontsize=9,loc='lower left');ax.grid(alpha=.18)
axes[-1].set_xticks(range(12),['Jan','Fev','Mar','Abr','Mai','Jun','Jul','Ago','Set','Out','Nov','Dez'])
fig.suptitle('2025 — duas estratégias para prever a mesma série bruta',fontsize=14)
fig.text(.07,.02,'*Intervalos condicionais aos parâmetros; no ARIMA, também ao fator sazonal estimado.\nNão incorporam incerteza de recomposição, revisões ou efeitos ARCH. Origens atualizadas a cada mês.',fontsize=9)
fig.tight_layout(rect=[0,.075,1,.96]);fig.savefig(OUT/'graficos/previsoes_comparaveis_2025.png',dpi=180);fig.savefig(OUT/'graficos/previsoes_comparaveis_2025.svg');plt.close(fig)
print(pd.DataFrame(metrics).to_string(index=False));print(year.groupby('metodo').coberto95.sum());print(year[year.metodo=='ARIMA recomposto'][['alvo','fator_estimado','observado','previsao','limite_inferior95','limite_superior95']].to_string(index=False))
