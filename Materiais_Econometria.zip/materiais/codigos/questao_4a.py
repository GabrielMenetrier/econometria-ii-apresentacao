from pathlib import Path
import sys,os,json,warnings
ROOT=Path(__file__).resolve().parents[1];sys.path.append(str(ROOT/'.dependencias'))
os.environ['MPLCONFIGDIR']=str(ROOT/'.cache_matplotlib');sys.stdout.reconfigure(encoding='utf-8')
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from statsmodels.tsa.arima.model import ARIMA
OUT=ROOT/'questao_4a';(OUT/'graficos').mkdir(parents=True,exist_ok=True)
data=pd.read_csv(ROOT/'dados/brutos/housing_fred_1994_2025_python.csv',parse_dates=['observation_date']).set_index('observation_date')[['HOUST','HOUSTNSA']].loc['1994-01-01':'2025-12-01'].asfreq('MS')
assert len(data)==384 and data.notna().all().all()
rows=[];audit=[]
for series in data.columns:
    seasonal=series=='HOUSTNSA';previous=None
    for origin in pd.date_range('2015-01-01','2025-11-01',freq='MS'):
        train=data.loc[:origin,series];target=origin+pd.offsets.MonthBegin(1)
        y=train.diff(12).diff().dropna() if seasonal else train.diff().dropna()
        assert train.index[-1]<target and len(train)==len(y)+(13 if seasonal else 1)
        model=ARIMA(y,order=(0,0,1),seasonal_order=(0,0,1,12) if seasonal else (0,0,0,0),trend='n',concentrate_scale=True)
        candidates=[]
        for start in [None,previous] if previous is not None else [None,np.zeros(2 if seasonal else 1)]:
            with warnings.catch_warnings(record=True) as caught:
                warnings.simplefilter('always')
                fit=model.fit(start_params=start,cov_type='none',method_kwargs={'maxiter':1500,'pgtol':1e-8,'factr':1e4})
                audit.append(dict(serie=series,origem=str(origin.date()),converged=bool(fit.mle_retvals['converged']),llf=fit.llf,warnings=[str(c.message) for c in caught]))
                if fit.mle_retvals['converged']:candidates.append(fit)
        if not candidates:raise RuntimeError(f'Sem convergencia {series} {origin}')
        fit=max(candidates,key=lambda f:f.llf);previous=np.asarray(fit.params)
        transformed=float(np.asarray(fit.forecast(1))[0])
        base=float(train.iloc[-1])
        if seasonal:base+=float(train.loc[target-pd.DateOffset(months=12)]-train.loc[origin-pd.DateOffset(months=12)])
        pred=base+transformed;actual=float(data.loc[target,series]);error=actual-pred
        rows.append(dict(serie=series,modelo='SARIMA(0,1,1)(0,1,1)12' if seasonal else 'ARIMA(0,1,1)',origem=origin,alvo=target,N_niveis=len(train),N_efetivo=len(y),observado=actual,previsao=pred,erro=error,erro_absoluto=abs(error),erro_quadrado=error**2,APE=100*abs(error/actual),theta=float(fit.params.iloc[0]),Theta=float(fit.params.iloc[1]) if seasonal else None,sigma2=fit.scale,previsao_transformada=transformed))
        if target.month==12:print(series,target.date(),flush=True)
result=pd.DataFrame(rows);assert len(result)==262
result.to_csv(OUT/'previsoes_recursivas.csv',index=False)
metrics=[]
for series,g in result.groupby('serie'):
    assert len(g)==131 and g.alvo.min()==pd.Timestamp('2015-02-01') and g.alvo.max()==pd.Timestamp('2025-12-01')
    for label,part in [('2015M2–2025M12',g),('2015M2–2024M12',g[g.alvo<'2025-01-01']),('2025M1–2025M12',g[g.alvo>='2025-01-01'])]:
        metrics.append(dict(serie=series,periodo=label,N=len(part),RMSE=np.sqrt(part.erro_quadrado.mean()),MAE=part.erro_absoluto.mean(),MAPE=part.APE.mean()))
    fig,ax=plt.subplots(figsize=(12,4));ax.plot(g.alvo,g.observado,label='Observado',lw=1.3);ax.plot(g.alvo,g.previsao,label='Previsão de 1 mês à frente',lw=1.2)
    ax.set_title(series+' — previsões com janela expansível');ax.set_ylabel('Mil unidades no mês' if series=='HOUSTNSA' else 'Mil unidades, taxa anualizada dessazonalizada');ax.legend();fig.tight_layout()
    fig.savefig(OUT/'graficos'/f'{series}_previsoes.png',dpi=170);fig.savefig(OUT/'graficos'/f'{series}_previsoes.svg');plt.close(fig)
pd.DataFrame(metrics).to_csv(OUT/'metricas.csv',index=False)
(OUT/'auditoria_otimizacao.json').write_text(json.dumps(audit,indent=2),encoding='utf-8')
print(pd.DataFrame(metrics).to_string(index=False),flush=True)
