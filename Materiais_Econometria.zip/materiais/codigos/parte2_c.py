exec(open(__file__.replace('parte2_c.py','parte2_b.py'),encoding='utf-8').read().split('rows=[]')[0])
OUT=BASE/'item_c';(OUT/'modelos').mkdir(parents=True,exist_ok=True)
rows=[];coef=[]
for lag in [0,1,5]:
 for p,q in [(1,1),(1,2),(2,1)]:
  for dist in ['normal','t']:
   name=f'AR{lag}_GARCH{p}{q}_{dist}';m=arch_model(r,mean='Constant' if lag==0 else 'AR',lags=lag or None,vol='GARCH',p=p,o=0,q=q,dist=dist,hold_back=5,rescale=False)
   f=m.fit(disp='off',cov_type='robust',options={'maxiter':3000,'ftol':1e-10})
   assert f.convergence_flag==0 and f.nobs==1503
   z=f.std_resid.dropna();persistence=sum(v for k,v in f.params.items() if k.startswith(('alpha[','beta[')))
   row=dict(modelo=name,AR=lag,p=p,q=q,dist=dist,N=f.nobs,AIC=f.aic,BIC=f.bic,persistencia=persistence,omega=f.params['omega'])
   for h in [5,10,20]:
    row[f'LBz_{h}_p']=float(acorr_ljungbox(z,lags=[h],model_df=0).iloc[0].lb_pvalue);row[f'LBz2_{h}_p']=float(acorr_ljungbox(z*z,lags=[h],model_df=0).iloc[0].lb_pvalue);row[f'ARCH_{h}_p']=float(het_arch(z,nlags=h,ddof=0)[1])
   eps=f.resid.dropna().to_numpy()[:-1];neg=(eps<0).astype(float);X=np.column_stack([np.ones(len(eps)),neg,neg*eps,(1-neg)*eps]);aux=sm.OLS(z.to_numpy()[1:]**2,X).fit();row['EngleNg_p']=float(chi2.sf(len(eps)*aux.rsquared,3));rows.append(row)
   for k in f.params.index:coef.append(dict(modelo=name,parametro=k,valor=f.params[k],erro_padrao=f.std_err[k],p_valor=f.pvalues[k]))
   with (OUT/'modelos'/f'{name}.pickle').open('wb') as file:pickle.dump(f,file)
table=pd.DataFrame(rows).sort_values('BIC');table.to_csv(OUT/'comparacao_garch.csv',index=False);pd.DataFrame(coef).to_csv(OUT/'coeficientes.csv',index=False)
details={}
for name in ['AR0_GARCH11_t',table.iloc[0].modelo]:
 with (OUT/'modelos'/f'{name}.pickle').open('rb') as file:f=pickle.load(file)
 keys=[k for k in f.params.index if k.startswith(('alpha[','beta['))];rho=f.params[keys].sum();se=np.sqrt(f.param_cov.loc[keys,keys].to_numpy().sum())
 details[name]={'params':f.params.to_dict(),'se':f.std_err.to_dict(),'rho':rho,'rho_se_delta':se,'rho_IC95_wald':[rho-1.96*se,rho+1.96*se]}
 if name=='AR0_GARCH11_t':details[name].update(half_life=np.log(.5)/np.log(rho),var_incondicional=f.params['omega']/(1-rho))
(OUT/'persistencia.json').write_text(json.dumps(details,indent=2),encoding='utf-8');print(table.head(8).to_string(index=False));print(json.dumps(details,indent=2))
